#include "edit.h"

void    get_help        ( void );
void    show_insert     ( int  );
void    show_help       ( void );
void    clear_help      ( void );
void    condense_string ( STRING_INFO * );

#define REAL_ADDRESS    ( ( string->address ) + ( Y_SHIFT ) + ( cursor_x ) )
#define Y_SHIFT         ( cursor_y ) * ( string->x_len + 1 )

/* �D�U���r�� */

char * const help_message = "^E �M���ܦ楽 ^K �R�� ^N �s�� ^P �M��"
                            "PgDn �楽 Enter ���� TAB ������J";

/* ��������J�@�Ӧr��, �ݭn�ǤJ�@�ӵ��c�p�U

          struct string_info
          {
            int    x_pos            --------> �r��@�}�l�� X �y��
            int    y_pos;           --------> �r��@�}�l�� Y �y��
            int    x_len;           --------> �r��i�H���X��
            int    y_len;           --------> �r��i�H���X�C
            int    front_color;     --------> �r�ꪺ�e���C��
            int    back_color;      --------> �r�ꪺ�I���C��
            int    save_x_cursor;   --------> �W�@�� x �y�Ъ���m
            int    save_y_cursor;   --------> �W�@�� y �y�Ъ���m
            int    org_front_color; --------> �r���l���e���C��
            int    org_back_color;  --------> �r���l���I���C��
            int    smash;           --------> �r��O�_�i�H��~�Ÿ�
            int    number;          --------> �r��O�_���Ʀr�r��
            char * address;         --------> �r�ꪺ��}
          }
*/

void get_string( STRING_INFO * string )
{
  int    loop;
  int    cursor_x;
  int    cursor_y;
  int    insert_mode;
  int    pic_change;
  char   temp_address[82];
  char   input;
  char * tempaddress;

  /* �]�w x ,y ���W�@�����y�� */
  cursor_x    = string->save_x_cursor;
  cursor_y    = string->save_y_cursor;

  /* �]�w�@�ǰ򥻪��Ѽ� */
  insert_mode = 0;
  pic_change  = 1;

  /* ��ܨD�U�e�� */
  show_help();

  while ( TRUE )
  {

    /* �p�G�e��������, �h������e��ø�X */

    if ( pic_change == 1 ) print_long_string( 0, string );

    /* ��� insert �����A */
    show_insert( insert_mode );

    /* ��ܴ�Ъ��Ҧb */
    show_cursor( string->x_pos + cursor_x , string->y_pos + cursor_y
      , insert_mode );

    /* ���w�e���|���ܰ� */
    pic_change = 1;

    switch( input = get_key() )
    {
      case MY_CURSOR_HEAD :

        #if defined (unix)
        get_key();
        #endif

        switch ( input = get_key() )
        {

         /* �N��Ц^��歺 */
         case MY_CURSOR_HOME  :

           /* �e�����|��� */
           pic_change = 0;

           #if defined (unix)
           get_key();
           #endif

           cursor_x = 0;
           break;

         /* �N��в��쥻��r�ꪺ���� */

         case MY_CURSOR_END   :

           /* �e�����|��� */
           pic_change = 0;

           #if defined (unix)
           get_key();
           #endif

           for ( cursor_x = string->x_len;
             *(REAL_ADDRESS -1 ) == '\x0' && cursor_x > 0 ; cursor_x-- );
           if ( cursor_x == string->x_len ) cursor_x--;

           break;

         /* �N��ЦV�k���@�� */
         case MY_CURSOR_RIGHT :

           /* �e�����|��� */
           pic_change = 0;

           if ( ++cursor_x == string->x_len )
           {
             if ( ++cursor_y == string->y_len )
             {
               cursor_y--;
               cursor_x--;
             }

             else
             {
               cursor_x = 0;
             }
           }
           break;

         /* ���ЦV�����@�� */
         case MY_CURSOR_LEFT  :

           /* �e�����|��� */
           pic_change = 0;

           if ( --cursor_x < 0 )
           {
             if ( --cursor_y >= 0 )
             {
               cursor_x = string->x_len - 1;
             }
             else
             {
               cursor_x++;
               cursor_y++;
             }
           }

           break;

         /* ���ЦV�W���@�� */

         case MY_CURSOR_UP     :

           /* �e�����|��� */
           pic_change = 0;

           if ( cursor_y > 0 ) cursor_y--;
           break;

         /* ���ЦV�U���@�� */

         case MY_CURSOR_DOWN   :

           /* �e�����|��� */
           pic_change = 0;

           if ( ++cursor_y == string->y_len ) cursor_y--;
           break;

         /* �������J�Ҧ� */

         case MY_CURSOR_INSERT :

           /* �e�����|��� */
           pic_change = 0;

           #if defined (unix)
           get_key();
           #endif

           insert_mode = ( ++insert_mode ) & 1;
           break;

         /* �R���@�Ӧr�� */

         case MY_CURSOR_DELETE :

           #if defined (unix)
           get_key();
           #endif

           *REAL_ADDRESS = '\x0';
           tempaddress = REAL_ADDRESS;

           do
           {
             *tempaddress = *(tempaddress+1);

           } while ( *(++tempaddress) != '\x0' );

            *(tempaddress+1) = '\x0';

          break;

         /* �N��в��쥻�檺���� */

         case MY_CURSOR_PGDN   :

           /* �e�����|��� */
           pic_change = 0;

           #if defined (unix)
           get_key();
           #endif

           cursor_x = string->x_len - 1;
           break;

         /* ��ܨD�U�e�� , �u�b DOS ���� */
         case MY_CURSOR_F1     :

           /* �e�����|��� */
           pic_change = 0;

           get_help();
           break;

         case MY_CURSOR_PGUP   :

           /* �e�����|��� */
           pic_change = 0;

           #if defined (unix)
           get_key();
           #endif

           break;

         default               :

           /* �e�����|��� */
           pic_change = 0;

           break;
        }

        break;

      /* ���U���@��, �Y�u���@��h������J */
      case MY_KEY_RETURN :

        {
          /* �Y�u���@��h������J */
          if ( string->y_len == 1 )
          {

           /* �O���o�@���̫᪺ x , y �y�� */
            string->save_x_cursor = cursor_x;
            string->save_y_cursor = cursor_y;

            /* ��r��᭱�L�Ϊ��ťծ��� */
            condense_string( string );

            /* �p�G�r�ꤣ�঳ ~ �Ÿ��h�� ~ �ܦ� - */
            if ( string->smash == SMASH_EXECUTE )
              smash_string( string );

            /* �M���D�U�e�� */
            clear_help();

            /* �N��Ю��� */
            set_cursor_type( NO_CURSOR );

            /* �N�r���٭즨��Ӫ��C�� */
            print_long_string( 1 , string );

            return;
           }

          /* �Y�b�̩��@��, �h���B�z */
          if ( cursor_y == string->y_len - 1 ) break;

          /* ���U���@�� */
          tempaddress = string->address
            + ( ( string->y_len - 1 ) * ( string->x_len + 1 ) );

          if ( *tempaddress != '\x0' )
          {
            cursor_y++;
            cursor_x = 0;
            break;
          }

          for ( loop = string->y_len - 1 ; loop > cursor_y ; loop-- )
          {
            int i;

            tempaddress = string->address
              + ( loop * ( string->x_len + 1 ) );

            for ( i = 0 ; i < string->x_len ; i++ )
              *(tempaddress + i ) = '\x0';

            if ( loop != cursor_y + 1 )
            strcpy( tempaddress , tempaddress - ( string->x_len + 1 ) );
          }

          tempaddress = string->address
            + ( (cursor_y + 1 ) * ( string->x_len + 1 ) );

          while ( *REAL_ADDRESS != '\x0' )
          {
            *tempaddress++ = *REAL_ADDRESS;
            *REAL_ADDRESS  = '\x0';
            cursor_x++;
          }

          cursor_x = 0;
          cursor_y++;

          break;
        }

      /* ������J */

      case MY_KEY_TAB :

        /* �O���o�@���̫᪺ x , y �y�� */
        string->save_x_cursor = cursor_x;
        string->save_y_cursor = cursor_y;

        /* ��r��᭱�L�Ϊ��ťծ��� */
        condense_string( string );

        /* �p�G�r�ꤣ�঳ ~ �Ÿ��h�� ~ �ܦ� - */
        if ( string->smash == 1 ) smash_string( string );

        /* �M���D�U�e�� */
        clear_help();

        /* �N��Ю��� */
        set_cursor_type( NO_CURSOR );

        /* �N�r���٭즨��Ӫ��C�� */
        print_long_string( 1 , string );

        return;

      /* �R���@�� */

      case MY_KEY_CTRL_K :

        {
          int temp_cursor_y;
          int i;

          cursor_x      = 0;
          temp_cursor_y = cursor_y;

          for ( ; cursor_y < string->y_len ; cursor_y++ )
          {

            for ( i = 0; i < string->x_len ; i++ )
              *(REAL_ADDRESS + i ) = '\0';

            if ( cursor_y != string->y_len - 1 )
              strcpy( REAL_ADDRESS , REAL_ADDRESS + string->x_len + 1 );

          }

          cursor_x = 0;
          cursor_y = temp_cursor_y;

        }

        break;

      /* �M���@�� */

      case MY_KEY_CTRL_P :

        cursor_x = 0;
        for ( ; cursor_x < string->x_len ; cursor_x++ )
          *REAL_ADDRESS = '\x0';
        cursor_x = 0;
        break;

      /* �R���ܦ楽 */

      case MY_KEY_CTRL_E :

        {
          int i;

          i = cursor_x;

          for ( ; cursor_x < string->x_len ; cursor_x++ )
            *REAL_ADDRESS = '\0';

          cursor_x = i;
          break;

        }

      /* �s����� */

      case MY_KEY_CTRL_N :

        {
          int temp_cursor_x;
          int temp_cursor_y;
          int i;

          if ( cursor_y == string->y_len - 1 ) break;
          tempaddress = string->address
              + ( ( cursor_y + 1 ) * ( string->x_len + 1 ) );

          temp_cursor_x = cursor_x;
          cursor_x      = 0;

          if ( strlen( tempaddress ) + strlen( REAL_ADDRESS )
                 > string->x_len )
          {
            warning_beep();
            cursor_x = temp_cursor_x;
            break;
          }

          strcat( REAL_ADDRESS , tempaddress );

          cursor_x      = 0;
          temp_cursor_y = cursor_y;
          cursor_y++;

          for ( ; cursor_y < string->y_len ; cursor_y++ )
          {

            for ( i = 0; i < string->x_len ; i++ )
              *(REAL_ADDRESS + i ) = '\0';

            if ( cursor_y != string->y_len - 1 )
              strcpy( REAL_ADDRESS , REAL_ADDRESS + string->x_len + 1 );

          }

          cursor_y = temp_cursor_y;
          cursor_x = temp_cursor_x;

          break;
        }

      /* �˰h�����@�Ӧr�� */
      case MY_KEY_BACKSPACE :

        {

          int temp_cursor_y;
          int i;

          if ( cursor_x == 0 )
          {
            if ( cursor_y == 0 )
            {
              warning_beep();
              break;
            }

            tempaddress = string->address
              + ( ( cursor_y - 1 ) * ( string->x_len + 1 ) );

            if ( strlen( tempaddress ) + strlen( REAL_ADDRESS )
                 > string->x_len )
            {
              warning_beep();
              break;
            }

            strcat( tempaddress , REAL_ADDRESS );

            cursor_x      = 0;
            temp_cursor_y = cursor_y;

            for ( ; cursor_y < string->y_len ; cursor_y++ )
            {

              for ( i = 0; i < string->x_len ; i++ )
                *(REAL_ADDRESS + i ) = '\0';

              if ( cursor_y != string->y_len - 1 )
                strcpy( REAL_ADDRESS , REAL_ADDRESS + string->x_len + 1 );

            }

            cursor_y = temp_cursor_y;
            cursor_x = strlen( tempaddress );
            if ( cursor_x == string->x_len ) cursor_x--;
            cursor_y--;
            break;
          }

          cursor_x--;
          *REAL_ADDRESS = '\0';
            tempaddress = REAL_ADDRESS;

          do
          {
            *tempaddress = *(tempaddress+1);

          } while ( *(tempaddress++) != '\0' );

          break;
        }

      default:

        /* �p�G number �]�w��1 , ���u���J�Ʀr */
        if ( ( !isdigit( input ) && input != '-' )
             && string->number == NUMBER_ONLY )
        {
          warning_beep();
          break;
        }

        /* �P�w�O�_�O���`�r���άO����r�� */

        if ( !iscntrl(input) || IsChinese( input ) )
        {
          loop = cursor_x ;
          for ( ; cursor_x >= 0 ; cursor_x-- )
            if ( *REAL_ADDRESS == '\x0' ) *REAL_ADDRESS = ' ';

          cursor_x = loop;

          if ( insert_mode == 0 )
          {
            *REAL_ADDRESS = input;
            if ( ++cursor_x == string->x_len ) cursor_x--;
          }

          else
          {

            tempaddress = Y_SHIFT + string->address;

            if ( strlen( tempaddress ) >= string->x_len )
            {
              warning_beep();
            }

            else
            {

              strcpy( temp_address , REAL_ADDRESS );
              *REAL_ADDRESS     = input;
              cursor_x++;
              *REAL_ADDRESS     = '\x0';
              strcat( REAL_ADDRESS , temp_address );
              if ( cursor_x == string->x_len ) cursor_x--;

            }
          }
        }
      break;
    }
  }
}

/* ��J�r�ꪺ�D�U�e�� */

void get_help( void )
{

  char buffer[ 80 * 25 ];
  int  color;

  save_windows( 19, 10 , 60 , 19 , buffer );

  color = LIGHTGREEN + ( BLUE << 4 );
  set_cursor_type( NO_CURSOR );

  print_string( 19 , 10 , color , " �z�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�{ " );
  print_string( 19 , 11 , color , " �xctrl+P  �M�����.   <HOME> ����歺 �x " );
  print_string( 19 , 12 , color , " �xctrl+K  �R�����.   <END>  ����好 �x " );
  print_string( 19 , 13 , color , " �xctrl+E  �M���ܦ楽. <PgDw> ����楽 �x " );
  print_string( 19 , 14 , color , " �xctrl+N  �s����C    <Curs> �W�U���k �x " );
  print_string( 19 , 15 , color , " �x<F1>    �D�U        <Back> �˰h�R�� �x " );
  print_string( 19 , 16 , color , " �x<TAB>   ������J    <Ins>  ���J�Ҧ� �x " );
  print_string( 19 , 17 , color , " �x<ENTER> ����        <Del>  �R����r �x " );
  print_string( 19 , 18 , color , " �x           * ���������~�� *         �x " );
  print_string( 19 , 19 , color , " �|�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�} " );

  get_control_key();

  restore_windows( 19, 10, 60, 19, buffer );

}

/* �o��@�ǯS��������, �Ǧ^�� �p�U

�Ǧ^�� ��ФW   RETURN_UP        1
�Ǧ^�� ��ФU   RETURN_DOWN      2
�Ǧ^�� ��Х�   RETURN_LEFT      3
�Ǧ^�� ��Хk   RETURN_RIGHT     4
�Ǧ^�� ���HOME RETURN_HOME      5
�Ǧ^�� ���END  RETURN_END       6
�Ǧ^�� RETURN   RETURN_RETURN   10
�Ǧ^�� TAB      RETURN_TAB      11
�Ǧ^�� SPACE    RETURN_SPACE    12
�Ǧ^�� PGDN     RETURN_PGDN     13
�Ǧ^�� PGUP     RETURN_PGUP     14
��L������      RETURN_NONE      0

*/

int get_control_key( void )
{
  char control_key;

  locate_cursor( IDLE_X_CURSOR , IDLE_Y_CURSOR );

  control_key = get_key();
  switch ( control_key )
  {
    case MY_CURSOR_HEAD :

      #if defined (unix)
      get_key();
      #endif

      control_key = get_key();
      switch ( control_key )
      {
        case MY_CURSOR_UP     : return RETURN_UP   ;
        case MY_CURSOR_DOWN   : return RETURN_DOWN ;
        case MY_CURSOR_LEFT   : return RETURN_LEFT ;
        case MY_CURSOR_RIGHT  : return RETURN_RIGHT;

        case MY_CURSOR_HOME   :

          #if defined (unix)
          get_key();
          #endif
          return RETURN_HOME ;

        case MY_CURSOR_END    :

          #if defined (unix)
          get_key();
          #endif
          return RETURN_END ;

        case MY_CURSOR_PGDN   :

          #if defined (unix)
          get_key();
          #endif
          return RETURN_PGDN ;

        case MY_CURSOR_PGUP   :

          #if defined (unix)
          get_key();
          #endif
          return RETURN_PGUP ;

        #if defined (unix)

        case MY_CURSOR_INSERT :
        case MY_CURSOR_DELETE :

          get_key();
          return RETURN_NONE;

        #endif

        default              : return RETURN_NONE ;
      }

    case MY_KEY_SPACE        : return RETURN_SPACE;
    case MY_KEY_RETURN       : return RETURN_RETURN;
    case MY_KEY_TAB          : return RETURN_TAB;
    default                  :
    return RETURN_NONE;
  }

}

/* ��ܴ��J�Ҧ������A */

void show_insert( int insert_mode )
{

  if ( insert_mode == 0 )
    print_string( 75 , 23 , WHITE , "���`" );

  else
    print_string( 75 , 23 , WHITE , "���J" );

  return;

}

/* ��ܿ�J���D�U���e�� */
void show_help( void )
{
  print_string( 1 , 23 , WHITE , help_message );
  return;
}

/* �M����J���D�U�e�� */
void clear_help( void )
{

  int   loop;
  char  blank_message[ 82 ];

  for ( loop = 0 ; loop < strlen( help_message ) ; loop++ )
    blank_message[loop] = ' ';

  blank_message[loop] = '\x0';
  print_string( 1 , 23 , WHITE , blank_message );
  return;

}

/* ��r��᭱�L�Ϊ��ťծ��� */

void condense_string( STRING_INFO * string )
{
  int cursor_x;
  int cursor_y;

  for ( cursor_y = 0; cursor_y < string->y_len ; cursor_y++ )
  {
    for ( cursor_x = string->x_len - 1 ; cursor_x >= 0 ; cursor_x-- )
    {
      if ( *REAL_ADDRESS == '\x0' ) continue;
      if ( *REAL_ADDRESS == ' '   ) *REAL_ADDRESS = '\x0';
      else                          cursor_x      = 0;
    }
  }

  return;
}

/* �M���r��̭��t�� ~ ���r�� */
void smash_string( STRING_INFO *pString )
{
  int    loop;
  int    fChinese = FALSE;
  int    fLast;
  char * string;

  for ( loop = 0; loop < pString->y_len ; loop++ )
  {
    string = pString->address + ( loop * ( pString->x_len + 1 ) );
    for ( ; *string != '\0'; string++ )
    {
      fLast = fChinese;

      if ( fChinese )
      {
        fChinese = FALSE;
      }

      else
      {
        if ( *string < 0 ) fChinese = TRUE;
        else               fChinese = FALSE;
      }

      if ( *string == '~' && !fLast) *string = '-';
    }

    if ( fChinese ) *--string = '\x0';
  }

  return;
}

void clear_string( STRING_INFO * pString )
{
  int i;
  int j;

  for ( i = 0; i < pString->y_len ; i++ )
  {
    for ( j = 0; j < pString->x_len ; j++ )
    {
      /* �M���C�@�Ӧr�� */
      *( pString->address + ( i * ( pString->x_len + 1 ) ) + j ) = '\x0';
    }

    /* �C�@��r���]�w�� 0 */
    *( pString->address + ( i * ( pString->x_len + 1 ) ) + j ) = '\x0';

  }

  return;
}

void number_to_string( int number , char * string )
{

  char   temp[ 20 ];
  int    len    = 0;
  int    sign   = 0;

  if ( number < 0 )
  {
    number = 0 - number;
    sign = 1;
  }

  do
  {
    temp[ len ] = '0' + number % 10;
    len++;
  } while ( ( number /= 10 ) > 0 );


  if ( sign == 1 ) *( string++ ) = '-';
  len--;

  do
  {
    *(string++) = temp[ len ];
    len--;
  } while ( len >= 0 );

  *string = '\x0';

  return;
}

void align_word( char * address , int len )
{
  int   real_length;
  int   loop;
  char  temp[ 20 ];

  if ( ( real_length = strlen( address ) ) >= len )  return;

  for ( loop = 0; loop < len - real_length; loop++ )  temp[loop] = ' ';
  temp[ loop ] = '\x0';
  strcat( temp , address );
  strcpy( address , temp );

  return;
}

/* ��M source �r��̭��O�_�� dest �r�� */

int string_compare( char * source , char * dest )
{
  char * string_1;
  char * string_2;

  /* ���~���_�ϭ� */
  if ( *dest   == '\x0' ) return FALSE;
  if ( *source == '\x0' ) return FALSE;

  /* �p�G�b DOS , �h�ഫ�p�g���j�g */
  #if defined (MSDOS)

  string_1 = dest;
  while ( *string_1 != '\x0' )
  {
    *string_1 = toupper( *string_1 );
    string_1++;
  }

  #endif

  while ( *source != '\x0' )
  {
    string_1 = source ;
    string_2 = dest   ;

    while ( *string_1 == *string_2 )
    {
      if ( *(++string_2 ) == '\x0' ) return TRUE;
      if ( *(++string_1 ) == '\x0' ) return FALSE;
    }
    source++;
  }

  return FALSE;
}

void write_string( FILE * fp , STRING_INFO * pString )
{

  int    line;
  int    loop;
  char * address;

  for ( line = pString->y_len
    ; (*( pString->address + ( (line-1) * (pString->x_len+1))) == '\x0' )
      && ( line > 1 )
    ; line-- );

  for ( loop = 0 ; loop < line ; loop++)
  {
    address = pString->address + ( loop * ( pString->x_len + 1 ) );

    if ( *address == '.' && *(address+1) == '\x0' )
    {
      fprintf( fp , "\n" );
    }

    else
    {
      if ( loop != line - 1 )
        fprintf( fp , "%s\n"  , address );
      else
        fprintf( fp , "%s"    , address );
    }
  }

  fprintf( fp , "~\n" );

  return;
}

void write_select( FILE * fp , int selection , CONST_STRING respect[] )
{

  int loop;
  int touch;

  loop  = 0;
  touch = 0;

  while ( respect[loop].string[0] != '\x0' )
  {
    if ( respect[loop].value == selection )
    {
      touch = 1;
      fprintf( fp , "%s\n" , respect[loop].string );
    }

    loop++;
  }

  if ( touch == 0 ) fprintf( fp , "0\n" );

  return;
}

void write_bit( FILE * fp , int selection , CONST_STRING respect[] )
{

  int loop;
  int touch = 0;

  for ( loop = 0 ; respect[loop].string[0] != '\x0' ; loop++ )
  {
    if ( IS_SET( selection , respect[loop].value ) )
    {
      if ( touch != 0 )
        fprintf( fp , "|%s" , respect[loop].string );

      else
        fprintf( fp , "%s"  , respect[loop].string );

      touch = 1;

    }
  }

  if ( touch == 0 ) fprintf( fp , "0\n" );
  else              fprintf( fp , "\n"  );

  return;
}

#undef    REAL_ADDRESS
#undef    Y_SHIFT
