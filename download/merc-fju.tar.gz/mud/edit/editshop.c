#include "edit.h"

#define SHOP_X          5
#define SHOP_Y          3
#define SHOP_FRONT_COL  LIGHTGREEN
#define SHOP_BACK_COL   BLACK
#define SHOP_TAG_COL    RED
#define SHOP_COL        ( SHOP_FRONT_COL + ( SHOP_BACK_COL << 4 ) )
#define SHOP_TAG        ( SHOP_FRONT_COL + ( SHOP_TAG_COL  << 4 ) )

void    show_edit_shop_shape    ( SHOP_INFO * );
void    show_edit_shop          ( int );
void    show_shop_object        ( SHOP_INFO * );
void    show_shop_object_title  ( int );
void    do_save_shop            ( SHOP_INFO * , FILE * );
void    set_shop_default        ( SHOP_INFO * );
int     load_shop               ( SHOP_INFO * );

/* ��ܰө����_�l�e�� */
void show_edit_shop_shape( SHOP_INFO * pShop )
{

  char show_number[ 10 ];

  print_string( SHOP_X , SHOP_Y    , SHOP_COL ,"�z�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�{" );
  print_string( SHOP_X , SHOP_Y + 1, SHOP_COL ,"�x�ɮצW�� :                                                          �x" );
  print_string( SHOP_X , SHOP_Y + 2, SHOP_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( SHOP_X , SHOP_Y + 3, SHOP_COL ,"�x�ө��D�H : [     ]                                                  �x" );
  print_string( SHOP_X , SHOP_Y + 4, SHOP_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( SHOP_X , SHOP_Y + 5, SHOP_COL ,"�x�c�檫�~���� [ ] �OŢ [ ] ���b [ ] �k��1 [ ] �k��2 [ ] �Z�� [ ] �_���x" );
  print_string( SHOP_X , SHOP_Y + 6, SHOP_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( SHOP_X , SHOP_Y + 7, SHOP_COL ,"�x[ ] �@�� [ ] �Ĥ� [ ] �a�� [ ] �U�� [ ] �e�� [ ] ���U [ ] �_��      �x" );
  print_string( SHOP_X , SHOP_Y + 8, SHOP_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( SHOP_X , SHOP_Y + 9, SHOP_COL ,"�x[ ] ���� [ ] �� [ ] �� [ ] �D���a���� [ ] ���a���� [ ] �u�� [ ] �ĤY�x" );
  print_string( SHOP_X , SHOP_Y +10, SHOP_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( SHOP_X , SHOP_Y +11, SHOP_COL ,"�x�}���ɶ� [  ]    �����ɶ� [  ]    �R�J�Q�q [   ]    ��X�Q�q [   ]  �x" );
  print_string( SHOP_X , SHOP_Y +12, SHOP_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( SHOP_X , SHOP_Y +13, SHOP_COL ,"�x<�s��>  <���>                                                      �x" );
  print_string( SHOP_X , SHOP_Y +14, SHOP_COL ,"�|�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�}" );

  /* �C�L�ɦW */
  print_string( SHOP_X + 15 , SHOP_Y + 1 , SHOP_COL
    , pShop->pFile->filename );

  /* �C�L�ɮת����� */
  if ( pShop->valid == 0 )
    print_string( SHOP_X + 40 , SHOP_Y + 1 , SHOP_COL , "���ɮ�" );

  else if ( pShop->valid == 1 )
    print_string( SHOP_X + 40 , SHOP_Y + 1 , SHOP_COL , "�s�ɮ�" );

  else if ( pShop->valid == 2 )
    print_string( SHOP_X + 40 , SHOP_Y + 1 , SHOP_COL , "�����T�����ɮ�" );

  /* �ഫ�ө��D�H�ܼƦ��r��, �åB�V�k��� 5 */
  number_to_string( pShop->keeper , show_number );
  align_word( show_number , 5 );
  print_string( SHOP_X + 14 , SHOP_Y + 3 , SHOP_COL , show_number );

  /* �ഫ�ө��}���ɶ��ܼƦ��r��, �åB�V�k��� 2 */
  number_to_string( pShop->openhour , show_number );
  align_word( show_number , 2 );
  print_string( SHOP_X + 12 , SHOP_Y +11 , SHOP_COL , show_number );

  /* �ഫ�ө������ɶ��ܼƦ��r��, �åB�V�k��� 2 */
  number_to_string( pShop->closehour , show_number );
  align_word( show_number , 2 );
  print_string( SHOP_X + 29 , SHOP_Y +11 , SHOP_COL , show_number );

  /* �ഫ�ө��R�J�Q�q�ܼƦ��r��, �åB�V�k��� 3 */
  number_to_string( pShop->buyprofit , show_number );
  align_word( show_number , 3 );
  print_string( SHOP_X + 46 , SHOP_Y +11 , SHOP_COL , show_number );

  /* �ഫ�ө���X�Q�q�ܼƦ��r��, �åB�V�k��� 3 */
  number_to_string( pShop->sellprofit , show_number );
  align_word( show_number , 3 );
  print_string( SHOP_X + 64 , SHOP_Y +11 , SHOP_COL , show_number );

  /* ��ܳc�檫�~���� */
  show_shop_object( pShop );

  return;
}

/* ��ܽs��ɪ�������� */
void show_edit_shop( int control )
{
  print_string( SHOP_X + 2 , SHOP_Y + 3
    ,( ( control == 1 ) ? SHOP_TAG : SHOP_COL ) , "�ө��D�H"     );

  print_string( SHOP_X + 2 , SHOP_Y + 5
    ,( ( control == 2 ) ? SHOP_TAG : SHOP_COL ) , "�c�檫�~����" );

  print_string( SHOP_X + 2 , SHOP_Y + 11
    ,( ( control == 3 ) ? SHOP_TAG : SHOP_COL ) , "�}���ɶ�"     );

  print_string( SHOP_X + 19 , SHOP_Y + 11
    ,( ( control == 4 ) ? SHOP_TAG : SHOP_COL ) , "�����ɶ�"     );

  print_string( SHOP_X + 36 , SHOP_Y + 11
    ,( ( control == 5 ) ? SHOP_TAG : SHOP_COL ) , "�R�J�Q�q"     );

  print_string( SHOP_X + 54 , SHOP_Y + 11
    ,( ( control == 6 ) ? SHOP_TAG : SHOP_COL ) , "��X�Q�q"     );

  print_string( SHOP_X + 3 , SHOP_Y + 13
    ,( ( control == 7 ) ? SHOP_TAG : SHOP_COL ) , "�s��"         );

  print_string( SHOP_X + 11 , SHOP_Y + 13
    ,( ( control == 8 ) ? SHOP_TAG : SHOP_COL ) , "���"         );

  return;
}

/* ��ܰө��i�H�c�檫�~������ */
void show_shop_object( SHOP_INFO * pShop )
{

  print_string( SHOP_X + 16 , SHOP_Y + 5 , SHOP_COL
    , ( ( pShop->object[ 0 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 25 , SHOP_Y + 5 , SHOP_COL
    , ( ( pShop->object[ 1 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 34 , SHOP_Y + 5 , SHOP_COL
    , ( ( pShop->object[ 2 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 44 , SHOP_Y + 5 , SHOP_COL
    , ( ( pShop->object[ 3 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 54 , SHOP_Y + 5 , SHOP_COL
    , ( ( pShop->object[ 4 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 63 , SHOP_Y + 5 , SHOP_COL
    , ( ( pShop->object[ 5 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X +  3 , SHOP_Y + 7 , SHOP_COL
    , ( ( pShop->object[ 6 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 12 , SHOP_Y + 7 , SHOP_COL
    , ( ( pShop->object[ 7 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 21 , SHOP_Y + 7 , SHOP_COL
    , ( ( pShop->object[ 8 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 30 , SHOP_Y + 7 , SHOP_COL
    , ( ( pShop->object[ 9 ] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 39 , SHOP_Y + 7 , SHOP_COL
    , ( ( pShop->object[ 10] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 48 , SHOP_Y + 7 , SHOP_COL
    , ( ( pShop->object[ 11] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 57 , SHOP_Y + 7 , SHOP_COL
    , ( ( pShop->object[ 12] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X +  3 , SHOP_Y + 9 , SHOP_COL
    , ( ( pShop->object[ 13] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 12 , SHOP_Y + 9 , SHOP_COL
    , ( ( pShop->object[ 14] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 19 , SHOP_Y + 9 , SHOP_COL
    , ( ( pShop->object[ 15] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 26 , SHOP_Y + 9 , SHOP_COL
    , ( ( pShop->object[ 16] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 41 , SHOP_Y + 9 , SHOP_COL
    , ( ( pShop->object[ 17] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 54 , SHOP_Y + 9 , SHOP_COL
    , ( ( pShop->object[ 18] == 0 ) ? " " : "*" ) );

  print_string( SHOP_X + 63 , SHOP_Y + 9 , SHOP_COL
    , ( ( pShop->object[ 19] == 0 ) ? " " : "*" ) );

  return;
}

/* ��ܰө��i�H�c�檫�~�������W�r */
void show_shop_object_title( int selection )
{
  print_string( SHOP_X + 19 , SHOP_Y + 5
    ,( ( selection == 0 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 0 ].item_name );

  print_string( SHOP_X + 28 , SHOP_Y + 5
    ,( ( selection == 1 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 1 ].item_name );

  print_string( SHOP_X + 37 , SHOP_Y + 5
    ,( ( selection == 2 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 2 ].item_name );

  print_string( SHOP_X + 47 , SHOP_Y + 5
    ,( ( selection == 3 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 3 ].item_name );

  print_string( SHOP_X + 57 , SHOP_Y + 5
    ,( ( selection == 4 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 4 ].item_name );

  print_string( SHOP_X + 66 , SHOP_Y + 5
    ,( ( selection == 5 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 5 ].item_name );

  print_string( SHOP_X + 6 , SHOP_Y + 7
    ,( ( selection == 6 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 6 ].item_name );

  print_string( SHOP_X + 15 , SHOP_Y + 7
    ,( ( selection == 7 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 7 ].item_name );

  print_string( SHOP_X + 24 , SHOP_Y + 7
    ,( ( selection == 8 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 8 ].item_name );

  print_string( SHOP_X + 33 , SHOP_Y + 7
    ,( ( selection == 9 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 9 ].item_name );

  print_string( SHOP_X + 42 , SHOP_Y + 7
    ,( ( selection == 10 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 10 ].item_name );

  print_string( SHOP_X + 51 , SHOP_Y + 7
    ,( ( selection == 11 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 11 ].item_name );

  print_string( SHOP_X + 60 , SHOP_Y + 7
    ,( ( selection == 12 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 12 ].item_name );

  print_string( SHOP_X + 6 , SHOP_Y + 9
    ,( ( selection == 13 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 13 ].item_name );

  print_string( SHOP_X + 15 , SHOP_Y + 9
    ,( ( selection == 14 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 14 ].item_name );

  print_string( SHOP_X + 22 , SHOP_Y + 9
    ,( ( selection == 15 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 15 ].item_name );

  print_string( SHOP_X + 29 , SHOP_Y + 9
    ,( ( selection == 16 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 16 ].item_name );

  print_string( SHOP_X + 44 , SHOP_Y + 9
    ,( ( selection == 17 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 17 ].item_name );

  print_string( SHOP_X + 57 , SHOP_Y + 9
    ,( ( selection == 18 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 18 ].item_name );

  print_string( SHOP_X + 66 , SHOP_Y + 9
    ,( ( selection == 19 ) ? SHOP_TAG : SHOP_COL )
    , item_type[ 19 ].item_name );

  return;
}

void do_edit_shop ( void )
{
  FILE_INFO   * pFile;
  SHOP_INFO     aShop;
  SHOP_INFO   * pShop;
  STRING_INFO   aString;
  STRING_INFO * pString;
  int           control_key;
  int           control = 1;
  int           execute = 0;
  int           loop;
  int           selection = 0;
  char          temp[10];

  /* �M���ù��H�ή������ */
  clear_screen();
  set_cursor_type( NO_CURSOR );

  /* �}���ɮ� */
  pFile = get_file_name( ".sho" );

  /* �ɮ׵L�kŪ�� */
  if ( pFile->information < 0 ) return;

  /* �]�w�ө����_�ϭ� */
  pShop               = &aShop;
  pShop->valid        = pFile->information;
  pShop->pFile        = pFile;
  set_shop_default( pShop );

  /* �]�w���ο�J�r�ꪺ�_�l�� */
  pString                  = &aString;
  pString->y_len           = 1;
  pString->front_color     = BLUE;
  pString->back_color      = LIGHTGRAY;
  pString->org_front_color = SHOP_COL;
  pString->org_back_color  = BLACK;
  pString->smash           = SMASH_NO_EXECUTE;
  pString->number          = NUMBER_ONLY;
  pString->address         = temp;

  /* ���J�ө��ɮ� */
  if ( pFile->information == 0 )
  {
    /* �p�G�����~ */
    if ( !load_shop( pShop ) )
    {
      pShop->valid = 2;
      set_shop_default( pShop );
    }
  }

  /* ��ܽs��ө����e�� */
  show_edit_shop_shape( pShop );

  do
  {
    /* ��ܱ������ */
    show_edit_shop( control );

    /* �q��L�o�������� */
    control_key = get_control_key();

    if ( control_key == RETURN_TAB    ) control++;
    if ( control_key == RETURN_UP     ) control--;
    if ( control_key == RETURN_DOWN   ) control++;
    if ( control_key == RETURN_RETURN ) execute = control;
    if ( control_key == RETURN_SPACE  ) execute = control;
    if ( control_key == RETURN_HOME   ) control = 1;
    if ( control_key == RETURN_END    ) control = 8;

    check_boundary( 1 , 8 , &control );

    switch ( execute )
    {
      /* �s��ө��D�H */
      case 1 :

        pString->x_pos           = SHOP_X + 14;
        pString->y_pos           = SHOP_Y +  3;
        pString->x_len           = 5;
        pString->y_len           = 1;
        pString->save_x_cursor   = 0;
        pString->save_y_cursor   = 0;
        for ( loop = 0 ; loop < 6; loop++ ) *(pString->address+loop) = '\x0';
        number_to_string( pShop->keeper , pString->address );

        get_string( pString );
        pShop->keeper = atoi(pString->address );
        if ( pShop->keeper < 0 ) pShop->keeper = 0;

        number_to_string( pShop->keeper , pString->address );
        align_word( pString->address , 5 );
        print_string( SHOP_X + 14 , SHOP_Y + 3 , SHOP_COL , pString->address );

        execute = 0;
        break;

      /* �s��c�檫�~������ */
      case 2 :

        {
          show_shop_object( pShop );
          show_shop_object_title( selection );

          do
          {
            control_key = get_control_key();

            if ( control_key == RETURN_LEFT  ) selection--;
            if ( control_key == RETURN_RIGHT ) selection++;
            if ( control_key == RETURN_HOME  ) selection = 0;
            if ( control_key == RETURN_END   ) selection =19;


            /* �Y�O PGDN �άO  PGUP �h�M���Ҧ����ﶵ */
            if ( control_key == RETURN_PGDN || control_key == RETURN_PGUP )
            {
              for ( loop = 0; loop < MAX_ITEM ; loop++ )
                pShop->object[ loop ] = '\x0';
              pShop->object_count = 0;

            }

            /* �ť���h�N����ܳo�ت��~�O�_�i�H�c�� */
            if ( control_key == RETURN_SPACE
                 || control_key == RETURN_UP
                 || control_key == RETURN_DOWN )
            {
              /* �Y�O�w�g���, �h�ϦV�M�� */
              if ( pShop->object[selection] == 1 )
              {
                pShop->object[selection] = 0;
                pShop->object_count--;
              }

              /* �Y�S���, �h�]�w�� */
              else
              {
                /* �Y��諸�ƥئh�L MAX_TRADE �h���B�z */
                if ( pShop->object_count < MAX_TRADE )
                {
                  /* �Y�o�ت��~���i�H�c��, �]���B�z�� */
                  if ( item_type[selection].sell == 1 )
                  {
                    pShop->object[selection] = 1;
                    pShop->object_count++;
                  }
                }
                else
                {
                   warning_beep();
                }
              }
            }

            /* �ݬݿ�ܶ��جO�_�W�X�F�d�� */
            check_boundary( 0 , MAX_ITEM - 1 , &selection );

            /* ��ܬO�_���~�i�H�Q�c�� */
            show_shop_object( pShop );

            /* ��ܥ����i�H�c�檫�~�������W�� */
            show_shop_object_title( selection );

          } while ( control_key != RETURN_RETURN
              && control_key != RETURN_TAB );

         /* �M���c�檫�~����ܥ��� */
         show_shop_object_title( MAX_ITEM );

         execute = 0;
         break;

        }

      /* �]�w�ө��}�����ɶ� �d�� 0 - 24 */
      case 3 :

        pString->x_pos           = SHOP_X + 12;
        pString->y_pos           = SHOP_Y + 11;
        pString->x_len           = 2;
        pString->y_len           = 1;
        pString->save_x_cursor   = 0;
        pString->save_y_cursor   = 0;
        for ( loop = 0 ; loop < 3; loop++ ) *(pString->address+loop) = '\x0';
        number_to_string( pShop->openhour , pString->address );

        get_string( pString );
        pShop->openhour = atoi(pString->address );

        /* �ˬd�ɶ��O�_�W�X�d�� */
        if ( pShop->openhour < 0  ) pShop->openhour = 0;
        if ( pShop->openhour > 24 ) pShop->openhour = 0;

        number_to_string( pShop->openhour , pString->address );
        align_word( pString->address , 2 );
        print_string( SHOP_X + 12 , SHOP_Y + 11, SHOP_COL , pString->address );

        execute = 0;
        break;

      /* �]�w�ө��������ɶ� �d�� 0 - 24 */
      case 4 :

        pString->x_pos           = SHOP_X + 29;
        pString->y_pos           = SHOP_Y + 11;
        pString->x_len           = 2;
        pString->y_len           = 1;
        pString->save_x_cursor   = 0;
        pString->save_y_cursor   = 0;
        for ( loop = 0 ; loop < 3; loop++ ) *(pString->address+loop) = '\x0';
        number_to_string( pShop->closehour , pString->address );

        get_string( pString );
        pShop->closehour = atoi(pString->address );

        /* �ˬd�ɶ��O�_�W�X�d�� */
        if ( pShop->closehour <  0 ) pShop->closehour = 0;
        if ( pShop->closehour > 24 ) pShop->closehour = 0;

        number_to_string( pShop->closehour , pString->address );
        align_word( pString->address , 2 );
        print_string( SHOP_X + 29 , SHOP_Y + 11, SHOP_COL , pString->address );

        execute = 0;
        break;

      /* �]�w�ө��R�J���Q�q �d�� 0 - 999 */
      case 5 :

        pString->x_pos           = SHOP_X + 46;
        pString->y_pos           = SHOP_Y + 11;
        pString->x_len           = 3;
        pString->y_len           = 1;
        pString->save_x_cursor   = 0;
        pString->save_y_cursor   = 0;
        for ( loop = 0 ; loop < 4; loop++ ) *(pString->address+loop) = '\x0';
        number_to_string( pShop->buyprofit , pString->address );

        get_string( pString );
        pShop->buyprofit = atoi(pString->address );

        /* �ˬd�O�_�W�X�d�� */
        if ( pShop->buyprofit <  0 ) pShop->buyprofit = 0;

        number_to_string( pShop->buyprofit , pString->address );
        align_word( pString->address , 3 );
        print_string( SHOP_X + 46 , SHOP_Y + 11, SHOP_COL , pString->address );

        execute = 0;
        break;

      /* �]�w�ө���X���Q�q �d�� 0 - 999 */
      case 6 :

        pString->x_pos           = SHOP_X + 64;
        pString->y_pos           = SHOP_Y + 11;
        pString->x_len           = 3;
        pString->y_len           = 1;
        pString->save_x_cursor   = 0;
        pString->save_y_cursor   = 0;
        for ( loop = 0 ; loop < 4; loop++ ) *(pString->address+loop) = '\x0';
        number_to_string( pShop->sellprofit , pString->address );

        get_string( pString );
        pShop->sellprofit = atoi(pString->address );

        /* �ˬd�O�_�W�X�d�� */
        if ( pShop->sellprofit <  0 ) pShop->sellprofit = 0;

        number_to_string( pShop->sellprofit , pString->address );
        align_word( pString->address , 3 );
        print_string( SHOP_X + 64 , SHOP_Y + 11, SHOP_COL , pString->address );

        execute = 0;

        break;

     /* �s�� */
     case 7 :

       fclose( pFile->filehandler );
       pFile->filehandler = fopen ( pFile->filename ,"w+" );

       do_save_shop( pShop , pFile->filehandler );
       fclose( pFile->filehandler );
       return;

     /* ��� */
     case 8 :

       /* �Y�O�s���ɮ׫h�R�� , ���M�h����. */

       if ( pFile->information == 1 ) delete_null_file( pFile );
       else fclose( pFile->filehandler );

    }
  } while ( execute != 8 );

  return;
}

/* �x�s�ө��ɮ׮榡 */
void do_save_shop( SHOP_INFO * pShop , FILE * fp )
{
  fprintf( fp , "#SHOPS\n"                                 );
  fprintf( fp , "Keeper          %d\n" , pShop->keeper     );

  {
    int loop;
    int count;

    fprintf( fp , "Object          "                         );

    for ( loop = 0, count = 0; loop < 20; loop++ )
    {
      if ( pShop->object[ loop ] != 0 && count < MAX_TRADE )
      {
        if ( count != 0 ) fprintf( fp , " " );
        fprintf( fp , "%s" , item_type[ loop ].item_string_name );
        count++;
      }
    }

    if ( count == 0 ) fprintf( fp , "0" );
    fprintf( fp , "\n"                                       );
  }

  fprintf( fp , "OpenHour        %d\n" , pShop->openhour   );
  fprintf( fp , "CloseHour       %d\n" , pShop->closehour  );
  fprintf( fp , "SellProfit      %d\n" , pShop->sellprofit );
  fprintf( fp , "BuyProfit       %d\n" , pShop->buyprofit  );
  fprintf( fp , "End\n"                                    );

  return;
}

/* �]�w�ө����_�l�� */
void set_shop_default( SHOP_INFO * pShop )
{
  int loop;

  pShop->keeper       = 0;
  pShop->openhour     = 0;
  pShop->closehour    = 23;
  pShop->buyprofit    = 100;
  pShop->sellprofit   = 120;
  pShop->object_count = 0;
  for ( loop = 0 ; loop < MAX_ITEM ; loop++ ) pShop->object[ loop ] = 0;

  return;
}

/* �q�ɮ׸��J�ө��榡 */
int load_shop( SHOP_INFO * pShop )
{
  char   word[ MAX_WORD_LENGTH ];
  char * pWord;
  int    Match;

  pWord = word ;

  for ( ; ; )
  {
    fread_word( pShop->pFile , pWord );
    if ( pShop->pFile->status == 1 ) return FALSE;
    Match = FALSE;

    switch( pWord[0] )
    {
      case '*' :

        fread_to_eol( pShop->pFile );
        Match = TRUE;
        break;

      case '#' :

        if ( !strcmp( pWord , "#SHOPS" ) )
        {
          Match = TRUE;
          break;
        }

       break;

     case 'B' :

       /* �R�J�Q�q �d�� 0 - 999 */
       if ( !strcmp( pWord , "BuyProfit" ) )
       {
          pShop->buyprofit = fread_number( pShop->pFile );

          /* �ˬd�O�_�W�X�d�� */
          if ( pShop->pFile->status == 1                      ) return FALSE;
          if ( pShop->buyprofit < 0 || pShop->buyprofit > 999 ) return FALSE;

         Match = TRUE;
         break;
       }

       break;

     case 'C' :

       /* �������ɶ� �d�� 0 - 24 */
       if ( !strcmp( pWord , "CloseHour" ) )
       {
          pShop->closehour = fread_number( pShop->pFile );

          /* �ˬd�O�_�W�X�d�� */
          if ( pShop->pFile->status == 1                     ) return FALSE;
          if ( pShop->closehour < 0 || pShop->closehour > 24 ) return FALSE;


         Match = TRUE;
         break;
       }

       break;

     case 'E' :

       if ( !strcmp( pWord , "End" ) )
       {
         if ( fread_if_eof( pShop->pFile ) ) return TRUE;
         else                                return FALSE;
       }

       break;

     case 'K' :

       if ( !strcmp( pWord , "Keeper" ) )
       {
          pShop->keeper = fread_number( pShop->pFile );

          /* �ˬd�O�_�W�X�d�� */
          if ( pShop->pFile->status == 1 ) return FALSE;
          if ( pShop->keeper < 0 )         return FALSE;

          Match = TRUE;
          break;
       }

       break;

     case 'O' :

       /* �}�����ɶ� �d�� 0 - 24 */
       if ( !strcmp( pWord , "OpenHour" ) )
       {
          pShop->openhour = fread_number( pShop->pFile );
          if ( pShop->pFile->status == 1 ) return FALSE;

          /* �ˬd�O�_�W�X�d�� */
          if ( pShop->openhour < 0 || pShop->openhour > 24 ) return FALSE;

          Match = TRUE;
          break;
       }

       /* �c�檫�~������, �W�L MAX_TRADE �Ӽƪ��t�Τ��z�| */
       if ( !strcmp( pWord , "Object" ) )
       {
          int iTrade = 0;
          int object;

          while ( iTrade < MAX_TRADE )
          {
            object = fread_number( pShop->pFile );
            if ( pShop->pFile->status == 1         ) return FALSE;
            if ( object < 0 && object > MAX_ITEM   ) return FALSE;

            if ( object != 0 )
            {
              if ( item_type[ object - 1 ].sell == 0 ) return FALSE;
              pShop->object[ object-1 ] = 1;
              pShop->object_count++;
            }

            iTrade++;
            if ( fread_if_eol( pShop->pFile ) ) break;
          }

          fread_to_eol( pShop->pFile );
          Match = TRUE;
          break;
       }

       break;

     case 'S' :

       /* ��X�Q�q �d�� 0 - 999 */
       if ( !strcmp( pWord , "SellProfit" ) )
       {
          pShop->sellprofit = fread_number( pShop->pFile );
          if ( pShop->pFile->status == 1 ) return FALSE;

          /* �ˬd�O�_�W�X�d�� */
          if ( pShop->sellprofit < 0 || pShop->sellprofit > 999 )
            return FALSE;

         Match = TRUE;
         break;
       }

       break;

    }
    if ( !Match ) return FALSE;
  }
}
