#include "edit.h"

char *       fread_alpha        ( FILE_INFO * );
int          symbol_lookup      ( char * , int * );
FILE_INFO    file_structure;


/* �R���Ū��ɮ� */
void delete_null_file( FILE_INFO * pFile )
{

  if ( fgetc( pFile->filehandler ) !=  EOF )
  {
    fclose( pFile->filehandler );
  }

  else
  {

    fclose( pFile->filehandler );
    remove( pFile->filename );

    print_string( 20 , 23 , LIGHTGREEN
     , "�Ū��ɮ�, �ҥH�R��, ���������~��.\n" );

    get_control_key();
  }

  return;
}

/* ��J�ɦW

�����ޤJ�ѼƤ@�r�� lastname --> ���ɦW

*/

#define FILE_X_POS      20
#define FILE_Y_POS      1
#define PRINT_LEN       ( FILE_LENGTH + 4 )
#define FILE_PER_COL    ( 80 / PRINT_LEN )
#define MAX_LINE        20

/* Ū���ɮת��W�r , �L�|�Ǧ^�@���ɮ׸�ƪ����c.
   �����ޤJ�ѼƤ@�r�� lastname ���ɦW .

    �Ǧ^�� :

    filehandler ------> �ɮת�Ū�����X.
    filename    ------> �ɮת��W�r.
    information ------> 0 �ɮפw�g�s�b�ӥB�i�HŪ�g. ���ɮ� .
                        1 �ɮפ��s�b���O�i�HŪ�g. �s�ɮ�.
                       -1 �ɮפ��s�b, �B�L�k�}��.
                       -2 �ɮצs�b, ���O�L�kŪ�g.
                       -3 �ɮצs�b, ���O�L�k�}��.

*/

FILE_INFO * get_file_name( char * lastname )
{
   STRING_INFO     pString;
   STRING_INFO   * filename_info;
   FILE_INFO     * file_pointer;
   char            filename[ 100 ];
   int             loop;
   int             cursor_x;
   int             cursor_y;
   DIR           * reading;
   struct dirent * next;

   /* �M���ù� */
   clear_screen();

   /* �C�L�������ɮ� */
   reading = opendir ( LOCAL_DIRECTORY );

   if ( reading )
   {
     loop = 0;
     cursor_y = FILE_Y_POS + 2;

     while ( ( next = readdir( reading ) ) != NULL
       && loop < FILE_PER_COL * MAX_LINE  )
     {

       if ( strlen( next->d_name ) < PRINT_LEN - 1
         && string_compare( next->d_name , lastname ) )
       {

         cursor_x = ( PRINT_LEN * ( loop % FILE_PER_COL ) ) + 1;
         print_string( cursor_x , cursor_y , LIGHTGREEN , next->d_name );
         loop++;

         /* �Ҽ{�촫�� */
         if ( ( loop % FILE_PER_COL ) == 0 ) cursor_y++;

       }
     }

     /* ���� DIR �޹D */
     closedir( reading );
   }

   sprintf( filename , "�п�J�ɦW, ���ɦW�O %s : " , lastname );
   print_string( FILE_X_POS , FILE_Y_POS , LIGHTGREEN , filename );

   filename_info = &pString;
   filename_info->x_pos           = FILE_X_POS + 28 ;
   filename_info->y_pos           = FILE_Y_POS ;
   filename_info->x_len           = FILE_LENGTH;
   filename_info->y_len           = 1;
   filename_info->front_color     = LIGHTBLUE;
   filename_info->back_color      = LIGHTGRAY;
   filename_info->save_x_cursor   = 0;
   filename_info->save_y_cursor   = 0;
   filename_info->org_front_color = BLUE;
   filename_info->org_back_color  = BLACK;
   filename_info->smash           = SMASH_NO_EXECUTE;
   filename_info->number          = NUMBER_ACCEPT;
   filename_info->address         = filename;

   for ( loop = 0 ; loop < 100 ; loop++ ) filename[ loop ] = '\x0';

   /* Ū���ɮת��W�r���r�� */
   get_string( filename_info );

   /* �]�w�ɮ׵��c����� */
   file_pointer = &file_structure;
   strcat( filename , lastname );
   strcpy( file_pointer->filename , filename );
   file_pointer->filehandler = NULL;
   file_pointer->information = 0;

   /* �ɮצW�٬��Ŧr�� */
   if ( !strcmp( file_pointer->filename , lastname ) )
   {
     file_pointer->information = -4;
     show_error( " �A���ɮצW�ٹL�u, �t�Τ��ӻ{.\n" );
     clear_screen();
     return file_pointer;
   }

   /* �����ɮ׬O�_�s�b -1 �N�����s�b */
   if ( access( filename , 0 ) == -1 )
   {
     /* ���}�ɸոլ�, �Y�L�k�}�ɫh�L�kŪ�g, �Ǧ^ -1 */
     /* �i�H�}�ɫh�Ǧ^ 1, �N�����s�b���O�i�HŪ�g */

     if ( ( file_pointer->filehandler = fopen( filename , "a+" ) ) == NULL )
     {
       file_pointer->filehandler = NULL;
       file_pointer->information = -1;
     }

     else
     {
       file_pointer->information  = 1;
     }
   }

   /* �ɮפw�g�s�b������ */

   else
   {
     /* �Y�L�kŪ�g�h�Ǧ^ -2 , �N���ɮצs�b���O�L�kŪ�g */

     if ( access( filename , 6 ) == -1 )
     {
       file_pointer->filehandler = NULL;
       file_pointer->information = -2;
     }
     else
     {
       /* �}�ɶ}�}��, �����\�Ǧ^ -3 , �N���ɮצs�b���O�L�k�}�� */

       if ( ( file_pointer->filehandler = fopen( filename , "r+" ) ) == NULL )
       {
         file_pointer->filehandler = NULL;
         file_pointer->information = -3;
       }
     }
   }

  if (      file_pointer->information == -1 )
    show_error( " �A���ɮפ��s�b, �B�L�k�}��.\n" );

  else if ( file_pointer->information == -2 )
    show_error( " �A���ɮצs�b���O�L�kŪ�g.\n" );

  else if ( file_pointer->information == -3 )
    show_error( " �A���ɮצs�b, ���O�L�k�}��.\n" );

  else if ( file_pointer->information == -4 )
    show_error( " �A���ɮצW�ٹL�u, �t�Τ��ӻ{.\n" );

  clear_screen();

  return file_pointer;
}


#undef FILE_X_POS
#undef FILE_Y_POS
#undef PRINT_LEN
#undef FILE_PER_COL
#undef MAX_LINE

/* ���լO�_��F�ɮש��� */
int fread_if_eof( FILE_INFO *pFile )
{
  char character;

  do
  {
    if ( ( character = getc( pFile->filehandler ) ) == EOF ) return TRUE;
  }
  while ( character == ' ' || character == '\n' || character == '\r' );

  return FALSE;
}


/* ���լO�_�F���ɮ׳o�@�檺���� */
int fread_if_eol( FILE_INFO *pFile )
{
  char character;

  do
  {
    character = getc( pFile->filehandler );
  }
  while ( character == ' ' );

  if ( character == '\n' || character == '\r' )
  {
    ungetc( character , pFile->filehandler );
    return TRUE;
  }

  ungetc( character , pFile->filehandler );
  return FALSE;
}

/* Ū����� */
void fread_to_eol( FILE_INFO * pFile )
{

  char c;

  do
  {
    c = getc( pFile->filehandler );
  }
  while ( c != '\n' && c != '\r' );

  do
  {
    c = getc( pFile->filehandler );
  }
  while ( c == '\n' || c == '\r' );

  ungetc( c, pFile->filehandler );
  return;

}

/* �q�ɮפ�Ū���@�ӳ�r */
void fread_word( FILE_INFO * pFile , char * address )
{
    char *pword;
    char character;
    int  len;

    /* ����e�����ť�Ū�� */

    do
    {
      if ( ( character  = getc( pFile->filehandler ) ) == EOF )
      {
        pFile->status = 1;
        return;
      }
    }
    while ( isSpace( character ) );
    ungetc( character , pFile->filehandler );

    for ( pword = address , len = 0; len < MAX_WORD_LENGTH ; pword++ , len++)
    {

      if ( ( *pword = getc( pFile->filehandler ) ) == EOF )
      {
        pFile->status = 1;
        return;
      }

      if ( isSpace( *pword ) )
      {
        ungetc( *pword , pFile->filehandler );
        *pword        = '\x0';
        return;
      }
    }

    pFile->status = 1;
    return;
}

/* �q�ɮ�Ū���@�ӼƦr */

int fread_number( FILE_INFO *pFile )
{
  int  number;
  int  sign;
  char c;

  do
  {
    if ( ( c = getc( pFile->filehandler ) ) == EOF )
    {
      pFile->status = 1;
      return -1;
    }
  }
  while ( isSpace( c ) );

  number = 0;
  sign   = FALSE;

  if ( c == '+' || c == '|' )
  {
     if ( ( c = getc( pFile->filehandler ) ) == EOF )
     {
       pFile->status = 1;
       return -1;
     }
  }

  else if ( c == '-' )
  {
    sign = TRUE;
    if ( ( c = getc( pFile->filehandler ) ) == EOF )
    {
      pFile->status = 1;
      return -1;
    }
  }

  if ( !isdigit( c ) )
  {
    ungetc( c , pFile->filehandler );
    if ( !isalpha( c ) )
    {
      pFile->status = 1;
      return -1;
    }

    if ( symbol_lookup( fread_alpha( pFile )
       , &number) == FALSE)
    {
      pFile->status = 1;
      return -1;
    }

    if ( ( c = getc( pFile->filehandler ) ) == EOF )
    {
      pFile->status = 1;
      return -1;
    }

    ungetc( c, pFile->filehandler );

    if ( c != '+' && c != '-' && c != '|' ) return number;
    else return ( number | fread_number( pFile ) );
  }

  while ( isdigit( c ) )
  {
    number = number * 10 + c - '0';

    if ( ( c  = getc( pFile->filehandler ) ) == EOF )
    {
      pFile->status = 1;
      return -1;
    }
  }

  if ( sign != 0 ) number = 0 - number;

       if ( c == '|' ) number = number | fread_number( pFile );
  else if ( c != ' ' ) ungetc( c, pFile->filehandler );

  return number;
}

/* Ū���r��`�ƱM�Ϊ���� */

char *fread_alpha( FILE_INFO * pFile)
{
  static char word[ MAX_WORD_LENGTH ];
  char   *pword;
  char   cEnd;
  int    len;

  do
  {
    if ( ( cEnd = getc( pFile->filehandler ) ) == EOF )
    {
      pFile->status = 1;
      return NULL;
    }
  }
  while ( isSpace( cEnd ) );

  ungetc( cEnd , pFile->filehandler );
  pword = word;

  for ( len = 0 , pword = word ; len < MAX_WORD_LENGTH; pword++ )
  {
    if ( ( *pword = getc( pFile->filehandler ) ) == EOF )
    {
      pFile->status = 1;
      return NULL;
    }

    if (  *pword == ' ' || *pword == '|' || *pword == '\r'
      || *pword == '\n' || *pword == '-' || *pword == '+' )
    {
      ungetc( *pword , pFile->filehandler );
      *pword = '\x0';
      return word;
    }
  }

  pFile->status = 1;
  return NULL;
}

/* �ˬd�r��`�ƪ� */
int  symbol_lookup( char * symbol, int * num )
{
  int loop;

  if ( symbol == '\x0' || !isalpha( symbol[0] ) ) return FALSE;

  for ( loop = 0 ; const_table[loop].string[0] != '\x0' ; loop++ )
  {
    if ( !strcmp( const_table[loop].string , symbol ) )
    {
       *num = const_table[loop].value;
       return TRUE;
    }
  }

  return FALSE;
}

/* �q�ɮפ�Ū���@�Ӧr�� */
void fread_string( FILE_INFO *pFile , STRING_INFO * pString )
{

  char   character;
  int    cursor_x;
  int    cursor_y;
  int    fChinese;
  int    fLast;

  /* ���M���ت����r�� */
  clear_string( pString );

  /* ����ť�Ū�� */
  do
  {
    if ( ( character = getc( pFile->filehandler ) ) == EOF )
    {
      pFile->status = 1;
      return;
    }

  } while ( isSpace( character ) );

  ungetc( character , pFile->filehandler );

  cursor_x = 0;
  cursor_y = 0;
  fChinese = FALSE;
  fLast    = FALSE;

  for ( ; ; )
  {
    fLast = fChinese;

    /* Ū���r������Ѧr���� */
    character = getc( pFile->filehandler );

    /* �O���O����r */
    if ( fChinese )
    {
      fChinese = FALSE;
    }

    else
    {
      if ( character < 0 )  fChinese = TRUE;
      else                  fChinese = FALSE;
    }

    switch ( character )
    {

      default :

        if ( ( ++cursor_x ) > pString->x_len )
        {
          pFile->status = 1;
          return;
        }

        /* Ū���@�Ӧr����S�w����} */
        *( pString->address + ( cursor_y * ( pString->x_len + 1 ) )
          + cursor_x - 1 ) = character;

        break;

      case EOF:

        pFile->status = 1;
        return;

      case '\r':

        break;

      case '\n':

        if ( ++cursor_y > pString->y_len )
        {
          pFile->status = 1;
          return;
        }

        cursor_x = 0;
        break;

      case '~' :

        if ( fLast )
        {
          if ( ( ++cursor_x ) > pString->x_len )
          {
            pFile->status = 1;
            return;
          }

          /* Ū���@�Ӧr����S�w����} */
          *( pString->address + ( cursor_y * ( pString->x_len + 1 ) )
            + cursor_x - 1 ) = character;

          break;
        }

        return;
    }
  }
}
