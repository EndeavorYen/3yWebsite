#include "edit.h"

void    	mem_error		( void );
STRING_INFO  *  malloc_string           ( void );

ROOM_INFO * pRoom;

void initial_room( void )
{

  int 	loop;

  /* �t�m�ж����c���O���� */
  if ( ( pRoom = ( ROOM_INFO * ) malloc( sizeof( ROOM_INFO ) ) ) == NULL )
    mem_error();

  /* �t�m�ж����ж����X�r�ꪺ�Ŷ� */
  pRoom->pVnum = malloc_string();

  /* �]�w�ж����X�r��_�ҭ� */
  pRoom->pVnum->x_pos           = ROOM_X + 13;
  pRoom->pVnum->y_pos           = ROOM_Y + 3;
  pRoom->pVnum->x_len           = 5;
  pRoom->pVnum->y_len           = 1;
  pRoom->pVnum->front_color     = BLUE;
  pRoom->pVnum->back_color      = LIGHTGRAY;
  pRoom->pVnum->org_front_color = ROOM_COL;
  pRoom->pVnum->org_back_color  = BLACK;
  pRoom->pVnum->smash           = SMASH_EXECUTE;
  pRoom->pVnum->number          = NUMBER_ONLY;
  pRoom->pVnum->address         = pRoom->aVnum;
  clear_string( pRoom->pVnum );

  /* �t�m�ж����ж��W�٦r�ꪺ�Ŷ� */
  pRoom->pName = malloc_string();

  /* �]�w�ж��W�٦r��_�ҭ� */
  pRoom->pName->x_pos           = ROOM_X + 30;
  pRoom->pName->y_pos           = ROOM_Y +  3;
  pRoom->pName->x_len           = 40;
  pRoom->pName->y_len           =  1;
  pRoom->pName->front_color     = BLUE;
  pRoom->pName->back_color      = LIGHTGRAY;
  pRoom->pName->org_front_color = ROOM_COL;
  pRoom->pName->org_back_color  = BLACK;
  pRoom->pName->smash           = SMASH_EXECUTE;
  pRoom->pName->number          = NUMBER_ACCEPT;
  pRoom->pName->address         = pRoom->name;
  clear_string( pRoom->pName );

  /* �t�m�ж����ж��y�z�r�ꪺ�Ŷ� */
  pRoom->pDesc = malloc_string();

  /* �]�w�ж��y�z�r��_�ҭ� */
  pRoom->pDesc->x_pos           = ROOM_X + 7;
  pRoom->pDesc->y_pos           = ROOM_Y + 5;
  pRoom->pDesc->x_len           = 68;
  pRoom->pDesc->y_len           =  8;
  pRoom->pDesc->front_color     = BLUE;
  pRoom->pDesc->back_color      = LIGHTGRAY;
  pRoom->pDesc->org_front_color = ROOM_COL;
  pRoom->pDesc->org_back_color  = BLACK;
  pRoom->pDesc->smash           = SMASH_EXECUTE;
  pRoom->pDesc->number          = NUMBER_ACCEPT;
  pRoom->pDesc->address         = pRoom->description;
  clear_string( pRoom->pDesc );

  /* �t�m�ж������ӥX�f�����c�O���� */
  for ( loop = 0; loop < 6; loop++ )
  {
    /* �t�m�C�@�ӥX�f���c���O���� */
    pRoom->exit[loop] = ( EXIT_INFO * ) malloc( sizeof( EXIT_INFO ) );
    if ( pRoom->exit[loop] == NULL ) mem_error();

    /* �t�m�C�@�ӥX�f�ж����r��Ŷ� */
    pRoom->exit[loop]->pRoom = malloc_string();

    /* �]�w�ж����X�r��_�ҭ� */
    pRoom->exit[loop]->pRoom->x_pos           = EXIT_X + 22;
    pRoom->exit[loop]->pRoom->y_pos           = EXIT_Y + 6;
    pRoom->exit[loop]->pRoom->x_len           = 5;
    pRoom->exit[loop]->pRoom->y_len           = 1;
    pRoom->exit[loop]->pRoom->front_color     = BLUE;
    pRoom->exit[loop]->pRoom->back_color      = LIGHTGRAY;
    pRoom->exit[loop]->pRoom->org_front_color = EXIT_COL;
    pRoom->exit[loop]->pRoom->org_back_color  = BLACK;
    pRoom->exit[loop]->pRoom->smash           = SMASH_EXECUTE;
    pRoom->exit[loop]->pRoom->number          = NUMBER_ONLY;
    pRoom->exit[loop]->pRoom->address         = pRoom->exit[loop]->aRoom;
    clear_string( pRoom->exit[loop]->pRoom );

    /* �t�m�C�@�ӥX�f�_�ͪ��r��Ŷ� */
    pRoom->exit[loop]->pKey = malloc_string();

    /* �]�w�ж��_�͸��X�r��_�ҭ� */
    pRoom->exit[loop]->pKey->x_pos           = EXIT_X + 12;
    pRoom->exit[loop]->pKey->y_pos           = EXIT_Y + 9;
    pRoom->exit[loop]->pKey->x_len           = 5;
    pRoom->exit[loop]->pKey->y_len           = 1;
    pRoom->exit[loop]->pKey->front_color     = BLUE;
    pRoom->exit[loop]->pKey->back_color      = LIGHTGRAY;
    pRoom->exit[loop]->pKey->org_front_color = EXIT_COL;
    pRoom->exit[loop]->pKey->org_back_color  = BLACK;
    pRoom->exit[loop]->pKey->smash           = SMASH_EXECUTE;
    pRoom->exit[loop]->pKey->number          = NUMBER_ONLY;
    pRoom->exit[loop]->pKey->address         = pRoom->exit[loop]->aKey;
    clear_string( pRoom->exit[loop]->pKey );

    /* �t�m�C�@�ӥX�f����r���r��Ŷ� */
    pRoom->exit[loop]->pKeyword = malloc_string();

    /* �]�w�ж��X�f����r�r��_�ҭ� */
    pRoom->exit[loop]->pKeyword->x_pos           = EXIT_X + 9;
    pRoom->exit[loop]->pKeyword->y_pos           = EXIT_Y + 11;
    pRoom->exit[loop]->pKeyword->x_len           = 40;
    pRoom->exit[loop]->pKeyword->y_len           = 1;
    pRoom->exit[loop]->pKeyword->front_color     = BLUE;
    pRoom->exit[loop]->pKeyword->back_color      = LIGHTGRAY;
    pRoom->exit[loop]->pKeyword->org_front_color = EXIT_COL;
    pRoom->exit[loop]->pKeyword->org_back_color  = BLACK;
    pRoom->exit[loop]->pKeyword->smash           = SMASH_EXECUTE;
    pRoom->exit[loop]->pKeyword->number          = NUMBER_ACCEPT;
    pRoom->exit[loop]->pKeyword->address = pRoom->exit[loop]->keyword;

    /* �t�m�C�@�ӥX�f�y�z���r��Ŷ� */
    pRoom->exit[loop]->pDesc = malloc_string();

    /* �]�w�ж��X�f�y�z�r�r��_�ҭ� */
    pRoom->exit[loop]->pDesc->x_pos           = EXIT_X + 9;
    pRoom->exit[loop]->pDesc->y_pos           = EXIT_Y + 13;
    pRoom->exit[loop]->pDesc->x_len           = 40;
    pRoom->exit[loop]->pDesc->y_len           = 1;
    pRoom->exit[loop]->pDesc->front_color     = BLUE;
    pRoom->exit[loop]->pDesc->back_color      = LIGHTGRAY;
    pRoom->exit[loop]->pDesc->org_front_color = EXIT_COL;
    pRoom->exit[loop]->pDesc->org_back_color  = BLACK;
    pRoom->exit[loop]->pDesc->smash           = SMASH_EXECUTE;
    pRoom->exit[loop]->pDesc->number          = NUMBER_ACCEPT;
    pRoom->exit[loop]->pDesc->address = pRoom->exit[loop]->description;

  }

  /* �t�m�ж��������B�~�y�z�����c���O���� */
  for ( loop = 0; loop < 5; loop++ )
  {
    pRoom->desc[loop] = ( ROOM_DESC * ) malloc ( sizeof( ROOM_DESC ) );
    if ( pRoom->desc[loop] == NULL ) mem_error();

    /* �t�m�ж��B�~�y�z����r�r��Ŷ� */
    pRoom->desc[loop]->pKeyword = malloc_string();

    /* �]�w�ж�����r�r��_�ҭ� */
    pRoom->desc[loop]->pKeyword->x_pos           = DESC_X + 9;
    pRoom->desc[loop]->pKeyword->y_pos           = DESC_Y + 5;
    pRoom->desc[loop]->pKeyword->x_len           = 30;
    pRoom->desc[loop]->pKeyword->y_len           = 1;
    pRoom->desc[loop]->pKeyword->front_color     = BLUE;
    pRoom->desc[loop]->pKeyword->back_color      = LIGHTGRAY;
    pRoom->desc[loop]->pKeyword->org_front_color = DESC_COL;
    pRoom->desc[loop]->pKeyword->org_back_color  = BLACK;
    pRoom->desc[loop]->pKeyword->smash           = SMASH_EXECUTE;
    pRoom->desc[loop]->pKeyword->number          = NUMBER_ACCEPT;
    pRoom->desc[loop]->pKeyword->address  = pRoom->desc[loop]->keyword;

    /* �]�w�ж�����r�r��_�ҭ� */
    pRoom->desc[loop]->pDesc = malloc_string();

    /* �]�w�ж�����r�r��_�ҭ� */
    pRoom->desc[loop]->pDesc->x_pos           = DESC_X + 7;
    pRoom->desc[loop]->pDesc->y_pos           = DESC_Y + 7;
    pRoom->desc[loop]->pDesc->x_len           = 65;
    pRoom->desc[loop]->pDesc->y_len           = 8;
    pRoom->desc[loop]->pDesc->front_color     = BLUE;
    pRoom->desc[loop]->pDesc->back_color      = LIGHTGRAY;
    pRoom->desc[loop]->pDesc->org_front_color = DESC_COL;
    pRoom->desc[loop]->pDesc->org_back_color  = BLACK;
    pRoom->desc[loop]->pDesc->smash           = SMASH_EXECUTE;
    pRoom->desc[loop]->pDesc->number          = NUMBER_ACCEPT;
    pRoom->desc[loop]->pDesc->address  = pRoom->desc[loop]->description;

  }

  return;
}

void mem_error( void )
{

  perror( "Cannot allocate memory." );
  exit( 0 );

}

STRING_INFO * malloc_string( void )
{

  STRING_INFO * temp;

  temp = ( STRING_INFO * ) malloc( sizeof( STRING_INFO ) );
  if ( temp == NULL )
  {
    mem_error();
    return NULL;
  }

  else
  {
   return temp;
  }
}
