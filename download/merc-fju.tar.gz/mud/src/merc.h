/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*  �o�O�ѻ��j�ƾǨt�s�@�s�Ҽ��g���C���M�D��� merc ��s�ӨӡM�Ҧ������v    *
*  �N�|�Q�O�d�M���w��j�a�ק�M���ڭ̤]�Ʊ�A�̤]�ണ�ѵ��j�a�M�Ҧ�����    *
*  �~�欰�N���Q���\�C                                                      *
*                                                                          *
*  paul@mud.ch.fju.edu.tw                                                  *
*                                                                          *
***************************************************************************/

/* �ФŦۦ��� */
#define MUD_VERSION             "99-10-11"

#define STRUCT_NOTE_DATA        20
#define STRUCT_BAN_DATA         21
#define STRUCT_EXTRA_DESCR_DATA 22
#define STRUCT_DESCRIPTOR_DATA  23
#define STRUCT_CMD_DATA         24
#define STRUCT_AREA_DATA        25
#define STRUCT_HELP_DATA        26
#define STRUCT_MOB_INDEX_DATA   27
#define STRUCT_OBJ_INDEX_DATA   28
#define STRUCT_AFFECT_DATA      29
#define STRUCT_RESET_DATA       30
#define STRUCT_ROOM_INDEX_DATA  31
#define STRUCT_EXIT_DATA        32
#define STRUCT_SHOP_DATA        33
#define STRUCT_CHAR_DATA        34
#define STRUCT_OBJ_DATA         35
#define STRUCT_MPROG_DATA       36
#define STRUCT_SYMBOL_DATA      37
#define STRUCT_PC_DATA          38
#define STRUCT_SKILL_DATA       39
#define STRUCT_ALIAS_DATA       40
#define STRUCT_SOCIAL_DATA      41
#define STRUCT_GAMBLE_DATA      42
#define STRUCT_TEACH_DATA       43
#define STRUCT_ENABLE_DATA      44
#define STRUCT_XNAME_DATA       45
#define STRUCT_MPROG_ACT_LIST   46
#define STRUCT_SECTOR_DATA      47
#define STRUCT_CLASS_DATA       48
#define STRUCT_LIMIT_DATA       49
#define STRUCT_ADDRESS_DATA     50
#define STRUCT_BUS_DATA         51
#define STRUCT_NET_DATA         52
#define STRUCT_CLUB_DATA        53
#define STRUCT_DAMAGE_DATA      54
#define STRUCT_PW_DATA          55
#define STRUCT_GR_DATA          56
#define STRUCT_CACHET_DATA      57
#define STRUCT_LIQ_DATA         58
#define STRUCT_RESTRICT_DATA    59
#define STRUCT_JOB_DATA         60
#define STRUCT_ENROLL_DATA      61
#define STRUCT_QUEST_DATA       62
#define STRUCT_ENEMY_DATA       63
#define STRUCT_QUEST_INFO       64
#define STRUCT_IMMLIST_DATA     65
#define STRUCT_FRIEND_DATA      66
#define STRUCT_SHIP_DATA        67
#define STRUCT_FAILCODE_DATA    68
#define STRUCT_BOARD_DATA       69
#define STRUCT_POST_DATA        70
#define STRUCT_HERO_DATA        71
#define STRUCT_EFFECT_DATA      72
#define STRUCT_MESSAGE_DATA     73
#define STRUCT_ANGEL_DATA       74
#define STRUCT_SALE_DATA        75
#define STRUCT_FIGHT_DATA       76
#define STRUCT_SERIAL_DATA      77
#define STRUCT_TOP_DATA         78
#define STRUCT_WANTED_DATA      79
#define STRUCT_VOTE_DATA        80
#define STRUCT_IP_DATA          81
#define STRUCT_JOKE_DATA        82
#define STRUCT_TRACE_DATA       83
#define STRUCT_VARIABLE_DATA    84
#define STRUCT_TICKET_DATA      85
#define STRUCT_ORDER_DATA       86
#define STRUCT_GIFT_DATA        87
#define STRUCT_STAMP_DATA       88
#define STRUCT_MINERAL_DATA     89
#define STRUCT_MINE_DATA        90
#define STRUCT_EVENT_DATA       91
#define STRUCT_BASIC_DATA       92
#define STRUCT_BOUNTY_DATA      93
#define STRUCT_SERVER_DATA      94
#define STRUCT_QUESTION_DATA    95
#define STRUCT_ANSWER_DATA      96
#define STRUCT_ENQUIRE_DATA     97
#define STRUCT_FILE_DATA        98
#define STRUCT_GREETING_DATA    99

#define MAX_QUESTION             5
#define MAX_PARAMETER            5
#define MAX_OBJECT_VALUE        15
#define MAX_EFFECT_VALUE         3
#define MAX_NAME_LENGTH         30
#define MAX_HORSES               6
#define MAX_DEBUG               15
#define MAX_INTERNAL             5
#define MAX_VELLUM_LENGTH       128
#define MAX_STAFF               20

#define isSpace(c)              ( isspace( c ) && !IsChinese( c ) )
#define IsChinese(c)            IS_SET( c, 0x80 )

#define MAX_PORT                5

#define NO_ERROR                0
#define FILE_ERROR              -1
#define FILE_CORRECT            1
#define FILE_NEW                0
#define LOAD_OBJECT             1
#define LOAD_DEPOSIT            2

#define FOGGY_SET               1
#define FOGGY_CLEAR             2

#define EDIT_NONE               0
#define EDIT_NOTE               1
#define EDIT_VOTE               2
#define EDIT_POST               3
#define EDIT_SELF_DESCRIPTION   4
#define EDIT_NOTEPAD            5

/* �Ÿ��w�q */
#define ALIAS_SEPRATOR          ':'
#define SYMBOL_SEMICOLON        '&'
#define SYMBOL_COMMAND          '#'
#define VERTICAL_LINE           "--------------------------------------" \
                                "-------------------------------------\n\r"
/* �����]�w */
#define MAX_BOARD               50
#define MAX_NOTES               100
#define POST_ALL                1
#define POST_NOT_MARK           2
#define POST_MARK               3

/* �s�ɼҦ� */
#define SAVE_FILE               1
#define BACKUP_FILE             2
#define FAILCODE_FILE           3
#define BASIC_FILE              4
#define LOG_FILE                5

/* Automap ���Ѽ� */
#define MAX_PATH                30
#define MAX_TRACE               10
#define TRACE_NONE              -1

#define SHOP_SELL               1
#define SHOP_BUY                2

/* ��}�X�� */
#define BAN_LOGIN               1
#define BAN_FQDN                2
#define BAN_FINGER              3

/* ��X�w�İϪ�����X */
#define MODE_ABSENT             0
#define MODE_SAY                1
#define MODE_CHAT               2

/* ĵ�i�ɶ�, ��������� */
#define FIRST_WARN              5
#define SECOND_WARN             3
#define THIRD_WARN              1

/* �t�ΫO�d�r���X�� */
#define XNAMES_SYSTEM           1
#define XNAMES_CACONYM          2
#define XNAMES_CHAT             3
#define XNAMES_CNAME            4

#define VARIABLE_ILLEGAL        1
#define VARIABLE_SAME           2
#define VARIABLE_DIFFERENT      3
#define VARIABLE_NOT_DEFINE     4

#define MAX_RECHRISTEN          5    /* �C�Ӫ��a�̦h�i�H��W�X��     */
#define NAME_LENGTH             12   /* ���a�^��W�٪�����           */
#define CHAT_REPEAT             3    /* �O���X�ӹ�ܪ�����           */
#define CHAT_PENALTY            15   /* �����Ƹܪ��g�@               */
#define IPC_BLOCK               100  /* �i�H���X���O����϶�         */
#define IPC_IDLE                1000 /* ���m�h�[�t�ήɶ��h�R�����϶� */
#define EQ_MAX_CAPCITY          80
#define EQ_MIN_CAPCITY          20
#define PILLS_PER_DAY           5
#define DOSAGE_LIMIT            60
#define DOSAGE_UPDATE           2
#define MAX_HITROLL             150  /* �̤j�R���v                   */

/* �}��w�q */
#define MAX_GOOD_ALIGNMENT      1000
#define MAX_EVIL_ALIGNMENT      -1000

/* �Ѳ����w�q�`�� */
#define MAX_STOCK_COST  1000000      /* �Ѳ����̤j����         */
#define MIN_STOCK_COST  3000         /* �Ѳ����̧C����         */
#define STOCK_SHOCK     100          /* �C�R��X�i���^�T�|�i�� */
#define STOCK_TAX       5            /* �ҥ�|                 */
#define MAX_STOCK_WIN   200          /* �Ѳ����̤j���T         */
#define MAX_STOCK_LOST  200          /* �Ѳ����̤j�^�T         */
#define MAX_ASSET       1000000000   /* ���a�̦h�i�H�����`�겣 */
#define MAX_STOCK_TRADE 100000000
#define STOCK_BOTE      200
#define STOCK_BUY       1
#define STOCK_BUY_TAX   2
#define STOCK_SELL      3
#define STOCK_SELL_TAX  4
#define STOCK_QUOTA     100
#define STOCK_RELEASE   10000

/* �C���������@�ǰѼƪ��ŧi */
#define MAX_SKILL                  250       /* �̦h�ޯ�ƶq */
#define MAX_RECALL                 10        /* �̦h�^�k��m */
#define MAX_INNATE                 10
#define MAX_STOCK                  100       /* �̦h�Ѳ����q */
#define MAX_FIRMAN                 100       /* �̦h�K�����P */
#define MAX_LEVEL                  120       /* �C���̰����� */
#define LEVEL_HERO                 ( MAX_LEVEL - 20 )
#define LEVEL_IMMORTAL             ( MAX_LEVEL - 19 )
#define LEV_IMM                    LEVEL_IMMORTAL

/* �]�w log ���h�� */
#define LOG_EMERG               1
#define LOG_CRIT                2
#define LOG_ERR                 3
#define LOG_DEBUG               4
#define LOG_STACK               5
#define LOG_INFO                6
#define LOG_WIZARD              7
#define LOG_NEWPLAYER           8
#define LOG_FAILPASS            9
#define LOG_FAILEXIT            10
#define LOG_FAILLOAD            11
#define LOG_SHUTDOWN            12
#define LOG_IDEA                13
#define LOG_TYPO                14
#define LOG_LOWLIFE             15
#define LOG_NET                 16
#define LOG_CHAT                17
#define LOG_SUICIDE             18
#define LOG_PURGE               19
#define LOG_FAILENABLE          20
#define LOG_WIZFLAGS            21
#define LOG_BADFILE             22
#define LOG_SUSPECT             23

/* notify ���X�� */
#define NOTIFY_DEBUG            0x00000001
#define NOTIFY_INFO             0x00000002
#define NOTIFY_WIZARD           0x00000004
#define NOTIFY_NEWPLAYER        0x00000008
#define NOTIFY_FAILPASS         0x00000010
#define NOTIFY_EMERG            0x00000020
#define NOTIFY_CRIT             0x00000040
#define NOTIFY_ERR              0x00000080
#define NOTIFY_XNAME            0x00000100
#define NOTIFY_NET              0x00000200

#define INTERNAL_GETHOSTBYADDR  1
#define INTERNAL_FINGER         2
#define INTERNAL_ENDFINGER      3
#define INTERNAL_CHECKFILE      4
#define INTERNAL_CHECKSERV      5

/* �̤j�i�H�P�ɦ��X�ӤH�s�u */
#define MAX_CONNECT             5
#define MAX_HOSTNAME            256
#define MAX_IP                  10

#define HAND_RIGHT              1         /* �k�� */
#define HAND_LEFT               2         /* ���� */
#define HAND_BOTH               4         /* ���� */

/* �w�q�����s�u�`�� */
#define NET_NAME                1
#define NET_ADDRESS             2
#define NET_IMPORT              1
#define NET_EXPORT              2

#define ADDRESS_ALPHA           1
#define ADDRESS_NUMBER          2

/* �w�q���~�v�T�����A */
#define OBJ_CAST_HIT            1
#define OBJ_CAST_MANA           2
#define OBJ_CAST_MOVE           3
#define OBJ_CAST_IDENT          4
#define OBJ_CURE_POISON         5
#define OBJ_DETECT_INVS         6
#define OBJ_CAST_FLY            7
#define OBJ_CURE_BLIND          8
#define OBJ_GIANT_STR           9
#define OBJ_DETECT_HIDE         10
#define OBJ_SNEAK               11
#define OBJ_DETECT_EVIL         12
#define OBJ_CHANGE_SEX          13
#define OBJ_DETECT_MAGIC        14
#define OBJ_DETECT_POISON       15
#define OBJ_FAERIE_FOG          16
#define OBJ_GATE                17
#define OBJ_FIXITY              18
#define OBJ_CAST_ALL            19
#define OBJ_DETECT_MASK         20

/* �w�q���� */
#define EFFECT_NONE                     0
#define EFFECT_VICTIM_MANA              1
#define EFFECT_SELF_MANA                2
#define EFFECT_VICTIM_MOVE              3
#define EFFECT_SELF_MOVE                4
#define EFFECT_VICTIM_BLINDNESS         5
#define EFFECT_VICTIM_CURSE             6
#define EFFECT_VICTIM_POISON            7
#define EFFECT_VICTIM_SLEEP             8
#define EFFECT_VICTIM_PARA              9
#define EFFECT_VICTIM_FAERIE_FIRE       10

/* ����ɾ� */
#define OCCASION_NONE                   0

/* �w�q�ԭz���κA */
#define ACT_WHEN_EAT                    1
#define ACT_WHEN_WEAR                   2
#define ACT_WHEN_DROP                   3
#define ACT_WHEN_REMOVE                 4
#define ACT_WHEN_SACRIFICE              5
#define ACT_WHEN_GET                    6
#define ACT_WHEN_PUT                    7
#define ACT_WHEN_GIVE                   8
#define ACT_WHEN_FILL                   9
#define ACT_WHEN_DRINK                  10
#define ACT_WHEN_RECITE                 11
#define ACT_WHEN_BUY                    12
#define ACT_WHEN_SELL                   13
#define ACT_WHEN_VALUE                  14
#define ACT_WHEN_LOOK                   15
#define ACT_WHEN_COMPARE                16
#define ACT_WHEN_SEND                   17
#define ACT_WHEN_OPEN                   18
#define ACT_WHEN_CLOSE                  19
#define ACT_WHEN_LOCK                   20
#define ACT_WHEN_UNLOCK                 21
#define ACT_WHEN_AUCTION                22
#define ACT_WHEN_BET                    23
#define ACT_WHEN_REPAIR                 24
#define ACT_WHEN_DEPOSIT                25
#define ACT_WHEN_WITHDRAW               26
#define ACT_WHEN_CACHET                 27
#define ACT_WHEN_SLUP                   28
#define ACT_WHEN_STUDY                  29

/* �w�q�H�������ݩ� */
#define DEFAULT_HIT             100
#define DEFAULT_MOVE            100
#define DEFAULT_MANA            100
#define DEFAULT_STR             1
#define DEFAULT_INT             1
#define DEFAULT_WIS             1
#define DEFAULT_DEX             1
#define DEFAULT_CON             1

/* �w�q�ݩʦW�� */
#define TYPE_STR                1
#define TYPE_INT                2
#define TYPE_WIS                3
#define TYPE_DEX                4
#define TYPE_CON                5
#define SPELL_CLASS_ONE         1
#define SPELL_CLASS_TWO         2
#define SPELL_CLASS_THR         3
#define SPELL_CLASS_FOU         4
#define SPELL_CLASS_FIV         5

/* �w�q�t�γ]�w�Ǫ��U���ƭȥ[�� */
#define LOAD_ATTRIB_PLUS        1
#define LOAD_ARMOR_PLUS         1
#define LOAD_GOLD_PLUS         10
#define LOAD_DAMROLL_PLUS       5
#define LOAD_HIT_PLUS          50
#define LOAD_MANA_PLUS         50
#define LOAD_MOVE_PLUS         50

/* �w�q���ڳ̤j�t���ƥH�έt���q */
#define MAX_CARRY_N             1000
#define MAX_CARRY_W             1000000

/* �w�q�H���@�}�l�������ƥ� */
#define DEFAULT_GOLD            1000

/* �w�q�̤j�������� */
#define MAX_LIMIT_VALUE         30000

/* �w�q�̤j�i�ʦL�� */
#define MAX_CAN_CACHET            3

/* �w�q�����a�����ɶ� */
#define FOOD_DEGRADE             30

/* �w�q�̤j�]�۵��� */
#define MAX_CACHET_LEVEL        100

/* �w�q�^���W�[���K�����P */
#define HERO_ADD_FIRMAN          10

/* �w�q�k�N�ޯ�̤j��� */
#define LEVEL_ONE_DAM           350
#define LEVEL_TWO_DAM           700
#define LEVEL_THR_DAM          1300
#define LEVEL_FOU_DAM          1800
#define LEVEL_FIV_DAM          2300

/* �w�q¾�~���`�� */
#define CLASS_DEMOS             0       /* ����       */
#define CLASS_SCHOLAR           1       /* ��x       */
#define CLASS_FIGHTER           2       /* �Z�N       */
#define CLASS_SHAMAN            3       /* �D�h       */
#define CLASS_THIEF             4       /* �s��       */
#define CLASS_DOCTOR            5       /* ����       */
#define CLASS_BARD              6       /* �D�H       */
#define CLASS_GENERAL           7       /* �N�x       */
#define CLASS_BRAVO             8       /* ���       */
#define CLASS_MAGE              9       /* �Ѯv       */
#define CLASS_SMITH             10      /* ű�C�v     */
#define MAX_CLASS               11      /* �̦h¾�~�� */
#define FORCE_LEVEL             15

/* �w�q¾�~���`�� */
#define RES_DEMOS               ( 1 << CLASS_DEMOS   )  /* ����       */
#define RES_SCHOLAR             ( 1 << CLASS_SCHOLAR )  /* ��x       */
#define RES_FIGHTER             ( 1 << CLASS_FIGHTER )  /* �Z�N       */
#define RES_SHAMAN              ( 1 << CLASS_SHAMAN  )  /* �D�h       */
#define RES_THIEF               ( 1 << CLASS_THIEF   )  /* �s��       */
#define RES_DOCTOR              ( 1 << CLASS_DOCTOR  )  /* ����       */
#define RES_BARD                ( 1 << CLASS_BARD    )  /* �D�H       */
#define RES_GENERAL             ( 1 << CLASS_GENERAL )  /* �N�x       */
#define RES_BRAVO               ( 1 << CLASS_BRAVO   )  /* ���       */
#define RES_MAGE                ( 1 << CLASS_MAGE    )  /* �Ѯv       */
#define RES_SMITH               ( 1 << CLASS_SMITH   )  /* ű�C�v     */

/* �w�q�̤p�̤j������� */
#define MAX_PAGELEN             300
#define MIN_PAGELEN             5

/* �w�q�̦h�X���ݩ� */
#define MAX_ATTR                5
#define STR_UPGRADE             2
#define STR_ITEM                0
#define INT_UPGRADE             2
#define INT_ITEM                1
#define WIS_UPGRADE             2
#define WIS_ITEM                2
#define DEX_UPGRADE             2
#define DEX_ITEM                3
#define CON_UPGRADE             2
#define CON_ITEM                4
#define MAX_ARMOR               200000
#define MAX_PRACTICE            20000
#define MAX_NSKILL              100
#define CLUB_ATTR_GAIN          4

/* �w�q�����m�����A */
#define DOOR_OPEN               0
#define DOOR_CLOSED             1
#define DOOR_LOCKED             2

/* �w�q�̤j���ͩR�O�k�O�H�β��ʤO */
#define MAX_HIT                 20000
#define MAX_MANA                20000
#define MAX_MOVE                20000
#define MAX_STR                 100
#define MAX_INT                 100
#define MAX_WIS                 100
#define MAX_DEX                 100
#define MAX_CON                 100
#define MAX_DEFAULT_OBJECT      10

/* Command logging types. */
#define LOG_NORMAL              0
#define LOG_ALWAYS              1
#define LOG_NEVER               2
#define LOG_WIZ                 3

#define BOUNTY_GOLD        1
#define BOUNTY_FIRMAN      2

/* mpadd ���Ѽ� */
#define LOC_STR            1
#define LOC_INT            2
#define LOC_WIS            3
#define LOC_DEX            4
#define LOC_CON            5
#define LOC_TRAIN          6
#define LOC_NSKILL         7
#define LOC_FIRMAN         8
#define LOC_LEVEL          9
#define LOC_PILLS          10
#define LOC_DOSAGE         11
#define LOC_RECHR          12
#define LOC_MAXHIT         13
#define LOC_MAXMANA        14
#define LOC_MAXMOVE        15
#define LOC_HIT            16
#define LOC_MANA           17
#define LOC_MOVE           18

/* God Levels */
#define L_GOD                   MAX_LEVEL
#define L_SUP                   L_GOD - 1
#define L_DEI                   L_SUP - 1
#define L_ANG                   L_DEI - 1
#define L_HER                   L_ANG - 1

/* �榡�Ʀr�ꪺ�ﶵ */
#define FORMAT_CLEAN            1
#define FORMAT_SET              2
#define FORMAT_RETURN           3
#define FORMAT_STRING           4
#define FORMAT_NUM              5
#define FORMAT_LOCATE_STRING    6
#define FORMAT_LOCATE_NUM       7

/* �m�ߧޯ�үӪ���O */
#define PRACTICE_MOVE           5

/* ���� PK */
#define BORN_AGE                17            /* �X�ͪ��~��     */
#define PK_AGE                  21            /* �i�H��Ԫ��~�� */
#define PK_LEVEL                50            /* �i�H��Ԫ����� */
#define PK_JOIN                 1             /* ��ԥ[�J��     */
#define PK_BET                  2             /* ��ԤU�`��     */
#define PK_FIGHT                3             /* ��Ԥ�         */
#define PK_STOP                 4             /* ��Ե���       */
#define PK_DESERT               5             /* ��Զ��m��     */
#define PK_CONTRAST_LEVEL       20            /* ��Ԭۮt����   */
#define MIN_PK_GOLD             100
#define MAX_PK_GOLD             100000
#define MAX_PK_TOTAL            10000000

#define PK_FIRST                0
#define PK_SECOND               1

#define PK_NODEFINE             0
#define PK_PERSON               1
#define PK_CLUB                 2

#define FUNCTION(c)     void (c)( CHAR_DATA * ch , char * argument )
#define JOB(c)          void (c)( CHAR_DATA * ch, char * argument, JOB_MESSAGE * job )
#define SKILL(c)        bool (c)( int sn, int level, CHAR_DATA * ch, void * vo )
#define ANGEL(c)        bool (c)( CHAR_DATA * ch, bool fPrint )

/* �H�ŦX�«��� ANSI ���sĶ�� */
#if defined(TRADITIONAL)
#define const
#define args( list )                    ( )
#define DECLARE_DO_FUN( fun )           void fun( )
#define DECLARE_SPEC_FUN( fun )         bool fun( )
#define DECLARE_SPELL_FUN( fun )        bool fun( )
#define DECLARE_CHECK_FUN( fun )        bool fun( )
#define DECLARE_JOB_FUN( fun )          bool fun( )
#define DECLARE_ANGEL_FUN( fun )        bool fun( )
#define DECLARE_ROUTINE_FUN( fun )      bool fun( )
#define DECLARE_EVENT_FUN( fun )        void fun( )

#else
#define args( list )                    list
#define DECLARE_DO_FUN( fun )           DO_FUN      fun
#define DECLARE_SPEC_FUN( fun )         SPEC_FUN    fun
#define DECLARE_SPELL_FUN( fun )        SPELL_FUN   fun
#define DECLARE_CHECK_FUN( fun )        CHECK_FUN   fun
#define DECLARE_JOB_FUN( fun )          JOB_FUN     fun
#define DECLARE_ANGEL_FUN( fun )        ANGEL_FUN   fun
#define DECLARE_ROUTINE_FUN( fun )      ROUTINE_FUN fun
#define DECLARE_EVENT_FUN( fun )        EVENT_FUN   fun
#endif

#if     !defined( FALSE )
#define FALSE    0
#endif

#if     !defined( TRUE )
#define TRUE     1
#endif

#if     !defined( ERRORCODE )
#define ERRORCODE       -1
#endif

#if     defined(_AIX)
#if     !defined(const)
#define const
#endif
typedef int sh_int;
typedef int bool;
#define unix
#else
typedef short    int                    sh_int;
typedef unsigned char                   bool;
#endif

/* �w�q�����W�٬d�ߤ覡 */
#define CLUB_NAME               1               /* �έ^��W�٬d�� */
#define CLUB_CNAME              2               /* �Τ���W�٬d�� */
#define CLUB_MONEY              3
#define CLUB_STATUS             4
#define CLUB_TIMER              5
#define CLUB_CREATE_FUND        10000000        /* ������������� */
#define CLUB_EXPENSE            10000           /* �[�J�������W�O */
#define CLUB_COUNTERSIGN        5               /* �ݭn�X�ӤH�s�p */
#define MAX_CLUB_MEMBER         100              /* �����̦h�X�ӤH */
#define MAX_CLUB_DOYEN          10               /* �������Ѽƥ�   */
#define CLUB_COUNTERSIGN_FUND   100000          /* �s�p���������O */
#define MAX_CLUB_NUM            25              /* �̦h�����ƥ�   */
#define CLUB_STATUS_UNKNOW      0               /* �������������A */
#define CLUB_STATUS_COUNTERSIGN 1               /* �����s�p��     */
#define CLUB_STATUS_UNIONIZE    2               /* �����w�g����   */
#define MEMBER_VERIFY           TRUE            /* �ݭn�{������   */
#define MEMBER_NO_VERIFY        FALSE           /* ���ݭn�{������ */
#define CLUB_MASTER             6               /* ¾��->���D     */
#define CLUB_VICEMASTER         5               /* ¾��->�����D   */
#define CLUB_DOYEN              4               /* ¾��->����     */
#define CLUB_MEMBER             3               /* ¾��->����     */
#define CLUB_FOLLOWER           2               /* ¾��->�̤l     */
#define CLUB_ALL                1               /* ¾��->����     */
#define CLUB_NO_RELATION        -1              /* �S���������Y   */
#define BANK_PROFIT             100000          /* ���w���Q��     */
#define PLAYER_HOLD_DAY         90              /* ���a�O�d�Ѽ�   */
#define PLAYER_FILE_QUOTA       200000          /* ���a�ɮפj�p   */

#define MAX_VOTES               10
#define MAX_POLL                100
#define VOTE_GOLD               1000000
#define VOTE_LEVEL              10
#define VOTE_DAYS               10
#define VOTE_MIN_DAYS           5

/* ���c�����A�ŧi */
typedef struct  alias_data              ALIAS_DATA;
typedef struct  teach_data              TEACH_DATA;
typedef struct  cmd_data                CMD_DATA;
typedef struct  affect_data             AFFECT_DATA;
typedef struct  area_data               AREA_DATA;
typedef struct  ban_data                BAN_DATA;
typedef struct  xnames_data             XNAMES_DATA;
typedef struct  char_data               CHAR_DATA;
typedef struct  descriptor_data         DESCRIPTOR_DATA;
typedef struct  exit_data               EXIT_DATA;
typedef struct  extra_descr_data        EXTRA_DESCR_DATA;
typedef struct  help_data               HELP_DATA;
typedef struct  kill_data               KILL_DATA;
typedef struct  mob_index_data          MOB_INDEX_DATA;
typedef struct  note_data               NOTE_DATA;
typedef struct  obj_data                OBJ_DATA;
typedef struct  obj_index_data          OBJ_INDEX_DATA;
typedef struct  pc_data                 PC_DATA;
typedef struct  reset_data              RESET_DATA;
typedef struct  room_index_data         ROOM_INDEX_DATA;
typedef struct  shop_data               SHOP_DATA;
typedef struct  time_info_data          TIME_INFO_DATA;
typedef struct  weather_data            WEATHER_DATA;
typedef struct  symbol_data             SYMBOL_DATA;
typedef struct  mob_prog_data           MPROG_DATA;
typedef struct  mob_prog_act_list       MPROG_ACT_LIST;
typedef struct  auction_data            AUCTION_DATA;
typedef struct  sale_data               SALE_DATA;
typedef struct  fight_data              FIGHT_DATA;
typedef struct  serial_data             SERIAL_DATA;
typedef struct  top_data                TOP_DATA;
typedef struct  wanted_data             WANTED_DATA;
typedef struct  vote_data               VOTE_DATA;
typedef struct  gamble_data             GAMBLE_DATA;
typedef struct  sector_data             SECTOR_DATA;
typedef struct  skill_data              SKILL_DATA;
typedef struct  class_data              CLASS_DATA;
typedef struct  memory_data             MEMORY_DATA;
typedef struct  enable_data             ENABLE_DATA;
typedef struct  bus_data                BUS_DATA;
typedef struct  ship_data               SHIP_DATA;
typedef struct  joke_data               JOKE_DATA;
typedef struct  variable_data           VARIABLE_DATA;
typedef struct  ticket_data             TICKET_DATA;
typedef struct  order_data              ORDER_DATA;
typedef struct  gift_data               GIFT_DATA;
typedef struct  stamp_data              STAMP_DATA;
typedef struct  mineral_data            MINERAL_DATA;
typedef struct  mine_data               MINE_DATA;
typedef struct  greeting_data           GREETING_DATA;
typedef struct  array_data              ARRAY_DATA;
typedef struct  event_data              EVENT_DATA;
typedef struct  basic_data              BASIC_DATA;
typedef struct  bounty_data             BOUNTY_DATA;
typedef struct  server_data             SERVER_DATA;
typedef struct  cachet_data             CACHET_DATA;
typedef struct  trace_data              TRACE_DATA;
typedef struct  club_data               CLUB_DATA;
typedef struct  net_data                NET_DATA;
typedef struct  internal_socket         INTERNAL_SOCKET;
typedef struct  limit_data              LIMIT_DATA;
typedef struct  address_data            ADDRESS_DATA;
typedef struct  ip_data                 IP_DATA;
typedef struct  social_data             SOCIAL_DATA;
typedef struct  sockaddr_in             SOCKET_DATA;
typedef struct  timeval                 TIMEVAL;
typedef struct  ansi_data               ANSI_DATA;
typedef struct  palette_data            PALETTE_DATA;
typedef struct  damage_data             DAMAGE_DATA;
typedef struct  pw_data                 PW_DATA;
typedef struct  gr_data                 GR_DATA;
typedef struct  failcode_data           FAILCODE_DATA;
typedef struct  post_data               POST_DATA;
typedef struct  board_data              BOARD_DATA;
typedef struct  hero_data               HERO_DATA;
typedef struct  effect_data             EFFECT_DATA;
typedef struct  message_data            MESSAGE_DATA;
typedef struct  angel_data              ANGEL_DATA;
typedef struct  battle_data             BATTLE_DATA;
typedef struct  liq_data                LIQ_DATA;
typedef struct  restrict_data           RESTRICT_DATA;
typedef struct  job_data                JOB_DATA;
typedef struct  job_message             JOB_MESSAGE;
typedef struct  enroll_data             ENROLL_DATA;
typedef struct  stock_data              STOCK_DATA;
typedef struct  quest_data              QUEST_DATA;
typedef struct  question_data           QUESTION_DATA;
typedef struct  answer_data             ANSWER_DATA;
typedef struct  file_data               FILE_DATA;
typedef struct  enquire_data            ENQUIRE_DATA;
typedef struct  scan_data               SCAN_DATA;
typedef struct  quest_info              QUEST_INFO;
typedef struct  enemy_data              ENEMY_DATA;
typedef struct  immlist_data            IMMLIST_DATA;
typedef struct  friend_data             FRIEND_DATA;

/* �ŧi�@�Ǩ�ƪ��쫬���A */
typedef void DO_FUN      args( ( CHAR_DATA * , char * ) );
typedef bool SPEC_FUN    args( ( CHAR_DATA * ) );
typedef bool SPELL_FUN   args( ( int, int, CHAR_DATA *, void * ) );
typedef bool CHECK_FUN   args( ( CHAR_DATA *, bool ) );
typedef void JOB_FUN     args( ( CHAR_DATA *, char *, JOB_MESSAGE * ) );
typedef void EVENT_FUN   args( ( void ) );
typedef bool ANGEL_FUN   args( ( CHAR_DATA *, bool ) );
typedef bool ROUTINE_FUN args( ( CHAR_DATA *, CHAR_DATA *, int level ) );

/* �r��H�ΰO����޲z���Ѽƫŧi */
#define MAX_KEY_HASH             1024
#define MAX_STRING_LENGTH        4096
#define MAX_BUFFER_LENGTH        4000
#define MAX_EDITING_LENGTH       4000
#define MAX_OUTPUT_LENGTH       30000
#define MAX_BLOCK_SIZE           4096
#define MAX_INPUT_LENGTH          160
#define MAX_FILE_LENGTH           128
#define MAX_PERM_BLOCK         131072
#define MAX_MEM_LIST               12
#define MAX_REPEAT                 20
#define MAX_HISTORY                 9
#define MAX_NOTEPAD                10
#define MAX_SCREEN_BUFFER       32768
#define MAX_STOCK_HISTORY          20

/* �����O����޲z�Ѽƫŧi */
extern  int     top_restrict;
extern  int     top_board;
extern  int     top_affect;
extern  int     top_area;
extern  int     top_ed;
extern  int     top_exit;
extern  int     top_help;
extern  int     top_vote;
extern  int     top_joke;
extern  int     top_angel;
extern  int     top_sector;
extern  int     top_class;
extern  int     top_liq;
extern  int     top_social;
extern  int     top_mob_index;
extern  int     top_obj_index;
extern  int     top_reset;
extern  int     top_room;
extern  int     top_shop;
extern  int     top_mineral;
extern  int     top_teach;
extern  int     top_greeting;
extern  int     top_skill;
extern  int     top_cmd;
extern  int     top_quest;
extern  int     top_question;
extern  int     top_event;
extern  int     top_gift;
extern  int     top_bounty;
extern  int     top_immlist;
extern  int     top_sale;
extern  int     top_ship;
extern  FILE *  FilePointer;
extern  char    FileName[ MAX_INPUT_LENGTH ];
extern  int     RecallPlace[MAX_RECALL];
extern  int     iInnate[MAX_INNATE];
extern  int     nInnate;
extern  int     aInnate;
extern  int     merc_id;
extern  pid_t   merc_pid;
extern  bool    arena_busy;
extern  bool    fqdn_limit;
extern  bool    SystemCrash;
extern  bool    SetFileMode;
extern  bool    GroupSpiltExp;
extern  bool    AttackValue;
extern  bool    SkillValue;
extern  bool    PlayerAngel;
extern  bool    ChatRecord;
extern  int     MobDecrease;
extern  int     FileMode;
extern  int     PillsPerDay;
extern  int     DosageUpdate;
extern  int     DosageLimit;
extern  int     VoteGold;
extern  bool    NewLock;
extern  CLASS_DATA * iClass[MAX_CLASS];

/* �����r�걱���ܼ� */
extern  char      str_empty       [1];
extern  void *    rgFreeList      [MAX_MEM_LIST];
extern  int       rgAllocList     [MAX_MEM_LIST];
extern  int rgSizeList            [MAX_MEM_LIST];

#define PULSE_PER_SECOND            4
#define PULSE_PER_TALK              PULSE_PER_SECOND
#define PULSE_VIOLENCE            ( 3 * PULSE_PER_SECOND)
#define PULSE_MOBILE              ( 4 * PULSE_PER_SECOND)
#define PULSE_TICK                (30 * PULSE_PER_SECOND)
#define PULSE_AREA                (60 * PULSE_PER_SECOND)

struct   alias_data
{
  ALIAS_DATA *        next;
  char                text            [MAX_INPUT_LENGTH];
  char                macro           [MAX_INPUT_LENGTH];
};

struct teach_data
{
  TEACH_DATA * next;
  int          slot;
  int          cost;
  int          adept;
  int          inventory;
};

struct auction_data
{
  int         price;
  int         times;
  OBJ_DATA  * obj;
  CHAR_DATA * seller;
  CHAR_DATA * buyer;
  SALE_DATA * sale;
  int         start_time;
  int         timer;
  bool        visible;
};

struct sale_data
{
  SALE_DATA      * next;
  OBJ_INDEX_DATA * obj;
  bool             visible;
  int              cost;
  int              times;
  int              sold;
  int              gold;
};

struct fight_data
{
  CHAR_DATA * fight_1;
  CHAR_DATA * fight_2;
  CLUB_DATA * club_1;
  CLUB_DATA * club_2;
  AREA_DATA * area;
  int         status;
  int         type;
  int         lock;
  int         time;
  int         open;
};

struct serial_data
{
  int high;
  int low;
};

struct top_data
{
  TOP_DATA * next;
  int        day;
  int        hour;
  int        number;
  int        nRead;
  int        nWrite;
};

struct wanted_data
{
  WANTED_DATA * next;
  char        * wanted;
  char        * bountier;
  int           reward;
};

/* �ޯ�P�઺���c�ŧi */
struct enable_data
{
  ENABLE_DATA * next;
  int           slot;
};

struct net_data
{
  NET_DATA * next;
  char     * name;
  char     * cname;
  char     * address;
  int        port;
  int        import;
  int        export;
  int        nRead;
  int        nWrite;
  int        timer;
  int        import_duration;
  int        export_duration;
  bool       log;
  bool       valid;
  char       message[MAX_INPUT_LENGTH];
};

/* ������Ƶ��c */
struct  club_data
{
  CLUB_DATA       * next;
  ROOM_INDEX_DATA * location;
  OBJ_DATA        * staff[MAX_LEVEL][MAX_STAFF];
  char            * name;
  char            * cname;
  char            * master;
  char            * vicemaster;
  char            * doyen[MAX_CLUB_DOYEN];
  char            * member[MAX_CLUB_MEMBER];
  int               verify[MAX_CLUB_MEMBER];
  int               timer;
  int               status;
  int               money;
};

/* �a�K��� */
struct bus_data
{
  BUS_DATA        * next;
  ROOM_INDEX_DATA * station;
  ROOM_INDEX_DATA * platform;
  ROOM_INDEX_DATA * loge;
  char            * name;
  int               cost;
  int               count;
};

/* ������ */
struct ship_data
{
  SHIP_DATA       * next;
  char            * name;               /* �������W��         */
  char            * msg_entrance;       /* ��J�䪺�T��         */
  char            * msg_land;           /* ��a�䪺�T��         */
  char            * description;        /* ����ԭz             */
  ROOM_INDEX_DATA * starting;           /* ����X�o�I           */
  ROOM_INDEX_DATA * cabin;              /* ����             */
  ROOM_INDEX_DATA * destination;        /* ����ت��a           */
  int               cost;               /* �W��O��             */
  int               sailing;            /* ������ɶ�         */
  int               waiting;            /* ����ݤW��ɶ�     */
  int               sailing_tick;       /* ����ثe���ɶ�     */
  int               waiting_tick;       /* ��ثe���ݤW��ɶ� */
  int               count;              /* ����W��H��         */
  int               pirate;             /* ��J����s�����v     */
  int               pirate_count;       /* ��J����s������     */
  int               delay;              /* ����������v         */
  bool              lock;               /* ��O�_�D����w       */
};

/* ��ո�ƪ��ŧi */
struct  gamble_data
{
  GAMBLE_DATA * next;
  int           format;
  int           mount;
  int           horse[ MAX_HORSES ];
};

/* �a�ε��c���ŧi */
struct sector_data
{
  SECTOR_DATA * next;
  char        * cname;
  int           vnum;
  int           movement;
  int           flags;
  int           count;
  bool          dark;
};

/* �`�ƲŸ������c�ŧi */
struct  symbol_data
{
  SYMBOL_DATA * next;
  char        * str;
  int           num;
};

struct  ban_data
{
  BAN_DATA * next;
  char     * name;
  int        type;
};

/* �����r�����c */
struct xnames_data
{
  XNAMES_DATA * next;
  char        * word;
  int           type;
};

/* ���D�����c */
struct question_data
{
  QUESTION_DATA * next;
  char          * title;
  char          * question[MAX_QUESTION];
  bool            answer[MAX_QUESTION];
  int             count;
  int             fail;
};

struct enquire_data
{
  ENQUIRE_DATA * next;
  char         * keyword;
};

struct answer_data
{
  QUESTION_DATA * question;
  int             random[MAX_QUESTION];
  int             timer;
  int             false;
};

struct file_data
{
  FILE_DATA * next;
  FILE      * fp;
  char      * filename;
  int         errno;
  int         fd;
  int         timer;
};

/* ���������c */
struct quest_data
{
  QUEST_DATA * next;
  QUEST_INFO * link;
};

/* �Ѱg����� */
struct quest_info
{
  QUEST_INFO * next;
  char       * mark;
  char       * info;
  char       * help;
  bool         show;
};

/* ���ڸ�� */
struct immlist_data
{
  IMMLIST_DATA * next;
  char         * name;
  char         * description;
  int            level;
  int            trust;
  int            adviser;
};

/* �n�ͦW�浲�c */
struct friend_data
{
  FRIEND_DATA * next;
  char          name[NAME_LENGTH+1];
};

/* ���Ī����c */
struct enemy_data
{
  ENEMY_DATA * next;
  char       * city;
};

/* �ɶ��H�ΤѮ𪺰Ѽƫŧi */
#define SUN_DARK                0
#define SUN_RISE                1
#define SUN_LIGHT               2
#define SUN_SET                 3

#define SKY_CLOUDLESS           0
#define SKY_CLOUDY              1
#define SKY_RAINING             2
#define SKY_LIGHTNING           3

struct  time_info_data
{
  int hour;
  int day;
  int month;
  int year;
};

struct  weather_data
{
  int mmhg;
  int change;
  int sky;
  int sunlight;
};

/* �s�u�ثe�����A�ŧi */
#define CON_PLAYING                     0
#define CON_GET_FQDN                    1
#define CON_GET_FINGER                  2
#define CON_GET_NAME                    3
#define CON_CHECK_FILE                  4
#define CON_VERIFY                      5
#define CON_GET_OLD_PASSWORD            6
#define CON_CONFIRM_NEW_NAME            7
#define CON_GET_NEW_PASSWORD            8
#define CON_CONFIRM_NEW_PASSWORD        9
#define CON_GET_SEX                    10
#define CON_READ_MOTD                  11
#define CON_GET_CNAME                  12
#define CON_CHOOSE_SKILL               13
#define CON_GET_EMAIL_ADDRESS          14
#define CON_CHOOSE_CLASS               15
#define CON_CHOOSE_MODE                16
#define CON_CHOOSE_ANGEL               17
#define CON_CHOOSE_HOME                18
#define CON_CONTRACT                   19

/* �ޯ઺���� */
#define RATING_SKILL                    1
#define RATING_WIND                     2
#define RATING_EARTH                    3
#define RATING_LIGHTNING                4
#define RATING_POISON                   5
#define RATING_FIRE                     6
#define RATING_WATER                    7
#define RATING_DARKNESS                 8
#define RATING_LIGHT                    9
#define RATING_SAINT                   10
#define RATING_EVIL                    11
#define RATING_LOST                    12
#define RATING_CURE                    13
#define RATING_SING                    14
#define RATING_FIGHT                   15
#define RATING_MURDER                  16
#define RATING_CREATE                  17
#define RATING_THIEF                   18
#define RATING_ALL                     19 /* �Ҧ��t���]�t */

struct  descriptor_data
{
  DESCRIPTOR_DATA * next;
  bool              delete;
  int               counter;
  DESCRIPTOR_DATA * snoop_by;
  CHAR_DATA       * character;
  sh_int            descriptor;
  sh_int            connected;
  int               file;
  int               id_number;
  char              inbuf             [4 * MAX_INPUT_LENGTH];
  char              incomm                [MAX_INPUT_LENGTH];
  char              inlast  [MAX_HISTORY] [MAX_INPUT_LENGTH];
  char              tick_command          [MAX_INPUT_LENGTH];
  char              finger_data           [MAX_STRING_LENGTH];
  char              last_chat             [CHAT_REPEAT] [MAX_INPUT_LENGTH];
  char              username              [ NAME_LENGTH + 1 ];
  char            * showstr_head;
  char            * showstr_point;
  char            * outbuf;
  char            * buffer;
  char            * address;
  char            * host;
  char            * remote;
  char            * path;
  bool              select[MAX_INNATE];
  unsigned int      naddr;
  int               chat_error;
  int               inflect;
  int               outsize;
  int               outtop;
  int               alias_repeat;
  int               repeat;
  int               substitution;
  int               error;
  int               tick;
  int               tick_count;
  int               multi;
  int               port;
  int               nWrite;
  int               nRead;
  int               edit_mode;
  time_t            timekeeper;
  unsigned long int inet_addr;
  bool              fcommand     : 1;
  bool              check_fqdn   : 1;
  bool              check_finger : 1;
  bool              check_file   : 1;
  bool              lock_file    : 1;
  bool              fqdn_limit   : 1;
  bool              stack        : 1;
  bool              server       : 1;
};

struct  address_data
{
  ADDRESS_DATA * next;
  char         * number;
  char         * alpha;
  int            count;
};

struct ip_data
{
  IP_DATA * next;
  char    * address;
};

struct variable_data
{
  VARIABLE_DATA * next;
  char          * keyword;
  int             value;
  int             hours;
};

struct ticket_data
{
  TICKET_DATA * next;
  ORDER_DATA  * order;
  bool          sold;
};

struct order_data
{
  ORDER_DATA * next;
  int          order;
  int          howmany;
  int          gold;
};

struct gift_data
{
  GIFT_DATA      * next;
  OBJ_INDEX_DATA * gift;
  char           * title;
  char           * message;
  int              month;
  int              day;
  int              high;
  int              low;
  int              count;
  int              stamp;
  int              sender;
  int              duration;
  int              tick;
  int              gold;
  int              days;
  time_t           starting;
  time_t           ending;
  bool             send;
};

struct mineral_data
{
  MINERAL_DATA   * next;
  OBJ_INDEX_DATA * mineral;
  char           * message;
  int              count;
  int              flags;
};

struct mine_data
{
  MINE_DATA    * next;
  MINERAL_DATA * mineral;
};

struct greeting_data
{
  GREETING_DATA * next;
  char          * text;
};

struct array_data
{
  int    number;
  char * message;
};

struct stamp_data
{
  STAMP_DATA * next;
  int          number;
};

struct event_data
{
  EVENT_DATA * next;
  char       * title;
  char       * keyword;
  int          count;
  int          chance;
  bool         lock;
  EVENT_FUN  * function;
};

struct basic_data
{
  char * name;
  char * cname;
  char * address;
  char * email;
  int    level;
  int    age;
  int    played;
};

struct cachet_data
{
  CACHET_DATA * next;
  int           vnum;
};

struct server_data
{
  SERVER_DATA * next;
  char        * address;
};

struct bounty_data
{
  BOUNTY_DATA    * next;
  MOB_INDEX_DATA * mob;
  char           * msg;
  int              room;
  int              chance;
  int              count;
  int              max;
  int              type;
  int              value;
  int              migration;
  int              occurred;
  int              killed;
  bool             lock;
};

struct joke_data
{
  JOKE_DATA * next;
  int         stamp;
  char      * title;
  char      * org;
  char      * text;
};

struct trace_data
{
  int starting;
  int ending;
  int path[MAX_PATH];
};

struct  limit_data
{
  LIMIT_DATA * next;
  CLASS_DATA * class;
  int          level;
  int          adept;
};

struct  struct_data
{
  int    type;
  int    size;
  char * name;
  int    nAlloc;
};

/* act ��Ʃһݭn���Ѽ� */
#define TO_ROOM                 0
#define TO_NOTVICT              1
#define TO_VICT                 2
#define TO_CHAR                 3

/* �D�U���c���ŧi */
struct  help_data
{
  HELP_DATA * next;
  char      * keyword;
  char      * text;
  sh_int      level;
};

/* �����ө����ŧi */
#define MAX_TRADE               5

struct  shop_data
{
  SHOP_DATA       * next;                   /* Next shop in list            */
  ROOM_INDEX_DATA * sential;
  char            * filename;
  int               type;
  int               keeper;                 /* Vnum of shop keeper mob      */
  int               buy_type [MAX_TRADE];   /* Item types shop will buy     */
  int               profit_buy;             /* Cost multiplier for buying   */
  int               profit_sell;            /* Cost multiplier for selling  */
  int               open_hour;              /* First opening hour           */
  int               close_hour;             /* First closing hour           */
};

/* ¾�~���c���w�q */
struct  class_data
{
  CLASS_DATA * next;
  char       * name;                 /* �^��W��       */
  char       * cname;                /* ����W��       */
  char       * title;                /* ���Y�W��       */
  char       * rank[MAX_LEVEL+1];    /* ���Y           */
  char       * msg_limit;            /* �����T��       */
  int          vnum;                 /* ¾�~�s��       */
  int          low_rebirth;          /* ��¾���ŤU��   */
  int          high_rebirth;         /* ��¾���ŤW��   */
  int          rebirth_gold;         /* ��¾��         */
  int          warn;                 /* ��¾ĵ�i       */
  int          associate;            /* �ण����¾     */
  int          limit;                /* ������         */
  int          nskill;               /* �i�ǧޯ�ƥ�   */
  int          multiplier;           /* ��������       */
  int          attr[ MAX_ATTR ];     /* �Ҧ��ݩʪ��W�� */
  int          factor[ MAX_ATTR ];   /* �Ҧ��ݩʪ��]�� */
  int          max_default[MAX_ATTR];/* �ݩʹw�]�̤j�� */
  int          min_default[MAX_ATTR];/* �ݩʹw�]�̤p�� */
  int          hero[MAX_ATTR];       /* �ɯŬ��^���[���ƭ� */
  bool         fMana     : 1;        /* �ण��o��k�O */
  bool         rudiment  : 1;        /* �O�_���w�]¾�~ */
  bool         force     : 1;        /* �O�_���j��¾�~ */
  bool         innate    : 1;        /* �O�_���i��¾�~ */
  bool         select    : 1;        /* �O�_�@�}�l�i�H��� */
};

/* NOTE ���c���ŧi */
struct note_data
{
  NOTE_DATA * next;
  char      * filename;
  char      * sender;
  char      * date;
  char      * to_list;
  char      * subject;
  char      * text;
  time_t      date_stamp;
  bool        mark;
};

struct vote_data
{
  VOTE_DATA * next;
  char      * poster;
  char      * subject;
  char      * text;
  char      * date;
  char      * club;
  int         days;
  int         stamp;
  int         level;
  char      * message[MAX_VOTES];
  int         poll[MAX_VOTES];
  char      * poller[MAX_POLL];
  int         vote[MAX_POLL];
  int         lock;
  int         moninal;
};

/* AFFECT ���c���ŧi */
struct  affect_data
{
  AFFECT_DATA * next;
  int           type;
  int           duration;
  int           location;
  int           modifier;
  int           bitvector;
  int           level;
};

/* �Q�������c�ŧi */
struct  kill_data
{
  int number;
  int killed;
  int promotion;
  int exp;
  int damage;
  int dodge;
};

struct memory_data
{
  bool done;
  bool lock;
  int  timer;
  int  id;
  int  type;
  int  used;
  char text[MAX_STRING_LENGTH];
};

struct pw_data
{
  PW_DATA * next;
  char    * name;
  int       slot;
};

struct gr_data
{
  GR_DATA * next;
  char    * name;
  int       slot;
};

struct failcode_data
{
  FAILCODE_DATA * next;
  char          * address;
  int             timer;
};

struct board_data
{
  BOARD_DATA      * next;
  POST_DATA       * post;
  ROOM_INDEX_DATA * location;
  char            * name;
  char            * welcome;
  char            * listfile;
  char            * pathname;
  int               slot;
  int               capcity;
  int               read_level;
  int               write_level;
  bool              lock;
};

struct post_data
{
  POST_DATA  * next;
  BOARD_DATA * board;
  char       * title;
  char       * text;
  char       * poster;
  char       * owner;
  char       * filename;
  int          timer;
  int          attach;
  bool         mark : 1;
};

struct battle_data
{
  CHAR_DATA * fighter_1;
  CHAR_DATA * fighter_2;
  CLUB_DATA * club_1;
  CLUB_DATA * club_2;
  int         timer;
  bool        lock;
};

struct hero_data
{
  HERO_DATA * next;
  char      * name;
  char      * cname;
  char      * class;
  int         timer;
};

struct effect_data
{
  EFFECT_DATA * next;
  int           type;
  int           value[MAX_EFFECT_VALUE];
};

struct message_data
{
  MESSAGE_DATA * next;
  int            type;
  char         * self;
  char         * others;
};

struct angel_data
{
  ANGEL_DATA * next;
  ANGEL_FUN  * function;
  int          lower;
  int          higher;
  int          position;
  char       * description;
};

/***************************************************************************
 *                   �����ϰ��ɪ��ŧi����                                  *
 ***************************************************************************/

/* MOB �� ACT ���ƭȪ� */
#define ACT_IS_NPC              0x00000001 /* �Ǫ����]�w           */
#define ACT_SENTINEL            0x00000002 /* ���b���M���|����   */
#define ACT_SCAVENGER           0x00000004 /* �|�۰ʾ߰_�F��       */
#define ACT_AGGRESSIVE          0x00000020 /* �|�۰ʧ���           */
#define ACT_STAY_AREA           0x00000040 /* ���|���}�ϰ�         */
#define ACT_WIMPY               0x00000080 /* Flees when hurt      */
#define ACT_PET                 0x00000100 /* Auto set for pets    */
#define ACT_TRAIN               0x00000200 /* Can train PC's       */
#define ACT_PRACTICE            0x00000400 /* Can practice PC's    */
#define ACT_REBIRTH             0x00000800 /* �i�H�����a��¾       */
#define ACT_REBORN_FIGHT        0x00001000 /* �|�A�ͦ���L�Ǫ�     */
#define ACT_ASK                 0x00002000 /* �|�s�H���u           */
#define AUTOSET_VALUE           0x00004000 /* �Ѩt�γ]�w�@�Ǽƭ�   */
#define ACT_NOREBORN            0x00008000 /* ���|����             */
#define ACT_NOKILL              0x00010000 /* ������`             */
#define ACT_ENROLL              0x00020000 /* �O��                 */
#define ACT_ALIGN_GOOD          0x00040000 /* �}�絽�}���Ǫ�       */
#define ACT_ALIGN_EVIL          0x00080000 /* �}�稸�c���Ǫ�       */
#define ACT_NOSUMMON            0x00100000 /* ����Q�l��           */

/* MOB �� AFFECT_BY ���ƭȪ� */
#define AFF_BLIND               0x00000001
#define AFF_INVISIBLE           0x00000002
#define AFF_DETECT_EVIL         0x00000004
#define AFF_DETECT_INVIS        0x00000008
#define AFF_DETECT_MAGIC        0x00000010
#define AFF_DETECT_HIDDEN       0x00000020
#define AFF_SANCTUARY           0x00000040
#define AFF_FAERIE_FIRE         0x00000080
#define AFF_INFRARED            0x00000100
#define AFF_CURSE               0x00000200
#define AFF_POISON              0x00000400
#define AFF_PROTECT             0x00000800
#define AFF_SNEAK               0x00001000
#define AFF_HIDE                0x00002000
#define AFF_SLEEP               0x00004000
#define AFF_CHARM               0x00008000
#define AFF_FLYING              0x00010000
#define AFF_PASS_DOOR           0x00020000
#define AFF_FIXITY              0x00040000
#define AFF_MASK                0x00080000
#define AFF_DETECT_MASK         0x00100000

/* �ʧO */
#define SEX_NEUTRAL             0
#define SEX_MALE                1
#define SEX_FEMALE              2

/* �`�Ϊ����~���������X */
#define OBJ_VNUM_PROTYPE        1
#define OBJ_VNUM_MONEY_ONE      2
#define OBJ_VNUM_MONEY_SOME     3
#define OBJ_VNUM_CORPSE_NPC     4
#define OBJ_VNUM_CORPSE_PC      5
#define OBJ_VNUM_SEVERED_HEAD   6
#define OBJ_VNUM_TORN_HEART     7
#define OBJ_VNUM_SLICED_ARM     8
#define OBJ_VNUM_SLICED_LEG     9
#define OBJ_VNUM_FINAL_TURD     10
#define OBJ_VNUM_MUSHROOM       11
#define OBJ_VNUM_LIGHT_BALL     12
#define OBJ_VNUM_SPRING         13
#define OBJ_VNUM_DUMPLING       62
#define OBJ_VNUM_BOUGI          120
#define OBJ_VNUM_PON            121
#define OBJ_VNUM_CHICKEN        119
#define OBJ_VNUM_SCHOOL_MACE    50
#define OBJ_VNUM_SCHOOL_DAGGER  51
#define OBJ_VNUM_SCHOOL_SWORD   52
#define OBJ_VNUM_SCHOOL_ROBE    53
#define OBJ_VNUM_SCHOOL_HAT     54
#define OBJ_VNUM_MAGICSTONE     122
#define OBJ_VNUM_MEAT           169
#define OBJ_VNUM_LETTER         170

/* ���~�����A�`�� */
#define ITEM_LIGHT              1
#define ITEM_SCROLL             2
#define ITEM_WAND               3
#define ITEM_STAFF              4
#define ITEM_WEAPON             5
#define ITEM_TREASURE           6
#define ITEM_ARMOR              7
#define ITEM_POTION             8
#define ITEM_FURNITURE          9
#define ITEM_TRASH              10
#define ITEM_CONTAINER          11
#define ITEM_DRINK_CON          12
#define ITEM_KEY                13
#define ITEM_FOOD               14
#define ITEM_MONEY              15
#define ITEM_BOAT               16
#define ITEM_CORPSE_NPC         17
#define ITEM_CORPSE_PC          18
#define ITEM_FOUNTAIN           19
#define ITEM_PILL               20
#define ITEM_MAGICSTONE         21
#define ITEM_SPIRITJADE         22
#define ITEM_MYSTERY            23
#define ITEM_LETTER             24
#define ITEM_ORE                25
#define ITEM_GOLDMINE           26
#define ITEM_SIGIL              27
#define ITEM_VELLUM             28
#define ITEM_FIREWORK           29

/* �Z�����κA */
#define WEAPON_ALL              65535
#define WEAPON_HAND             1        /* �Ť���� */
#define WEAPON_DAGGER           2        /* �P������ */
#define WEAPON_SWORD            3        /* ���C���� */
#define WEAPON_BLADE            4        /* �j�M���� */
#define WEAPON_AXE              5        /* ���Y���� */
#define WEAPON_WHIP             6        /* ���@���� */
#define WEAPON_SPEAR            7        /* ���j���� */
#define WEAPON_PEN              8        /* �������� */
#define WEAPON_HAMMER           9        /* �������� */
#define WEAPON_CLUB             10       /* �ҴΧ��� */
#define WEAPON_BOW              11       /* �}�b���� */
#define WEAPON_FORCE            12       /* ��\���� */

#define SHOP_STORE              1
#define SHOP_SMITH              2
#define SHOP_MERCENARY          3
#define SHOP_COPER              4

/* ���~���B�~�X�мƭȪ� */
#define ITEM_GLOW               0x00000001
#define ITEM_HUM                0x00000002
#define ITEM_DARK               0x00000004
#define ITEM_LOCK               0x00000008
#define ITEM_EVIL               0x00000010
#define ITEM_INVIS              0x00000020
#define ITEM_MAGIC              0x00000040
#define ITEM_NODROP             0x00000080
#define ITEM_BLESS              0x00000100
#define ITEM_ANTI_GOOD          0x00000200
#define ITEM_ANTI_EVIL          0x00000400
#define ITEM_ANTI_NEUTRAL       0x00000800
#define ITEM_NOREMOVE           0x00001000
#define ITEM_INVENTORY          0x00002000
#define ITEM_CANCACHET          0x00004000
#define ITEM_USERSET            0x00008000
#define ITEM_NOSAVE             0x00010000
#define ITEM_CONTRABAND         0x00020000

/* ���~�������X�Ъ��ƭȪ� */
#define ITEM_TAKE               0x00000001
#define ITEM_WEAR_FINGER        0x00000002
#define ITEM_WEAR_NECK          0x00000004
#define ITEM_WEAR_BODY          0x00000008
#define ITEM_WEAR_HEAD          0x00000010
#define ITEM_WEAR_LEGS          0x00000020
#define ITEM_WEAR_FEET          0x00000040
#define ITEM_WEAR_HANDS         0x00000080
#define ITEM_WEAR_ARMS          0x00000100
#define ITEM_WEAR_SHIELD        0x00000200
#define ITEM_WEAR_ABOUT         0x00000400
#define ITEM_WEAR_WAIST         0x00000800
#define ITEM_WEAR_WRIST         0x00001000
#define ITEM_WIELD              0x00002000
#define ITEM_HOLD               0x00004000
#define ITEM_EARRING            0x00008000

/* ���~���v�T���A���ƭȪ� */
#define APPLY_NONE              0
#define APPLY_STR               1
#define APPLY_DEX               2
#define APPLY_INT               3
#define APPLY_WIS               4
#define APPLY_CON               5
#define APPLY_SEX               6
#define APPLY_CLASS             7
#define APPLY_LEVEL             8
#define APPLY_AGE               9
#define APPLY_HEIGHT            10
#define APPLY_WEIGHT            11
#define APPLY_MANA              12
#define APPLY_HIT               13
#define APPLY_MOVE              14
#define APPLY_GOLD              15
#define APPLY_EXP               16
#define APPLY_AC                17
#define APPLY_HITROLL           18
#define APPLY_DAMROLL           19
#define APPLY_SAVING_PARA       20
#define APPLY_SAVING_ROD        21
#define APPLY_SAVING_PETRI      22
#define APPLY_SAVING_BREATH     23
#define APPLY_SAVING_SPELL      24

/* �e�������~���� Value[1] ���������ƭȪ� */
#define CONT_CLOSEABLE          0x00000001
#define CONT_PICKPROOF          0x00000002
#define CONT_CLOSED             0x00000004
#define CONT_LOCKED             0x00000008

/* �ϰ쪺�X�� */
#define AREA_PK                 0x00000001

/* �ж����X�мƭȪ� */
#define ROOM_DARK               0x00000001
#define ROOM_NO_MOB             0x00000002
#define ROOM_INDOORS            0x00000004
#define ROOM_PRIVATE            0x00000008
#define ROOM_SAFE               0x00000010
#define ROOM_FOREVER_LIGHT      0x00000020
#define ROOM_NO_RECALL          0x00000040
#define ROOM_DEPOSIT_MONEY      0x00000080
#define ROOM_STOREROOM          0x00000100
#define ROOM_NOFIGHT            0x00000200
#define ROOM_NOQUIT             0x00000400
#define ROOM_CLUB               0x00000800
#define ROOM_MEMORIZE           0x00001000
#define ROOM_STOCK              0x00002000
#define ROOM_NO_WHERE           0x00004000
#define ROOM_SAIL               0x00008000
#define ROOM_FANE               0x00010000
#define ROOM_KILLER             0x00020000

/* �ж�����V�ƭȪ� */
#define DIR_NORTH               0
#define DIR_EAST                1
#define DIR_SOUTH               2
#define DIR_WEST                3
#define DIR_UP                  4
#define DIR_DOWN                5
#define DIR_ENTER               6
#define DIR_OUT                 7
#define DIR_MAX                 8


/* �ж��X�f���ƭȹ�Ӫ� */
#define EX_ISDOOR               0x00000001
#define EX_CLOSED               0x00000002
#define EX_LOCKED               0x00000004
#define EX_PICKPROOF            0x00000020

/* �ж��a�Ϋ��A���ƭȪ� */
#define SECTION_FLY             0x00000001
#define SECTION_SWIM            0x00000002
#define SECTION_NEWHAND         0x00000004

/* ���~�˳Ƹ�����m�ƭȪ�, -1 �N���S�� */
#define WEAR_NONE               -1
#define WEAR_LIGHT              0
#define WEAR_FINGER_L           1
#define WEAR_FINGER_R           2
#define WEAR_NECK_1             3
#define WEAR_NECK_2             4
#define WEAR_BODY               5
#define WEAR_HEAD               6
#define WEAR_LEGS               7
#define WEAR_FEET               8
#define WEAR_HANDS              9
#define WEAR_ARMS               10
#define WEAR_SHIELD             11
#define WEAR_ABOUT              12
#define WEAR_WAIST              13
#define WEAR_WRIST_L            14
#define WEAR_WRIST_R            15
#define WEAR_WIELD              16
#define WEAR_HOLD               17
#define WEAR_EARRING_L          18
#define WEAR_EARRING_R          19
#define MAX_WEAR                20

/* �ޯ�������� */
#define ATTACK_RANDOM           0x00000000
#define ATTACK_LIGHT            0x00000001
#define ATTACK_FINGER_L         0x00000002
#define ATTACK_FINGER_R         0x00000004
#define ATTACK_NECK_1           0x00000008
#define ATTACK_NECK_2           0x00000010
#define ATTACK_BODY             0x00000020
#define ATTACK_HEAD             0x00000040
#define ATTACK_LEGS             0x00000080
#define ATTACK_FEET             0x00000100
#define ATTACK_HANDS            0x00000200
#define ATTACK_ARMS             0x00000400
#define ATTACK_SHIELD           0x00000800
#define ATTACK_ABOUT            0x00001000
#define ATTACK_WAIST            0x00002000
#define ATTACK_WRIST_L          0x00004000
#define ATTACK_WRIST_R          0x00008000
#define ATTACK_WIELD            0x00010000
#define ATTACK_HOLD             0x00020000
#define ATTACK_EARRING_1        0x00040000
#define ATTACK_EARRING_2        0x00080000

/* �H�����A */
#define COND_DRUNK              0
#define COND_FULL               1
#define COND_THIRST             2

/* �H���ثe������ */
#define POS_DEAD                0
#define POS_SLEEPING            1
#define POS_RESTING             2
#define POS_FIGHTING            3
#define POS_STANDING            4

/* �N�z���ڥ\�� */
#define WIZ_SILENCE             0x00000001
#define WIZ_NOTELL              0x00000002
#define WIZ_NOEMOTE             0x00000004

#define MAX_TRIBUNAL            100                 /* �̤j�g�@�ɶ�     */
#define MAX_TRIBUNAL_PC         5                   /* �����v�O�̤j�g�@ */

/* �H���� ACT ���ƭȹ�Ӫ� */
#define PLR_IS_NPC              0x00000001          /* ����ó]�w */
#define PLR_BOUGHT_PET          0x00000002
#define PLR_AUCTION             0x00000004
#define PLR_AUTOEXIT            0x00000008
#define PLR_AUTOLOOT            0x00000010
#define PLR_AUTOSAC             0x00000020
#define PLR_BLANK               0x00000040
#define PLR_BRIEF               0x00000080
#define PLR_CHAT                0x00000100
#define PLR_COMBINE             0x00000200
#define PLR_PROMPT              0x00000400
#define PLR_TELNET_GA           0x00000800
#define PLR_HOLYLIGHT           0x00001000
#define PLR_WIZINVIS            0x00002000
#define PLR_SILENCE             0x00004000
#define PLR_NO_EMOTE            0x00008000
#define PLR_NO_SHOUT            0x00010000
#define PLR_NO_TELL             0x00020000
#define PLR_LOG                 0x00040000
#define PLR_DENY                0x00080000
#define PLR_FREEZE              0x00100000
#define PLR_THIEF               0x00200000
#define PLR_KILLER              0x00400000
#define PLR_BOLTER              0x00800000
#define PLR_EXACT               0x01000000
#define PLR_MESSAGE             0x02000000
#define PLR_FLEE                0x04000000
#define PLR_ANGEL               0x08000000
#define PLR_AUTOFOOD            0x10000000
#define PLR_AUTODRINK           0x20000000

#define PLR_COPYEQ              0x00000001

/* �w�q�� turn �o���ܼƥΪ� */
#define PLR_REBIRTH             0x00000001
#define PLR_TRAIN               0x00000002
#define PLR_PRACTICE            0x00000004
#define PLR_ANSI                0x00000008
#define PLR_LOTTO               0x00000010

/* �W�D�ƭȹ�Ӫ� */
#define CHANNEL_AUCTION         0x00000001
#define CHANNEL_CHAT            0x00000002
#define CHANNEL_BULLETIN        0x00000004
#define CHANNEL_IMMTALK         0x00000008
#define CHANNEL_MUSIC           0x00000010
#define CHANNEL_QUESTION        0x00000020
#define CHANNEL_SHOUT           0x00000040
#define CHANNEL_YELL            0x00000080
#define CHANNEL_GAMBLE          0x00000100
#define CHANNEL_CLASS           0x00000200
#define CHANNEL_CLUB            0x00000400
#define CHANNEL_SEMOTE          0x00000800
#define CHANNEL_WEATHER         0x00001000
#define CHANNEL_PHONE           0x00002000
#define CHANNEL_SUICIDE         0x00004000
#define CHANNEL_RUMOR           0x00008000
#define CHANNEL_NOTICE          0x00010000
#define CHANNEL_GROUP           0x00020000
#define CHANNEL_PK              0x00040000

/* �W�ߨƥ��]�� */
#define STONE_SPEED              1                   /* �[�t��   */
#define STONE_STRENGTH           2                   /* �[�O�q   */
#define STONE_CON                3                   /* �[���   */
#define STONE_WIS                4                   /* �[����   */
#define STONE_LUCKY              5                   /* ���B     */
#define STONE_PARRY              6                   /* ���     */
#define STONE_BLOCK              7                   /* �Z����� */
#define STONE_REVERSEHPMP        8                   /* �ƭȤ��� */
#define STONE_REVERSEHPMOVE      9                   /* �ƭȤ��� */
#define STONE_MAGIC             10                   /* �[�]�O   */
#define STONE_HPUP              11                   /* �[�ͩR�O */
#define STONE_MANAUP            12                   /* �[�k�O   */
#define STONE_MOVEUP            13                   /* �[��O   */
#define STONE_LIMITGAINUP       14                   /* �W�[���� */
#define STONE_REKICK            15                   /* ����     */
#define STONE_DEFEND            16                   /* ���m     */
#define STONE_MONEYUP           17                   /* �����W�[ */
#define STONE_EXPUP             18                   /* �g��W�[ */
#define STONE_UNDEATH           19                   /* ����     */
#define STONE_STEAL             20                   /* ����     */
#define STONE_KNOW              21                   /* �s�ݹ�� */
#define STONE_POWER             22                   /* �ĤO�@�� */
#define STONE_CHANGE            23                   /* ���ƹ�� */
#define STONE_TWOMAGIC          24                   /* �ӷl��b */
#define STONE_TWOATTACK         25                   /* �ӷl��b */
#define STONE_TWOSUMMON         26                   /* �ӷl��b */
#define STONE_THROW             27                   /* ���Y     */
#define STONE_ARMOR             28                   /* ���m�W�@ */
#define STONE_STEALMP           29                   /* ���Ѫk�O */
#define STONE_STEALHP           30                   /* ���ѥͩR */
#define STONE_STEALMOVE         31                   /* ������O */
#define STONE_MPPOWERUP         32                   /* �¤O�W�@ */
#define STONE_MOVEPOWERUP       33                   /* �¤O�W�@ */
#define STONE_DEATH             34                   /* ���z     */
#define STONE_WITH              35                   /* �t�X�¤O */
#define STONE_HITROLL           36                   /* �[�j�R�� */

/* �����]�� */
#define STONE_FIRE              37                   /* ���t�]�k */
#define STONE_LIGHTNING         38                   /* �p�t�]�k */
#define STONE_ICE               39                   /* �B�t�]�k */
#define STONE_EARTH             40                   /* �g�t�]�k */
#define STONE_POISON            41                   /* �r�t�]�k */
#define STONE_LIGHT             42                   /* ���t�]�k */
#define STONE_DARKNESS          43                   /* ��t�]�k */
#define STONE_SAINT             44                   /* �t�t�]�k */
#define STONE_EVIL              45                   /* ���t�]�k */
#define STONE_VOID              46                   /* ��L�]�k */
#define STONE_WIND              47                   /* ���t�]�k */
#define STONE_BEST              48                   /* �s���]�k */
#define STONE_WATER             49                   /* ���t�]�k */
#define STONE_NOATTR            50                   /* �L�ݩ�   */

/* ��_�λ��U�]�� */
#define STONE_HEAL              51                   /* �^�_�ͩR */
#define STONE_RECOVER           52                   /* �^�_��O */
#define STONE_MEDITATION        53                   /* �^�_�k�O */
#define STONE_CURE_POISON       54                   /* ���r�]�k */
#define STONE_PRAY              55                   /* ��ë�]�k */
#define STONE_BESTHEAL          56                   /* �s���^�_ */
#define STONE_CURE_POSITION     57                   /* �^�_���A */
#define STONE_DISPALMAGIC       58                   /* �h���]�k */
#define STONE_ARMORSPELL        59                   /* ���m�]�k */
#define STONE_CALLDEATH         60                   /* �����]�k */
#define STONE_BESTARMOR         61                   /* �s�����m */
#define STONE_REBIRTH           62                   /* �_���]�k */
#define STONE_MINIMIZE          63                   /* �Y�p�]�k */
#define STONE_ESCAPE            64                   /* �k�]�]�k */
#define STONE_SILENCE           65                   /* �H�q�]�k */

/* �l���]�� */
#define STONE_SUMMONEAGLE       66                   /* �l����N */
#define STONE_SUMMONLION        67                   /* �l���l */
#define STONE_SUMMONCOLD        68                   /* �l�곷�k */
#define STONE_SUMMONFIRE        69                   /* �̥����S */
#define STONE_SUMMONLAM         70                   /* �l��ԩi */
#define STONE_SUMMONTAITAN      71                   /* �l����Z */
#define STONE_SUMMONOODIN       72                   /* �l��ڤB */
#define STONE_SUMMONSNAKE       73                   /* �l����D */
#define STONE_SUMMONBAHAMUT     74                   /* �ګ��i�S */
#define STONE_SUMMONCOW         75                   /* �l�꯫�� */
#define STONE_SUMMONSAINT       76                   /* �t���f�P */
#define STONE_SUMMONFIREBIRD    77                   /* ��ͤ��� */
#define STONE_SUMMONBAHAMUT2    78                   /* �ګ��i�SII */
#define STONE_SUMMONEVILKING    79                   /* �l��ߤ� */
#define STONE_SUMMONTWOFACE     80                   /* �Ѧa�Y�a */
#define STONE_SUMMONBAHAMUTZERO 81                   /* �ګ��i�S�s�� */
#define STONE_SUMMONRIDER       82                   /* ���Z�h */
#define STONE_BESTSUMMON        83                   /* �s���l�� */
#define STONE_SUMMONGOLEM       84                   /* �l��ۤH */

/* �Z���ޯ�˳ƨϥέ���c�ŧi */
struct restrict_data
{
  RESTRICT_DATA * next;
  int             occasion;     /* ����ɾ�     */
  int             type;         /* ����A       */
  int             value;        /* ����ƭ�       */
  int             vicevalue;    /* ����Ƽƭ�   */
};

struct job_data
{
  JOB_DATA * next;
  char     * keyword;
  int        position;
  JOB_FUN  * function;
};

struct job_message
{
  ROOM_INDEX_DATA * room;
  CHAR_DATA       * mob;
  OBJ_DATA        * obj;
};

struct enroll_data
{
  ENROLL_DATA * next;
  char          name[NAME_LENGTH+1];
};

struct stock_data
{
  char * name;
  int    cost;
  int    sell;
  int    buy;
  int    today_sell;
  int    today_buy;
  int    win;
  int    lost;
  int    history[MAX_STOCK_HISTORY];
  bool   lock;
};

/* ������� */
#define RES_STR                 1                    /* ��O�q������   */
#define RES_INT                 2                    /* �ﴼ�O������   */
#define RES_WIS                 3                    /* ����Ѥ�����   */
#define RES_DEX                 4                    /* ��ӱ�������   */
#define RES_CON                 5                    /* ����椧����   */
#define RES_HP                  6                    /* ��ͩR������   */
#define RES_MANA                7                    /* ��k�O������   */
#define RES_MOVE                8                    /* ����O������   */
#define RES_CLASS               9                    /* ��¾�~������   */
#define RES_TRUST              10                    /* ��H���Ȥ����� */
#define RES_SKILL              11                    /* ��ޯध����   */
#define RES_SEX                12                    /* ��ʧO������   */
#define RES_LEVEL              13                    /* �ﵥ�Ť�����   */
#define RES_NOSKILL            14                    /* �۫g�ޯ୭��   */
#define RES_ALIGN              15                    /* �}�窺����     */

/* MOB �쫬���c���ŧi */
struct  mob_index_data
{
  MOB_INDEX_DATA * next;
  SPEC_FUN       * spec_fun;
  SHOP_DATA      * pShop;
  TEACH_DATA     * teach;
  ENABLE_DATA    * enable;
  JOB_DATA       * job;
  CLASS_DATA     * class;
  AREA_DATA      * area;
  char           * player_name;
  char           * short_descr;
  char           * long_descr;
  char           * description;
  char           * filename;
  char           * deadmsg;
  char           * auction;
  sh_int           vnum;
  sh_int           reborn_vnum;
  sh_int           reborn_room;
  sh_int           count;
  sh_int           killed;
  sh_int           sex;
  sh_int           now_str;
  sh_int           now_int;
  sh_int           now_wis;
  sh_int           now_dex;
  sh_int           now_con;
  sh_int           level;
  sh_int           damroll;
  sh_int           country_alignment;
  sh_int           fight_flags;
  int              hit;
  int              mana;
  int              move;
  int              act;
  int              affected_by;
  int              tractable;
  int              multipile;
  int              migrate;
  int              attack_ratio;
  int              dodge_ratio;
  int              skill[MAX_SKILL];
  sh_int           alignment;
  sh_int           hitroll;                /* Unused */
  sh_int           ac;                     /* Unused */
  sh_int           hitnodice;              /* Unused */
  sh_int           hitsizedice;            /* Unused */
  sh_int           hitplus;                /* Unused */
  sh_int           damnodice;              /* Unused */
  sh_int           damsizedice;            /* Unused */
  sh_int           damplus;                /* Unused */
  int              gold;                   /* Unused */
  MPROG_DATA *     mobprogs;               /* Used by MOBprogram */
  int              progtypes;              /* Used by MOBprogram */
  bool             speak : 1;
};

/* ���a�άO�����Ǫ����������c */
struct  char_data
{
  CHAR_DATA       * next;
  bool              delete;
  int               counter;
  CHAR_DATA       * next_in_room;
  CHAR_DATA       * master;
  CHAR_DATA       * leader;
  CHAR_DATA       * fighting;
  CHAR_DATA       * reply;
  CHAR_DATA       * mount;
  CHAR_DATA       * mount_by;
  CHAR_DATA       * spirit;
  CHAR_DATA       * boss;
  CHAR_DATA       * mercenary;
  CHAR_DATA       * hirer;
  SPEC_FUN        * spec_fun;
  MOB_INDEX_DATA  * pIndexData;
  DESCRIPTOR_DATA * desc;
  AFFECT_DATA     * affected;
  NOTE_DATA       * pnote;
  VOTE_DATA       * vote;
  OBJ_DATA        * carrying;
  OBJ_DATA        * deposit;
  ROOM_INDEX_DATA * in_room;
  ROOM_INDEX_DATA * was_in_room;
  ROOM_INDEX_DATA * social;
  PC_DATA         * pcdata;
  ALIAS_DATA      * alias;
  IP_DATA         * connect;
  ENABLE_DATA     * enable;
  GAMBLE_DATA     * gamble;
  CLUB_DATA       * club;
  CLASS_DATA      * class;
  ENROLL_DATA     * enroll;
  QUEST_DATA      * quest;
  ENEMY_DATA      * enemy;
  FRIEND_DATA     * friend;
  BOUNTY_DATA     * bounty;
  FAILCODE_DATA   * failcode;
  STAMP_DATA      * stamp;
  BASIC_DATA      * basic;
  ANSWER_DATA     * answer;
  SERIAL_DATA       serial;
  SERIAL_DATA       jade;
  char            * name;
  char            * cname;
  char            * short_descr;
  char            * long_descr;
  char            * description;
  char            * prompt;
  char            * email;
  char            * talk_buf;
  char            * editing;
  char            * stack;
  char            * notepad[MAX_NOTEPAD];
  char              talk_mode;
  sh_int            now_str;
  sh_int            now_int;
  sh_int            now_wis;
  sh_int            now_dex;
  sh_int            now_con;
  sh_int            sex;
  sh_int            level;
  sh_int            trust;
  sh_int            adviser;
  int               wizflags;
  int               tribunal_timer;
  int               played;
  int               dormancy;
  int               rechristen;
  int               home;
  int               pills;
  int               dosage;
  int               mask;
  time_t            logon;
  time_t            save_time;
  time_t            last_note;
  time_t            last_joke;
  time_t            last_clubnote;
  sh_int            timer;
  sh_int            wait;
  sh_int            eq_capcity;
  int               fight_tick;
  int               hit;
  int               mod_hit;
  int               max_hit;
  int               mana;
  int               mod_mana;
  int               max_mana;
  int               move;
  int               mod_move;
  int               max_move;
  int               limit;
  int               gold;
  int               bank;
  int               exp;
  int               act;
  int               affected_by;
  int               practice;
  int               notify;
  int               dodge;
  int               tractable;
  int               situs;
  int               clublog;
  int               firman;
  int               jail;
  int               failed;
  int               xname;
  int               steal;
  int               murder;
  int               spiritjade;
  int               migrate;
  int               angel_set;
  int               angel_left;
  int               recall[MAX_RECALL];
  int               stock[MAX_STOCK];
  int               asset[MAX_STOCK];
  int               skill[MAX_SKILL];
  int               board[MAX_BOARD];
  int               ante[2];
  int               fight_win;
  int               fight_lost;
  int               file_size;
  int               nskill;
  int               autosave;
  int               autosave_tick;
  int               autobackup;
  int               autobackup_tick;
  int               donate;
  sh_int            position;
  sh_int            carry_weight;
  sh_int            carry_number;
  sh_int            saving_throw;
  sh_int            turn;
  int               alignment;
  int               hitroll;
  int               damroll;
  int               armor;
  int               wimpy;
  int               deaf;
  MPROG_ACT_LIST  * mpact;                  /* Used by MOBprogram */
  int               mpactnum;               /* Used by MOBprogram */
  bool              speak    : 1;
  bool              cease    : 1;
  bool              trade    : 1;
};

/* ���a�M������Ƶ��c */
struct  pc_data
{
  PC_DATA    * next;
  TRACE_DATA * trace;
  TRACE_DATA * map[MAX_TRACE];
  OBJ_DATA   * corpse;
  CHAR_DATA  * mate;
  CHAR_DATA  * wooer;
  char       * pwd;
  char       * bamfin;
  char       * bamfout;
  char       * title;
  char       * lasthost;
  char       * mater;
  int          pkwin;
  int          pklost;
  int          kills;
  int          kill_level;
  int          ply;
  int          imprison;
  sh_int       deny;
  sh_int       suspect;
  sh_int       mod_str;
  sh_int       mod_int;
  sh_int       mod_wis;
  sh_int       mod_dex;
  sh_int       mod_con;
  sh_int       condition[3];
  sh_int       pagelen;
  bool         contract;
};

/* �Ǫ��{�������c */
struct  mob_prog_act_list
{
  MPROG_ACT_LIST * next;
  char           * buf;
  CHAR_DATA      * ch;
  OBJ_DATA       * obj;
  void           * vo;
};

struct  mob_prog_data
{
  MPROG_DATA * next;
  char       * arglist;
  char       * comlist;
  int          type;
};

bool    MOBtrigger;

#define ERROR_PROG              -1
#define IN_FILE_PROG            0
#define ACT_PROG                0x00000001
#define SPEECH_PROG             0x00000002
#define RAND_PROG               0x00000004
#define FIGHT_PROG              0x00000008
#define DEATH_PROG              0x00000010
#define HITPRCNT_PROG           0x00000020
#define ENTRY_PROG              0x00000040
#define GREET_PROG              0x00000080
#define ALL_GREET_PROG          0x00000100
#define GIVE_PROG               0x00000200
#define BRIBE_PROG              0x00000400

/* �G�� */
struct liq_data
{
  LIQ_DATA  * next;
  char      * name;
  char      * color;
  int         slot;
  int         drunk;
  int         full;
  int         thirst;
  bool        water;
};

struct body_type
{
  char * eq_name;
  char * situs_name;
  int    location;
  int    chance;
};

/* �ж��άO���~���B�~�y�z */
struct  extra_descr_data
{
  EXTRA_DESCR_DATA * next;
  char             * keyword;
  char             * description;
};

/* ���~���쫬���c */
struct  obj_index_data
{
  OBJ_INDEX_DATA   * next;
  EXTRA_DESCR_DATA * extra_descr;
  AFFECT_DATA      * affected;
  AFFECT_DATA      * impact;
  JOB_DATA         * job;
  RESTRICT_DATA    * restrict;
  MESSAGE_DATA     * message;
  char             * name;
  char             * short_descr;
  char             * long_descr;
  char             * description;
  char             * filename;
  char             * wearmsg;
  char             * remmsg;
  char             * unit;
  sh_int             vnum;
  sh_int             item_type;
  int                extra_flags;
  sh_int             other_flags;
  int                wear_flags;
  sh_int             count;
  sh_int             weight;
  sh_int             level;
  int                exp;
  int                cost;
  int                armor;
  int                value[ MAX_OBJECT_VALUE ];
  bool               disappear : 1;
};

/* �u�����~�����c */
struct  obj_data
{
  OBJ_DATA         * next;
  bool               delete;
  int                counter;
  OBJ_DATA         * next_content;
  OBJ_DATA         * contains;
  OBJ_DATA         * in_obj;
  CHAR_DATA        * carried_by;
  CHAR_DATA        * deposit_by;
  CHAR_DATA        * corpse_owner;
  CHAR_DATA        * address;
  EXTRA_DESCR_DATA * extra_descr;
  AFFECT_DATA      * affected;
  OBJ_INDEX_DATA   * pIndexData;
  ROOM_INDEX_DATA  * in_room;
  CLUB_DATA        * club;
  SERIAL_DATA        serial;
  SERIAL_DATA        owner;
  CACHET_DATA      * cachet;
  char             * name;
  char             * short_descr;
  char             * description;
  char             * unit;
  sh_int             item_type;
  int                extra_flags;
  sh_int             wear_flags;
  sh_int             wear_loc;
  sh_int             weight;
  sh_int             level;
  sh_int             timer;
  int                cost;
  int                max_armor;
  int                armor;
  int                venom;
  int                value   [ MAX_OBJECT_VALUE ];
  bool               disappear : 1;
};

/* �X�f��Ƶ��c */
struct  exit_data
{
  ROOM_INDEX_DATA * to_room;
  sh_int            vnum;
  sh_int            exit_info;
  sh_int            key;
  char            * keyword;
  char            * description;
  char            * message;
  bool              foggy;
};

/*
 * Reset commands:
 *   '*': comment
 *   'M': read a mobile
 *   'O': read an object
 *   'P': put object in object
 *   'G': give object to mobile
 *   'E': equip object to mobile
 *   'D': set state of door
 *   'R': randomize room exits
 *   'S': stop (end of list)
 */

/* �ϰ� reset �R�O���w�q */
struct  reset_data
{
  RESET_DATA * next;
  char         command;
  char       * filename;
  sh_int       arg1;
  sh_int       arg2;
  sh_int       arg3;
};

/* �ϰ�w�q */
struct  area_data
{
  AREA_DATA       * next;
  RESET_DATA      * reset_first;
  RESET_DATA      * reset_last;
  ROOM_INDEX_DATA * list;
  ROOM_INDEX_DATA * capital;
  MINERAL_DATA    * mineral;
  char            * name;
  char            * filename;
  char            * editor;
  char            * description;
  int               serial;
  int               capital_no;
  int               flag;
  int               upper;
  int               lower;
  int               age;
  int               nplayer;
  int               attribute;
  int               room;
  int               mob;
  int               obj;
  int               shop;
  int               reset;
  int               mine;
  int               foggy;
};

/* �ж��쫬��Ƶ��c */
struct  room_index_data
{
  ROOM_INDEX_DATA  * next;
  ROOM_INDEX_DATA  * next_in_area;
  CHAR_DATA        * people;
  OBJ_DATA         * contents;
  EXTRA_DESCR_DATA * extra_descr;
  AREA_DATA        * area;
  EXIT_DATA        * exit[8];
  JOB_DATA         * job;
  CLUB_DATA        * club;
  BOARD_DATA       * board;
  MINE_DATA        * mine;
  SECTOR_DATA      * sector;
  ENQUIRE_DATA     * enquire;
  char             * name;
  char             * description;
  char             * filename;
  int                vnum;
  int                room_flags;
  int                light;
};

/* ansi code ����Ƶ��c */
struct ansi_data
{
  char * code;
};

/* �զ�L����Ƶ��c */
struct palette_data
{
  char character;
  int  color;
};

/* �ޯ�ˮ`��Ƶ��c */
struct damage_data
{
  DAMAGE_DATA    * next;
  OBJ_INDEX_DATA * innate;
  ROUTINE_FUN    * routine;
  EFFECT_DATA    * effect;
  char           * description;
  int              chance;
  int              value;
  int              vicevalue;
  int              situs;
  int              parry;
  int              multiple;
  int              obj_vnum;
};

#define MAX_SCAN_COUNT          200
#define MAX_SCAN_DEPTH          20

struct scan_data
{
  int vnum;
  int depth;
  int dir[MAX_SCAN_DEPTH];
};

/*
 * Types of attacks.
 * Must be non-overlapping with spell/skill types,
 * but may be arbitrary beyond that.
 */
#define TYPE_UNDEFINED          -1
#define TYPE_HIT                1000
#define TYPE_HIT_COST           3

/* �k�N�I�k���κA */
#define TAR_IGNORE              0
#define TAR_CHAR_OFFENSIVE      1
#define TAR_CHAR_DEFENSIVE      2
#define TAR_CHAR_SELF           3
#define TAR_OBJ_INV             4
#define TAR_DODGE               5
#define TAR_STRING              6
#define TAR_FLEE                7
#define TAR_ARGUMENT            8
#define TAR_MEDITATION          9
#define TAR_OBJ_ROOM            10
#define TAR_MOUNT               11
#define TAR_NO_CAST             12

/* �k�N���Ӫ��κA */
#define COST_HIT                0
#define COST_MANA               1
#define COST_MOVE               2
#define COST_GOLD               3

/* �ޯ��Ƶ��c */
struct  skill_data
{
  SKILL_DATA    * next;
  SPELL_FUN     * function;           /* �k�N�I�k�����         */
  CHECK_FUN     * check;              /* �I�k�T�{���           */
  LIMIT_DATA    * limit;              /* �U¾�~������           */
  DAMAGE_DATA   * damage;             /* �ˮ`�T��               */
  RESTRICT_DATA * restrict;           /* ������               */
  char          * name;               /* �^��W��               */
  char          * cname;              /* ����W��               */
  char          * msg_off;            /* �k�N�������T��         */
  char          * help;               /* �D�U��T               */
  char          * message;            /* �����T��               */
  int             slot;               /* �k�N���s��             */
  int             position;           /* �k�N�һݳ̧C���A       */
  int             type;               /* �k�N�����O             */
  int             cost_type;          /* �I�k�үӪ����A         */
  int             cost;               /* �I�k�үӪ��I��         */
  int             wait;               /* �I�k�᪺����ɶ�       */
  int             exp;                /* �I�k����o�g��Ȫ����v */
  int             associate;          /* ���s���k�N�s��         */
  int             degree;             /* ���s���{��, �d�����@   */
  int             weapon;             /* �Z��                   */
  int             chance;             /* ���v���`�M             */
  int             affect;             /* �k�N�������X           */
  int             affect_id;          /* �I�k�����s��, ���~��� */
  int             rating;             /* �ѧO���X               */
  int             antirating;         /* �۫g�ޯ�               */
  int             choosen;            /* ������H��             */
  int             adeptation;         /* �����w�]���m��       */
  int             ply;                /* �m�ߪ����v             */
  int             qutoient;           /* �m�ߵ��Ū��Ӽ�         */
  bool            teach         : 1;  /* �O�_�i�H���۱о�       */
  bool            enable        : 1;  /* �O�_�i�H�Q�P��         */
  bool            say_spell     : 1;  /* �O�_�n��X�G�y         */
  bool            concentration : 1;  /* �O�_�|�N�Ӥ�����       */
  bool            cast          : 1;  /* �O�_�i�H�� cast �I�i   */
  bool            innate        : 1;  /* �O�_���w�]�ޯ�         */
  bool            canask        : 1;  /* �O�_�i�H�d��           */
  bool            valid         : 1;  /* �O�_�}��               */
};

/* �@�Ǳ`�Ϊ����� */
#define UMIN(a, b)              ((int) (a) < (int) (b) ? (a) : (b))
#define UMAX(a, b)              ((int) (a) > (int) (b) ? (a) : (b))
#define URANGE(a, b, c)         ((b) < (a) ? (a) : ((b) > (c) ? (c) : (b)))
#define LOWER(c)                ((c) >= 'A' && (c) <= 'Z' ? (c)+'a'-'A' : (c))
#define UPPER(c)                ((c) >= 'a' && (c) <= 'z' ? (c)+'A'-'a' : (c))
#define IS_SET(flag, bit)       ((flag) & (bit))
#define IS_ERROR( num )         ( ( num ) == ERRORCODE )
#define SET_BIT(var, bit)       ((var) |= (bit))
#define REMOVE_BIT(var, bit)    ((var) &= ~(bit))
#define SWAP( x , y )           { ( (x) = ( (x) - (y) ) ); \
                                  ( (y) = ( (x) + (y) ) ); \
                                  ( (x) = ( (y) - (x) ) ); }
#define SQUARE(x)               ( (x) * (x) )
#define NOSPACE( c )            while ( *(c) == ' ' || *(c) == '\t' ) (c)++
#define YESNO( comp )           ( ( comp ) ? "��" : "��" )

/* �����H������ */
#define IS_NPC(ch)              (IS_SET((ch)->act, ACT_IS_NPC))
#define IS_IMMORTAL(ch)         (get_trust(ch) >= LEVEL_IMMORTAL)
#define IS_GOD(ch)              ( (ch)->level >= MAX_LEVEL )
#define IS_HERO(ch)             (get_trust(ch) >= LEVEL_HERO)
#define IS_AFFECTED(ch, sn)     (IS_SET((ch)->affected_by, (sn)))
#define IS_MALE(ch)             (ch->sex == SEX_MALE )
#define IS_FEMALE(ch)           (ch->sex == SEX_FEMALE )

#define IS_GOOD(ch)             (ch->alignment >= 350)
#define IS_EVIL(ch)             (ch->alignment <= -350)
#define IS_NEUTRAL(ch)          (!IS_GOOD(ch) && !IS_EVIL(ch))

#define IS_AWAKE(ch)            (ch->position > POS_SLEEPING)
#define IS_REST(ch)             ( (ch)->position == POS_SLEEPING ||         \
                                  (ch)->position == POS_RESTING )
#define IS_OUTSIDE(ch)          ( !IS_SET( ( ch )->in_room->room_flags,     \
                                  ROOM_INDOORS))
#define WAIT_STATE(ch, npulse)  ((ch)->wait = UMAX((ch)->wait, (npulse)))
#define SECTOR( pSector )       ( get_sector_index( ( pSector ) ) )

/* ���~������ */
#define CAN_WEAR(obj, part)     (IS_SET((obj)->wear_flags,  (part)))
#define IS_OBJ_STAT(obj, stat)  (IS_SET((obj)->extra_flags, (stat)))

/* �y�z������ */
#define NAME( ch )  ( IS_NPC(ch) ? (ch)->short_descr : (ch)->cname )
#define REALNAME( ch )  ( IS_NPC(ch) ? (ch)->short_descr : (ch)->name )
#define PERS(ch, looker)        ( can_see( looker, (ch) ) ?             \
                                ( IS_NPC(ch) ? (ch)->short_descr        \
                                : (ch)->cname ) : "�Y�����W�H��" )

struct cmd_data
{
  CMD_DATA * next;
  char     * name;
  char     * cname;
  char     * help;
  DO_FUN   * function;
  int        position;
  int        level;
  int        log;
  int        exec;
  bool       canlock  : 1;
  bool       lock     : 1;
  bool       exact    : 1;
  bool       argument : 1;
  bool       mobonly  : 1;
  bool       chat     : 1;
  bool       wizlog   : 1;
  bool       jail     : 1;
  bool       dead     : 1;
  bool       order    : 1;
  bool       lost     : 1;
  bool       limit    : 1;
};

/* ������O�����c */
struct  social_data
{
  SOCIAL_DATA * next;
  char        * name;
  char        * chinese_name;
  char        * char_no_arg;
  char        * others_no_arg;
  char        * char_found;
  char        * others_found;
  char        * vict_found;
  char        * char_auto;
  char        * others_auto;
};

/* �ϰ�`�� */
extern  const   struct  body_type       situs           [];
extern  const   struct  social_data     social_table    [];
extern  char *  const                   attr_name       [MAX_ATTR];

/* �����ܼ� */
extern          HELP_DATA         *     help_first;
extern          HELP_DATA         *     help_last;
extern          BAN_DATA          *     ban_list;
extern          GREETING_DATA     *     greeting_list;
extern          SERVER_DATA       *     server_list;
extern          TOP_DATA          *     top_list;
extern          XNAMES_DATA       *     xnames_first;
extern          CHAR_DATA         *     char_list;
extern          SKILL_DATA        *     skill_list;
extern          SKILL_DATA        *     skill_last;
extern          CMD_DATA          *     cmd_list;
extern          CMD_DATA          *     cmd_last;
extern          DESCRIPTOR_DATA   *     descriptor_list;
extern          NOTE_DATA         *     note_list;
extern          VOTE_DATA         *     vote_list;
extern          JOKE_DATA         *     joke_list;
extern          BOARD_DATA        *     board_list;
extern          BOARD_DATA        *     board_last;
extern          OBJ_DATA          *     object_list;
extern          SOCIAL_DATA       *     social_first;
extern          SOCIAL_DATA       *     social_last;
extern          ANGEL_DATA        *     angel_list;
extern          BUS_DATA          *     bus_first;
extern          BUS_DATA          *     bus_last;
extern          CLUB_DATA         *     club_list;
extern          QUEST_INFO        *     quest_list;
extern          QUESTION_DATA     *     question_list;
extern          GIFT_DATA         *     gift_list;
extern          BOUNTY_DATA       *     bounty_list;
extern          EVENT_DATA        *     event_list;
extern          IMMLIST_DATA      *     imm_list;
extern          IMMLIST_DATA      *     imm_last;
extern          SALE_DATA         *     sale_list;
extern          VARIABLE_DATA     *     variable_list;
extern          WANTED_DATA       *     wanted_list;
extern          SHIP_DATA         *     ship_list;
extern          NET_DATA          *     net_list;
extern          SECTOR_DATA       *     sector_list;
extern          SECTOR_DATA       *     DefaultSector;
extern          CLASS_DATA        *     class_list;
extern          CLASS_DATA        *     class_demos;
extern          CLASS_DATA        *     class_force;
extern          LIQ_DATA          *     liq_list;
extern          LIQ_DATA          *     liq_water;
extern          ADDRESS_DATA      *     address_list;
extern          time_t                  current_time;
extern          time_t                  mud_boot_time;
extern          time_t                  reboot_time;
extern          time_t                  shutdown_time;
extern          int                     SaleChance;
extern          int                     SaleLimit;
extern          bool                    first_warn;
extern          bool                    second_warn;
extern          bool                    third_warn;
extern          bool                    AngelComing;
extern          bool                    AutoBackup;
extern          bool                    CheckServer;
extern          bool                    GetFQDN;
extern          int                     AngelTimes;
extern          int                     MaxConnect;
extern          long                    mud_boot_tick;
extern          bool                    fLogAll;
extern          FILE *                  fpReserve;
extern          KILL_DATA               kill_table      [];
extern          TIME_INFO_DATA          time_info;
extern          WEATHER_DATA            weather_info;
extern          AUCTION_DATA          * auction_info;
extern          FIGHT_DATA            * fight_info;
extern          AREA_DATA *             area_first;
extern          AREA_DATA *             area_last;
extern          HERO_DATA *             hero_first;
extern          HERO_DATA *             hero_last;
extern          SHOP_DATA *             shop_first;
extern          SHOP_DATA *             shop_last;
extern          PW_DATA   *             pw_list;
extern          GR_DATA   *             gr_list;
extern          bool                    merc_exec;
extern          STOCK_DATA              stock_data[MAX_STOCK];
extern          char                  * welcome_message;
extern          char                  * welcome_immortal;
extern          size_t                  hold_day;
extern          size_t                  file_quota;
extern          int                     max_notes;
extern          int                     Rechristen;
extern          int                     load_hit_plus;
extern          int                     load_mana_plus;
extern          int                     load_move_plus;
extern          int                     MaxPractice;
extern          int                     MaxNSkill;
extern          int                     MaxFirman;
extern          int                     HeroFirman;
extern          int                     FoodDegrade;
extern          int                     BornAge;
extern          int                     DefaultHit;
extern          int                     DefaultMana;
extern          int                     DefaultMove;
extern          int                     DefaultGold;
extern          int                     DefaultStr;
extern          int                     DefaultInt;
extern          int                     DefaultWis;
extern          int                     DefaultDex;
extern          int                     DefaultCon;
extern          int                     MaxStr;
extern          int                     MaxInt;
extern          int                     MaxWis;
extern          int                     MaxDex;
extern          int                     MaxCon;
extern          int                     MaxHit;
extern          int                     MaxMana;
extern          int                     MaxMove;
extern          int                     DefaultObject[MAX_DEFAULT_OBJECT];

/* ini.c */
extern          int                     MudPort[MAX_PORT];
extern          int                     MudConnect[MAX_PORT];
extern          int                     max_connect;
extern          int                     max_ip;
extern          int                     Increase;
extern          int                     IncreaseLimit;
extern          int                     DepositMoney;
extern          int                     EndowRate;
extern          int                     DonateMoney;
extern          int                     DonateBenifit;
extern          int                     DonateLevel;
extern          int                     DonateLimit;
extern          int                     DonateDuration;
extern          int                     DonateCount;
extern          bool                    DonateLock;
extern          int                     BankThreshold;
extern          int                     BankProfit;
extern          int                     SacGold;
extern          int                     MaxNumber;
extern          int                     FightRound;
extern          int                     FightDifferent;
extern          int                     FightRate;
extern          int                     FreeChar;
extern          int                     FreeObject;
extern          int                     FreeDesc;
extern          int                     FoggyRoom;
extern          AREA_DATA             * FoggyArea;
extern          int                     chat_penalty;
extern          int                     level_limit;
extern          int                     ipc_block;
extern          int                     ipc_idle;
extern          int                     max_stock_buy;
extern          int                     max_hire;
extern          bool                    internal_debug;
extern          bool                    wizlock;
extern          bool                    multilogin;
extern          bool                    strict_password;
extern          bool                    strict_email;
extern          bool                    tick_permit;
extern          char                    CurrentDir      [];
extern          char                    mud_name        [];
extern          char                    bbs_name        [];
extern          char                    home_dir        [];
extern          char                    help_dir        [];
extern          char                    sector_dir      [];
extern          char                    class_dir       [];
extern          char                    liq_dir         [];
extern          char                    social_dir      [];
extern          char                    angel_dir       [];
extern          char                    social_file     [];
extern          char                    area_dir        [];
extern          char                    board_dir       [];
extern          char                    board_lst       [];
extern          char                    board_sheet     [];
extern          char                    greet_dir       [];
extern          char                    vote_dir        [];
extern          char                    joke_dir        [];
extern          char                    note_dir        [];
extern          char                    mob_dir         [];
extern          char                    mob_ext         [];
extern          char                    room_dir        [];
extern          char                    room_ext        [];
extern          char                    obj_dir         [];
extern          char                    obj_ext         [];
extern          char                    joke_ext        [];
extern          char                    note_ext        [];
extern          char                    vote_ext        [];
extern          char                    help_ext        [];
extern          char                    angel_ext       [];
extern          char                    greet_ext       [];
extern          char                    sector_ext      [];
extern          char                    class_ext       [];
extern          char                    liquid_ext      [];
extern          char                    social_ext      [];
extern          char                    command_ext     [];
extern          char                    skill_ext       [];
extern          char                    reset_dir       [];
extern          char                    reset_ext       [];
extern          char                    shop_dir        [];
extern          char                    shop_ext        [];
extern          char                    mineral_dir     [];
extern          char                    mineral_ext     [];
extern          char                    dir_file        [];
extern          char                    player_dir      [];
extern          char                    index_file      [];
extern          char                    board_index     [];
extern          char                    null_file       [];
extern          char                    ideas_file      [];
extern          char                    typo_file       [];
extern          char                    newplayer_file  [];
extern          char                    symbol_file     [];
extern          char                    note_file       [];
extern          char                    check_file      [];
extern          char                    wizard_file     [];
extern          char                    bus_file        [];
extern          char                    gift_file       [];
extern          char                    bounty_file     [];
extern          char                    event_file      [];
extern          char                    ship_file       [];
extern          char                    purge_file      [];
extern          char                    quest_file      [];
extern          char                    question_file   [];
extern          char                    immlist_file    [];
extern          char                    sale_file       [];
extern          char                    club_file       [];
extern          char                    donate_file     [];
extern          char                    internal_file   [];
extern          char                    site_file       [];
extern          char                    station_file    [];
extern          char                    xname_file      [];
extern          char                    stock_file      [];
extern          char                    promotion_file  [];
extern          char                    net_file        [];
extern          char                    welcome_file    [];
extern          char                    welcome_imm     [];
extern          char                    address_file    [];
extern          char                    error_file      [];
extern          char                    hero_file       [];
extern          char                    bugs_file       [];
extern          char                    failload_file   [];
extern          char                    failexit_file   [];
extern          char                    failpass_file   [];
extern          char                    failenable_file [];
extern          char                    bad_file        [];
extern          char                    suspect_file    [];
extern          char                    MOBProgs_dir    [];
extern          char                    skill_dir       [];
extern          char                    skill_file      [];
extern          char                    ins_dir         [];
extern          char                    ins_file        [];
extern          char                    xname_log       [];
extern          char                    chat_log        [];
extern          char                    suicide_log     [];
extern          char                    wizflags_log    [];

/* load.c */
extern          ROOM_INDEX_DATA *       room_index_hash [MAX_KEY_HASH];
extern          OBJ_INDEX_DATA *        obj_index_hash  [MAX_KEY_HASH];
extern          MOB_INDEX_DATA *        mob_index_hash  [MAX_KEY_HASH];
extern void     set_exit_default        args( ( EXIT_DATA * ) );
extern void     set_room_default        args( ( ROOM_INDEX_DATA * ) );
extern void     set_immlist_default     args( ( IMMLIST_DATA  * ) );

#define SLOT_TWOSWORD                   1
#define SLOT_EVILFIST                   2
#define SLOT_FLOWER                     3
#define SLOT_FOUEN                      4
#define SLOT_DRAGON_BLADE               5
#define SLOT_SEVENCOLOR                 6
#define SLOT_NINE_STEP                  7
#define SLOT_LUNGSHAN                   8
#define SLOT_MOON_STEP                  9
#define SLOT_LINPO_STEPS               10
#define SLOT_GWHIP                     11
#define SLOT_G_STEPS                   12
#define SLOT_GDRAGON_STEPS             13
#define SLOT_RYO                       14
#define SLOT_NONAME                    15
#define SLOT_YOUNGGUN                  16
#define SLOT_CLOUD_STEPS               17
#define SLOT_LONGFIST                  18
#define SLOT_WINDLEG                   19
#define SLOT_TIGERBLADE                20
#define SLOT_MIRAGE_STEPS              21
#define SLOT_LOST_STEPS                22
#define SLOT_EIGHT_STEPS               23
#define SLOT_RULAI                     24
#define SLOT_NIGHT_STEPS               25
#define SLOT_PURPLE                    26
#define SLOT_B_A_1                     27
#define SLOT_CLOUD_GHOST               28
#define SLOT_BA_BLADE                  29
#define SLOT_SHOUTSKY                  30
#define SLOT_FLY_BLADE                 31
#define SLOT_BADSWORD                  32
#define SLOT_BE_NEEDLE                 33
#define SLOT_WIND_STEPS                34
#define SLOT_WINDCOLOR_STEPS           35
#define SLOT_COLOR_STEPS               36
#define SLOT_KING_FIST                 37
#define SLOT_KNOW_PEN                  38
#define SLOT_UNIVERSE                  39
#define SLOT_TIGER_AXE                 40
#define SLOT_TENDO_SLASH               41
#define SLOT_TAO_SPELL                 42
#define SLOT_MONKEY_STICK              43
#define SLOT_MING_SNAKE                44
#define SLOT_DRAGONLEG                 45
#define SLOT_DARK_WORD                 46
#define SLOT_DAYSTICK                  47
#define SLOT_DRAGON_DAGGER             48
#define SLOT_SKYDRAGON                 49
#define SLOT_SKYDRAGON_FORCE           50
#define SLOT_SKYDRAGON_SWORD           51
#define SLOT_DRAGONFIST                52
#define SLOT_DRAGONSLEEVE              53
#define SLOT_DREAM_BLADE               54
#define SLOT_DREAMDANCE                55
#define SLOT_DRUNK                     56
#define SLOT_DUANSUN_SWORD             57
#define SLOT_DUBAFIST                  58
#define SLOT_SIXFIRE                   59
#define SLOT_FAST_BLADE                60
#define SLOT_FIRE_LANCE                61
#define SLOT_FIRE_ICE                  62
#define SLOT_CLOUD_FIST                63
#define SLOT_SEVEN_DAGGER              64
#define SLOT_FLY_STEPS                 65
#define SLOT_FOLE_KEN                  66
#define SLOT_FONXANSWORD               67
#define SLOT_FROST_STEPS               68
#define SLOT_FUSWORDS                  69
#define SLOT_G_FINGER                  70
#define SLOT_GHOST_AXE                 71
#define SLOT_GHOST_MARIAL              72
#define SLOT_GHOST_STEPS               73
#define SLOT_GHOSTSTRIKE               74
#define SLOT_GODEAGLE_CLAW             75
#define SLOT_GOLD_BLADE                76
#define SLOT_GSWORD                    77
#define SLOT_HANZO_BLADE               78
#define SLOT_HATE_SWORD                79
#define SLOT_HELL_EVIL                 80
#define SLOT_HENMA_STEPS               81
#define SLOT_HER_BLADE                 82
#define SLOT_HUA_SWORD                 83
#define SLOT_HUNDRED_STEPS             84
#define SLOT_ICEBLADE                  85
#define SLOT_ICEFIST                   86
#define SLOT_YU_STEPS                  87
#define SLOT_YU_NEEDLE                 88
#define SLOT_SEVEN_MIND                89
#define SLOT_ICEFREEZE_STRIKE          90
#define SLOT_WUMIN_SWORD               91
#define SLOT_SEAFLOW_BLADE             92
#define SLOT_RAIN_THROWING             93
#define SLOT_SHA_STEPS                 94
#define SLOT_SHADOW_KILL               95
#define SLOT_SHADE_STEPS               96
#define SLOT_SKY_STEPS                 97
#define SLOT_SUN_BLADE                 98
#define SLOT_SNOW_MARTIAL              99
#define SLOT_SIX_FINGERS              100
#define SLOT_SLEEV_STEPS              101
#define SLOT_SHANSWORD                102
#define SLOT_MAKE_SPRING              103
#define SLOT_MAKE_LIGHT               104
#define SLOT_CAST_ARMOR               105
#define SLOT_CAST_BLESS               106
#define SLOT_CAST_FIRE                107
#define SLOT_CAST_LIGHTNING           108
#define SLOT_CONTROL_WEATHER          109
#define SLOT_LOCATE_OBJECT            110
#define SLOT_SUMMON                   111
#define SLOT_VENTRILOQUATE            112
#define SLOT_ACID_BLAST               113
#define SLOT_ACID_BREATH              114
#define SLOT_BLINDNESS                115
#define SLOT_BURNING_HANDS            116
#define SLOT_CALL_LIGHTNING           117
#define SLOT_CAUSE_CRITICAL           118
#define SLOT_CAUSE_LIGHT              119
#define SLOT_CAUSE_SERIOUS            120
#define SLOT_CHANGE_SEX               121
#define SLOT_CHARM_PERSON             122
#define SLOT_CHILL_TOUCH              123
#define SLOT_COLOUR_SPRAY             124
#define SLOT_CREATE_FOOD              125
#define SLOT_CREATE_WATER             126
#define SLOT_CURE_BLINDNESS           127
#define SLOT_CURE_CRITICAL            128
#define SLOT_CURE_LIGHT               129
#define SLOT_CURE_POISON              130
#define SLOT_CURE_SERIOUS             131
#define SLOT_CURSE                    132
#define SLOT_DETECT_EVIL              133
#define SLOT_DETECT_HIDDEN            134
#define SLOT_DETECT_INVIS             135
#define SLOT_DETECT_MAGIC             136
#define SLOT_DETECT_POISON            137
#define SLOT_DISPEL_EVIL              138
#define SLOT_DISPEL_MAGIC             139
#define SLOT_EARTHQUAKE               140
#define SLOT_ENCHANT_WEAPON           141
#define SLOT_ENERGY_DRAIN             142
#define SLOT_FAERIE_FIRE              143
#define SLOT_FAERIE_FOG               144
#define SLOT_FIRE_BREATH              145
#define SLOT_FIREBALL                 146
#define SLOT_FLAMESTRIKE              147
#define SLOT_FLY                      148
#define SLOT_FROST_BREATH             149
#define SLOT_GAS_BREATH               150
#define SLOT_GATE                     151
#define SLOT_GENERAL_PURPOSE          152
#define SLOT_GIANT_STRENGTH           153
#define SLOT_HARM                     154
#define SLOT_HEAL                     155
#define SLOT_HIGH_EXPLOSIVE           156
#define SLOT_IDENTIFY                 157
#define SLOT_INFRAVISION              158
#define SLOT_INVIS                    159
#define SLOT_KNOW_ALIGNMENT           160
#define SLOT_LIGHTNING_BOLT           161
#define SLOT_LIGHTNING_BREATH         162
#define SLOT_MAGIC_MISSILE            163
#define SLOT_MASS_INVIS               164
#define SLOT_PASS_DOOR                165
#define SLOT_POISON                   166
#define SLOT_PROTECTION               167
#define SLOT_REFRESH                  168
#define SLOT_REMOVE_CURSE             169
#define SLOT_SANCTUARY                170
#define SLOT_SHIELD                   171
#define SLOT_SHOCKING_GRASP           172
#define SLOT_SLEEP                    173
#define SLOT_STONE_SKIN               174
#define SLOT_TELEPORT                 175
#define SLOT_WEAKEN                   176
#define SLOT_WORD_OF_RECALL           177
#define SLOT_FLEE                     178
#define SLOT_SNEAK                    179
#define SLOT_HIDE                     180
#define SLOT_KING_ROAD                181
#define SLOT_LUBUREVENGE              182
#define SLOT_PRY                      183
#define SLOT_JUDGE                    184
#define SLOT_HASHIN                   185
#define SLOT_EIGHT_GUN                186
#define SLOT_MODO_SLASH               187
#define SLOT_SLASH_LIGHT              188
#define SLOT_SEVEN_KEY_NUMEN          189
#define SLOT_BLOOD_TEN                190
#define SLOT_EVIL_KING                191
#define SLOT_SHOOT_SUN                192
#define SLOT_WRITE_PEN                193
#define SLOT_FLY_NINE                 194
#define SLOT_FIRE_ELF                 195
#define SLOT_DORMANCY                 196
#define SLOT_PHYSIQUE                 197
#define SLOT_MEDITATION               198
#define SLOT_ANTI_PHYSIQUE            199
#define SLOT_FIXITY                   200
#define SLOT_VENOM                    201
#define SLOT_DEVELOP                  202
#define SLOT_REPAIR                   203
#define SLOT_COOK                     204
#define SLOT_STEAL                    205
#define SLOT_PICK                     206
#define SLOT_DEFLORATION              207
#define SLOT_CANNIBAL                 208
#define SLOT_WAKEUP                   209
#define SLOT_EVIL_POWER               210
#define SLOT_CRASH_WEAPON             211
#define SLOT_BYSTANDER_FIST           212
#define SLOT_FLYING_STONE             213
#define SLOT_SLOW                     214
#define SLOT_MOUNT                    215
#define SLOT_MOBILE_KILL              216
#define SLOT_MINT                     217
#define SLOT_MOBILE_STEPS             218
#define SLOT_CITIZEN                  219
#define SLOT_FAN_HAMMER               220
#define SLOT_HOLY_FIST                221
#define SLOT_FIRE_DRAGON              222
#define SLOT_CRY_GHOST                223
#define SLOT_ROCK_SLASH               224
#define SLOT_DRAGON_SHOUT             225
#define SLOT_SIX_SWORD                226
#define SLOT_THUNDER_HAMMER           227
#define SLOT_JADE_EIGHT               228
#define SLOT_DRAGON_PHOE              229
#define SLOT_DRAGON_HEROISM           230
#define SLOT_ETEN                     231
#define SLOT_POWER_WORD               232
#define SLOT_PRESERVE                 233
#define SLOT_CURE_OVERDOSE            234
#define SLOT_GOLD_SHIELD              235
#define SLOT_IRON_SHIELD              236
#define SLOT_DEVA_SHIELD              237
#define SLOT_REMEDAY                  238
#define SLOT_MAGIC_POWER              239
#define SLOT_TAICHI_FIST              240
#define SLOT_RESTORE_STAFF            241
#define SLOT_MASK                     242
#define SLOT_DETECT_MASK              243
#define SLOT_SPARKLER                 244
#define SLOT_SEARCH                   245
#define SLOT_SWIM                     246

DECLARE_DO_FUN( do_advance      );
DECLARE_DO_FUN( do_aecho        );
DECLARE_DO_FUN( do_habilitate   );
DECLARE_DO_FUN( do_alias        );
DECLARE_DO_FUN( do_allow        );
DECLARE_DO_FUN( do_angel        );
DECLARE_DO_FUN( do_answer       );
DECLARE_DO_FUN( do_areas        );
DECLARE_DO_FUN( do_ask          );
DECLARE_DO_FUN( do_at           );
DECLARE_DO_FUN( do_auction      );
DECLARE_DO_FUN( do_auto         );
DECLARE_DO_FUN( do_autoexit     );
DECLARE_DO_FUN( do_autoloot     );
DECLARE_DO_FUN( do_automap      );
DECLARE_DO_FUN( do_autosac      );
DECLARE_DO_FUN( do_address      );
DECLARE_DO_FUN( do_backup       );
DECLARE_DO_FUN( do_bamfin       );
DECLARE_DO_FUN( do_bamfout      );
DECLARE_DO_FUN( do_ban          );
DECLARE_DO_FUN( do_bet          );
DECLARE_DO_FUN( do_blank        );
DECLARE_DO_FUN( do_board        );
DECLARE_DO_FUN( do_bounty       );
DECLARE_DO_FUN( do_brief        );
DECLARE_DO_FUN( do_bug          );
DECLARE_DO_FUN( do_buy          );
DECLARE_DO_FUN( do_bus          );
DECLARE_DO_FUN( do_call         );
DECLARE_DO_FUN( do_cast         );
DECLARE_DO_FUN( do_cat          );
DECLARE_DO_FUN( do_cchat        );
DECLARE_DO_FUN( do_cd           );
DECLARE_DO_FUN( do_chance       );
DECLARE_DO_FUN( do_channels     );
DECLARE_DO_FUN( do_chat         );
DECLARE_DO_FUN( do_check        );
DECLARE_DO_FUN( do_cleanup      );
DECLARE_DO_FUN( do_close        );
DECLARE_DO_FUN( do_cls          );
DECLARE_DO_FUN( do_cname        );
DECLARE_DO_FUN( do_combine      );
DECLARE_DO_FUN( do_commands     );
DECLARE_DO_FUN( do_compare      );
DECLARE_DO_FUN( do_config       );
DECLARE_DO_FUN( do_consider     );
DECLARE_DO_FUN( do_crave        );
DECLARE_DO_FUN( do_credit       );
DECLARE_DO_FUN( do_club         );
DECLARE_DO_FUN( do_clubset      );
DECLARE_DO_FUN( do_clubchat     );
DECLARE_DO_FUN( do_cp           );
DECLARE_DO_FUN( do_damage       );
DECLARE_DO_FUN( do_data         );
DECLARE_DO_FUN( do_debug        );
DECLARE_DO_FUN( do_deny         );
DECLARE_DO_FUN( do_deposit      );
DECLARE_DO_FUN( do_description  );
DECLARE_DO_FUN( do_directory    );
DECLARE_DO_FUN( do_disconnect   );
DECLARE_DO_FUN( do_dormancy     );
DECLARE_DO_FUN( do_donate       );
DECLARE_DO_FUN( do_down         );
DECLARE_DO_FUN( do_edit         );
DECLARE_DO_FUN( do_enter        );
DECLARE_DO_FUN( do_endow        );
DECLARE_DO_FUN( do_enquire      );
DECLARE_DO_FUN( do_email        );
DECLARE_DO_FUN( do_event        );
DECLARE_DO_FUN( do_drink        );
DECLARE_DO_FUN( do_drop         );
DECLARE_DO_FUN( do_east         );
DECLARE_DO_FUN( do_eat          );
DECLARE_DO_FUN( do_echo         );
DECLARE_DO_FUN( do_emote        );
DECLARE_DO_FUN( do_enable       );
DECLARE_DO_FUN( do_equipment    );
DECLARE_DO_FUN( do_examine      );
DECLARE_DO_FUN( do_exits        );
DECLARE_DO_FUN( do_fcntl        );
DECLARE_DO_FUN( do_feed         );
DECLARE_DO_FUN( do_fight        );
DECLARE_DO_FUN( do_find         );
DECLARE_DO_FUN( do_filestat     );
DECLARE_DO_FUN( do_fill         );
DECLARE_DO_FUN( do_finger       );
DECLARE_DO_FUN( do_fire         );
DECLARE_DO_FUN( do_flee         );
DECLARE_DO_FUN( do_flow         );
DECLARE_DO_FUN( do_follow       );
DECLARE_DO_FUN( do_force        );
DECLARE_DO_FUN( do_forsake      );
DECLARE_DO_FUN( do_free         );
DECLARE_DO_FUN( do_freeze       );
DECLARE_DO_FUN( do_friend       );
DECLARE_DO_FUN( do_gamble       );
DECLARE_DO_FUN( do_get          );
DECLARE_DO_FUN( do_give         );
DECLARE_DO_FUN( do_gift         );
DECLARE_DO_FUN( do_goto         );
DECLARE_DO_FUN( do_group        );
DECLARE_DO_FUN( do_grep         );
DECLARE_DO_FUN( do_gtell        );
DECLARE_DO_FUN( do_help         );
DECLARE_DO_FUN( do_hero         );
DECLARE_DO_FUN( do_hire         );
DECLARE_DO_FUN( do_history      );
DECLARE_DO_FUN( do_holylight    );
DECLARE_DO_FUN( do_hp           );
DECLARE_DO_FUN( do_idea         );
DECLARE_DO_FUN( do_immtalk      );
DECLARE_DO_FUN( do_inventory    );
DECLARE_DO_FUN( do_invis        );
DECLARE_DO_FUN( do_ipcs         );
DECLARE_DO_FUN( do_jail         );
DECLARE_DO_FUN( do_joke         );
DECLARE_DO_FUN( do_kill         );
DECLARE_DO_FUN( do_cachet       );
DECLARE_DO_FUN( do_gchat        );
DECLARE_DO_FUN( do_learn        );
DECLARE_DO_FUN( do_leftskill    );
DECLARE_DO_FUN( do_level        );
DECLARE_DO_FUN( do_lfind        );
DECLARE_DO_FUN( do_liquid       );
DECLARE_DO_FUN( do_list         );
DECLARE_DO_FUN( do_llink        );
DECLARE_DO_FUN( do_llookup      );
DECLARE_DO_FUN( do_lock         );
DECLARE_DO_FUN( do_log          );
DECLARE_DO_FUN( do_look         );
DECLARE_DO_FUN( do_lore         );
DECLARE_DO_FUN( do_lotto        );
DECLARE_DO_FUN( do_ls           );
DECLARE_DO_FUN( do_lset         );
DECLARE_DO_FUN( do_lockcmd      );
DECLARE_DO_FUN( do_map          );
DECLARE_DO_FUN( do_marry        );
DECLARE_DO_FUN( do_memory       );
DECLARE_DO_FUN( do_md           );
DECLARE_DO_FUN( do_mfind        );
DECLARE_DO_FUN( do_mlevel       );
DECLARE_DO_FUN( do_mlist        );
DECLARE_DO_FUN( do_mload        );
DECLARE_DO_FUN( do_mode         );
DECLARE_DO_FUN( do_mpadd        );
DECLARE_DO_FUN( do_mpasound     );
DECLARE_DO_FUN( do_mpat         );
DECLARE_DO_FUN( do_mpchat       );
DECLARE_DO_FUN( do_mpecho       );
DECLARE_DO_FUN( do_mpechoaround );
DECLARE_DO_FUN( do_mpechoat     );
DECLARE_DO_FUN( do_mpclean      );
DECLARE_DO_FUN( do_mpforce      );
DECLARE_DO_FUN( do_mpgoto       );
DECLARE_DO_FUN( do_mpjunk       );
DECLARE_DO_FUN( do_mpkill       );
DECLARE_DO_FUN( do_mpmload      );
DECLARE_DO_FUN( do_mpoload      );
DECLARE_DO_FUN( do_mppurge      );
DECLARE_DO_FUN( do_mpremenemy   );
DECLARE_DO_FUN( do_mpremquest   );
DECLARE_DO_FUN( do_mpsetenemy   );
DECLARE_DO_FUN( do_mpsetquest   );
DECLARE_DO_FUN( do_mpstat       );
DECLARE_DO_FUN( do_mptransfer   );
DECLARE_DO_FUN( do_mpsay        );
DECLARE_DO_FUN( do_mset         );
DECLARE_DO_FUN( do_mstat        );
DECLARE_DO_FUN( do_multi        );
DECLARE_DO_FUN( do_murder       );
DECLARE_DO_FUN( do_music        );
DECLARE_DO_FUN( do_mwhere       );
DECLARE_DO_FUN( do_mount        );
DECLARE_DO_FUN( do_mud          );
DECLARE_DO_FUN( do_noemote      );
DECLARE_DO_FUN( do_north        );
DECLARE_DO_FUN( do_note         );
DECLARE_DO_FUN( do_notell       );
DECLARE_DO_FUN( do_notepad      );
DECLARE_DO_FUN( do_notify       );
DECLARE_DO_FUN( do_netstat      );
DECLARE_DO_FUN( do_oaf          );
DECLARE_DO_FUN( do_ofind        );
DECLARE_DO_FUN( do_okip         );
DECLARE_DO_FUN( do_olevel       );
DECLARE_DO_FUN( do_olist        );
DECLARE_DO_FUN( do_oload        );
DECLARE_DO_FUN( do_open         );
DECLARE_DO_FUN( do_order        );
DECLARE_DO_FUN( do_oset         );
DECLARE_DO_FUN( do_ostat        );
DECLARE_DO_FUN( do_otype        );
DECLARE_DO_FUN( do_owhere       );
DECLARE_DO_FUN( do_out          );
DECLARE_DO_FUN( do_pagelen      );
DECLARE_DO_FUN( do_paint        );
DECLARE_DO_FUN( do_pardon       );
DECLARE_DO_FUN( do_password     );
DECLARE_DO_FUN( do_peace        );
DECLARE_DO_FUN( do_perm         );
DECLARE_DO_FUN( do_pick         );
DECLARE_DO_FUN( do_phone        );
DECLARE_DO_FUN( do_ply          );
DECLARE_DO_FUN( do_post         );
DECLARE_DO_FUN( do_prompt       );
DECLARE_DO_FUN( do_pry          );
DECLARE_DO_FUN( do_purge        );
DECLARE_DO_FUN( do_put          );
DECLARE_DO_FUN( do_ps           );
DECLARE_DO_FUN( do_pwd          );
DECLARE_DO_FUN( do_qstat        );
DECLARE_DO_FUN( do_qset         );
DECLARE_DO_FUN( do_query        );
DECLARE_DO_FUN( do_question     );
DECLARE_DO_FUN( do_quit         );
DECLARE_DO_FUN( do_read         );
DECLARE_DO_FUN( do_rebirth      );
DECLARE_DO_FUN( do_reboot       );
DECLARE_DO_FUN( do_recall       );
DECLARE_DO_FUN( do_recho        );
DECLARE_DO_FUN( do_recite       );
DECLARE_DO_FUN( do_remove       );
DECLARE_DO_FUN( do_rename       );
DECLARE_DO_FUN( do_reply        );
DECLARE_DO_FUN( do_report       );
DECLARE_DO_FUN( do_rest         );
DECLARE_DO_FUN( do_restore      );
DECLARE_DO_FUN( do_rd           );
DECLARE_DO_FUN( do_rm           );
DECLARE_DO_FUN( do_rset         );
DECLARE_DO_FUN( do_rstat        );
DECLARE_DO_FUN( do_repair       );
DECLARE_DO_FUN( do_sacrifice    );
DECLARE_DO_FUN( do_sale         );
DECLARE_DO_FUN( do_save         );
DECLARE_DO_FUN( do_say          );
DECLARE_DO_FUN( do_score        );
DECLARE_DO_FUN( do_see          );
DECLARE_DO_FUN( do_sefind       );
DECLARE_DO_FUN( do_sell         );
DECLARE_DO_FUN( do_semote       );
DECLARE_DO_FUN( do_serial       );
DECLARE_DO_FUN( do_shout        );
DECLARE_DO_FUN( do_ship         );
DECLARE_DO_FUN( do_shutdown     );
DECLARE_DO_FUN( do_silence      );
DECLARE_DO_FUN( do_slay         );
DECLARE_DO_FUN( do_sleep        );
DECLARE_DO_FUN( do_snoop        );
DECLARE_DO_FUN( do_socials      );
DECLARE_DO_FUN( do_south        );
DECLARE_DO_FUN( do_split        );
DECLARE_DO_FUN( do_spy          );
DECLARE_DO_FUN( do_sset         );
DECLARE_DO_FUN( do_stand        );
DECLARE_DO_FUN( do_status       );
DECLARE_DO_FUN( do_stock        );
DECLARE_DO_FUN( do_store        );
DECLARE_DO_FUN( do_study        );
DECLARE_DO_FUN( do_suicide      );
DECLARE_DO_FUN( do_sysconf      );
DECLARE_DO_FUN( do_sysinfo      );
DECLARE_DO_FUN( do_system       );
DECLARE_DO_FUN( do_sector       );
DECLARE_DO_FUN( do_send         );
DECLARE_DO_FUN( do_shop         );
DECLARE_DO_FUN( do_site         );
DECLARE_DO_FUN( do_task         );
DECLARE_DO_FUN( do_tcp          );
DECLARE_DO_FUN( do_tell         );
DECLARE_DO_FUN( do_test         );
DECLARE_DO_FUN( do_tick         );
DECLARE_DO_FUN( do_time         );
DECLARE_DO_FUN( do_title        );
DECLARE_DO_FUN( do_toss         );
DECLARE_DO_FUN( do_touch        );
DECLARE_DO_FUN( do_top          );
DECLARE_DO_FUN( do_trade        );
DECLARE_DO_FUN( do_train        );
DECLARE_DO_FUN( do_transfer     );
DECLARE_DO_FUN( do_trust        );
DECLARE_DO_FUN( do_turn         );
DECLARE_DO_FUN( do_typo         );
DECLARE_DO_FUN( do_uname        );
DECLARE_DO_FUN( do_unlock       );
DECLARE_DO_FUN( do_up           );
DECLARE_DO_FUN( do_users        );
DECLARE_DO_FUN( do_unmount      );
DECLARE_DO_FUN( do_value        );
DECLARE_DO_FUN( do_visible      );
DECLARE_DO_FUN( do_vocation     );
DECLARE_DO_FUN( do_vote         );
DECLARE_DO_FUN( do_wake         );
DECLARE_DO_FUN( do_wanted       );
DECLARE_DO_FUN( do_wear         );
DECLARE_DO_FUN( do_weather      );
DECLARE_DO_FUN( do_west         );
DECLARE_DO_FUN( do_where        );
DECLARE_DO_FUN( do_whereis      );
DECLARE_DO_FUN( do_who          );
DECLARE_DO_FUN( do_wimpy        );
DECLARE_DO_FUN( do_withdraw     );
DECLARE_DO_FUN( do_wizhelp      );
DECLARE_DO_FUN( do_wizlist      );
DECLARE_DO_FUN( do_wizlock      );
DECLARE_DO_FUN( do_xnames       );
DECLARE_DO_FUN( do_yell         );

DECLARE_SPELL_FUN( skill_sneak              );
DECLARE_SPELL_FUN( skill_hide               );
DECLARE_SPELL_FUN( skill_mask               );

DECLARE_SPELL_FUN( spell_make_spring        );
DECLARE_SPELL_FUN( spell_make_light         );
DECLARE_SPELL_FUN( spell_cast_armor         );
DECLARE_SPELL_FUN( spell_cast_bless         );
DECLARE_SPELL_FUN( spell_cast_fire          );
DECLARE_SPELL_FUN( spell_cast_lightning     );

DECLARE_SPELL_FUN( cast_control_weather     );
DECLARE_SPELL_FUN( cast_locate_object       );
DECLARE_SPELL_FUN( cast_summon              );
DECLARE_SPELL_FUN( cast_scan                );
DECLARE_SPELL_FUN( cast_sparkler            );
DECLARE_SPELL_FUN( cast_search              );
DECLARE_SPELL_FUN( cast_ventriloquate       );
DECLARE_SPELL_FUN( cast_acid_blast          );
DECLARE_SPELL_FUN( cast_acid_breath         );
DECLARE_SPELL_FUN( cast_blindness           );
DECLARE_SPELL_FUN( cast_burning_hands       );
DECLARE_SPELL_FUN( cast_call_lightning      );
DECLARE_SPELL_FUN( cast_cause_critical      );
DECLARE_SPELL_FUN( cast_cause_light         );
DECLARE_SPELL_FUN( cast_cause_serious       );
DECLARE_SPELL_FUN( cast_change_sex          );
DECLARE_SPELL_FUN( cast_charm_person        );
DECLARE_SPELL_FUN( cast_chill_touch         );
DECLARE_SPELL_FUN( cast_colour_spray        );
DECLARE_SPELL_FUN( cast_create_food         );
DECLARE_SPELL_FUN( cast_create_water        );
DECLARE_SPELL_FUN( cast_cure_blindness      );
DECLARE_SPELL_FUN( cast_cure_critical       );
DECLARE_SPELL_FUN( cast_cure_light          );
DECLARE_SPELL_FUN( cast_cure_poison         );
DECLARE_SPELL_FUN( cast_cure_serious        );
DECLARE_SPELL_FUN( cast_curse               );
DECLARE_SPELL_FUN( cast_detect_evil         );
DECLARE_SPELL_FUN( cast_detect_hidden       );
DECLARE_SPELL_FUN( cast_detect_invis        );
DECLARE_SPELL_FUN( cast_detect_mask         );
DECLARE_SPELL_FUN( cast_detect_magic        );
DECLARE_SPELL_FUN( cast_detect_poison       );
DECLARE_SPELL_FUN( cast_dispel_evil         );
DECLARE_SPELL_FUN( cast_dispel_magic        );
DECLARE_SPELL_FUN( cast_earthquake          );
DECLARE_SPELL_FUN( cast_enchant_weapon      );
DECLARE_SPELL_FUN( cast_energy_drain        );
DECLARE_SPELL_FUN( cast_faerie_fire         );
DECLARE_SPELL_FUN( cast_faerie_fog          );
DECLARE_SPELL_FUN( cast_fire_breath         );
DECLARE_SPELL_FUN( cast_fireball            );
DECLARE_SPELL_FUN( cast_flamestrike         );
DECLARE_SPELL_FUN( cast_fly                 );
DECLARE_SPELL_FUN( cast_frost_breath        );
DECLARE_SPELL_FUN( cast_gas_breath          );
DECLARE_SPELL_FUN( cast_gate                );
DECLARE_SPELL_FUN( cast_general_purpose     );
DECLARE_SPELL_FUN( cast_giant_strength      );
DECLARE_SPELL_FUN( cast_harm                );
DECLARE_SPELL_FUN( cast_heal                );
DECLARE_SPELL_FUN( cast_high_explosive      );
DECLARE_SPELL_FUN( cast_identify            );
DECLARE_SPELL_FUN( cast_infravision         );
DECLARE_SPELL_FUN( cast_invis               );
DECLARE_SPELL_FUN( cast_judge               );
DECLARE_SPELL_FUN( cast_know_alignment      );
DECLARE_SPELL_FUN( cast_lightning_bolt      );
DECLARE_SPELL_FUN( cast_lightning_breath    );
DECLARE_SPELL_FUN( cast_magic_missile       );
DECLARE_SPELL_FUN( cast_mass_invis          );
DECLARE_SPELL_FUN( cast_null                );
DECLARE_SPELL_FUN( cast_pass_door           );
DECLARE_SPELL_FUN( cast_poison              );
DECLARE_SPELL_FUN( cast_protection          );
DECLARE_SPELL_FUN( cast_pry                 );
DECLARE_SPELL_FUN( cast_refresh             );
DECLARE_SPELL_FUN( cast_remove_curse        );
DECLARE_SPELL_FUN( cast_sanctuary           );
DECLARE_SPELL_FUN( cast_shield              );
DECLARE_SPELL_FUN( cast_shocking_grasp      );
DECLARE_SPELL_FUN( cast_sleep               );
DECLARE_SPELL_FUN( cast_stone_skin          );
DECLARE_SPELL_FUN( cast_teleport            );
DECLARE_SPELL_FUN( cast_weaken              );
DECLARE_SPELL_FUN( cast_word_of_recall      );
DECLARE_SPELL_FUN( cast_seven_key_numen     );
DECLARE_SPELL_FUN( cast_fire_elf            );
DECLARE_SPELL_FUN( cast_dormancy            );
DECLARE_SPELL_FUN( cast_physique            );
DECLARE_SPELL_FUN( cast_meditation          );
DECLARE_SPELL_FUN( cast_anti_physique       );
DECLARE_SPELL_FUN( cast_fixity              );
DECLARE_SPELL_FUN( cast_venom               );
DECLARE_SPELL_FUN( cast_develop             );
DECLARE_SPELL_FUN( cast_repair              );
DECLARE_SPELL_FUN( cast_cook                );
DECLARE_SPELL_FUN( cast_steal               );
DECLARE_SPELL_FUN( cast_pick                );
DECLARE_SPELL_FUN( cast_defloration         );
DECLARE_SPELL_FUN( cast_cannibal            );
DECLARE_SPELL_FUN( cast_wakeup              );
DECLARE_SPELL_FUN( cast_evil_power          );
DECLARE_SPELL_FUN( cast_crash_weapon        );
DECLARE_SPELL_FUN( cast_bystander_fist      );
DECLARE_SPELL_FUN( cast_flying_stone        );
DECLARE_SPELL_FUN( cast_slow                );
DECLARE_SPELL_FUN( cast_mint                );
DECLARE_SPELL_FUN( cast_power_word          );
DECLARE_SPELL_FUN( cast_preserve            );
DECLARE_SPELL_FUN( cast_cure_overdose       );
DECLARE_SPELL_FUN( cast_gold_shield         );
DECLARE_SPELL_FUN( cast_iron_shield         );
DECLARE_SPELL_FUN( cast_deva_shield         );
DECLARE_SPELL_FUN( cast_remeday             );
DECLARE_SPELL_FUN( cast_magic_power         );
DECLARE_SPELL_FUN( cast_taichi_fist         );
DECLARE_SPELL_FUN( cast_restore_staff       );

/* �T�{�ޯ઺��� */
DECLARE_CHECK_FUN( check_sword_attack       );
DECLARE_CHECK_FUN( check_unrigid_attack     );
DECLARE_CHECK_FUN( check_pc_attack          );
DECLARE_CHECK_FUN( check_spear_attack       );
DECLARE_CHECK_FUN( check_blade_attack       );
DECLARE_CHECK_FUN( check_whip_attack        );
DECLARE_CHECK_FUN( check_dagger_attack      );
DECLARE_CHECK_FUN( check_axe_attack         );
DECLARE_CHECK_FUN( check_club_attack        );
DECLARE_CHECK_FUN( check_pen_attack         );

/* �S���� */
DECLARE_ROUTINE_FUN( routine_none           );

/* Ĳ�o�ƥ��� */
DECLARE_EVENT_FUN( event_thunder       );
DECLARE_EVENT_FUN( event_solar_eclipse );
DECLARE_EVENT_FUN( event_month_eclipse );
DECLARE_EVENT_FUN( event_drought       );
DECLARE_EVENT_FUN( event_locust        );

/* �u�@������� */
DECLARE_ANGEL_FUN( angel_mount        );
DECLARE_ANGEL_FUN( angel_sleep        );
DECLARE_ANGEL_FUN( angel_drink        );
DECLARE_ANGEL_FUN( angel_eat          );
DECLARE_ANGEL_FUN( angel_marry        );
DECLARE_ANGEL_FUN( angel_wedding      );
DECLARE_ANGEL_FUN( angel_alias        );
DECLARE_ANGEL_FUN( angel_auction      );
DECLARE_ANGEL_FUN( angel_bet          );
DECLARE_ANGEL_FUN( angel_areas        );
DECLARE_ANGEL_FUN( angel_xname        );
DECLARE_ANGEL_FUN( angel_immortal     );
DECLARE_ANGEL_FUN( angel_deposit_gold );
DECLARE_ANGEL_FUN( angel_deposit_obj  );
DECLARE_ANGEL_FUN( angel_stock        );
DECLARE_ANGEL_FUN( angel_gamble       );
DECLARE_ANGEL_FUN( angel_direction    );
DECLARE_ANGEL_FUN( angel_shop         );
DECLARE_ANGEL_FUN( angel_smith        );
DECLARE_ANGEL_FUN( angel_mercenary    );
DECLARE_ANGEL_FUN( angel_coper        );
DECLARE_ANGEL_FUN( angel_kill         );
DECLARE_ANGEL_FUN( angel_bank         );
DECLARE_ANGEL_FUN( angel_obj_bank     );
DECLARE_ANGEL_FUN( angel_get          );
DECLARE_ANGEL_FUN( angel_drop         );
DECLARE_ANGEL_FUN( angel_withdraw     );
DECLARE_ANGEL_FUN( angel_unmount      );
DECLARE_ANGEL_FUN( angel_call         );
DECLARE_ANGEL_FUN( angel_bus          );
DECLARE_ANGEL_FUN( angel_ship         );
DECLARE_ANGEL_FUN( angel_lore         );
DECLARE_ANGEL_FUN( angel_badman       );
DECLARE_ANGEL_FUN( angel_wake         );
DECLARE_ANGEL_FUN( angel_lotto        );
DECLARE_ANGEL_FUN( angel_hero         );
DECLARE_ANGEL_FUN( angel_autosac      );
DECLARE_ANGEL_FUN( angel_autoloot     );
DECLARE_ANGEL_FUN( angel_friend       );
DECLARE_ANGEL_FUN( angel_wimpy        );
DECLARE_ANGEL_FUN( angel_enable       );
DECLARE_ANGEL_FUN( angel_flee         );
DECLARE_ANGEL_FUN( angel_attack       );
DECLARE_ANGEL_FUN( angel_meditation   );
DECLARE_ANGEL_FUN( angel_description  );
DECLARE_ANGEL_FUN( angel_club         );
DECLARE_ANGEL_FUN( angel_group        );
DECLARE_ANGEL_FUN( angel_nogroup      );
DECLARE_ANGEL_FUN( angel_reply        );
DECLARE_ANGEL_FUN( angel_fountain     );
DECLARE_ANGEL_FUN( angel_food         );
DECLARE_ANGEL_FUN( angel_gambleset    );
DECLARE_ANGEL_FUN( angel_weather      );
DECLARE_ANGEL_FUN( angel_repair       );
DECLARE_ANGEL_FUN( angel_crave        );
DECLARE_ANGEL_FUN( angel_sac          );
DECLARE_ANGEL_FUN( angel_wear         );
DECLARE_ANGEL_FUN( angel_study        );
DECLARE_ANGEL_FUN( angel_learn        );
DECLARE_ANGEL_FUN( angel_recall       );
DECLARE_ANGEL_FUN( angel_recallset    );
DECLARE_ANGEL_FUN( angel_spilt        );
DECLARE_ANGEL_FUN( angel_train        );
DECLARE_ANGEL_FUN( angel_forsake      );
DECLARE_ANGEL_FUN( angel_enemy        );
DECLARE_ANGEL_FUN( angel_blind        );
DECLARE_ANGEL_FUN( angel_poison       );
DECLARE_ANGEL_FUN( angel_board        );
DECLARE_ANGEL_FUN( angel_firman       );
DECLARE_ANGEL_FUN( angel_money        );
DECLARE_ANGEL_FUN( angel_fighting_1   );
DECLARE_ANGEL_FUN( angel_fighting_2   );
DECLARE_ANGEL_FUN( angel_cname        );
DECLARE_ANGEL_FUN( angel_nothing      );
DECLARE_ANGEL_FUN( angel_reboot       );
DECLARE_ANGEL_FUN( angel_message      );
DECLARE_ANGEL_FUN( angel_config_flee  );
DECLARE_ANGEL_FUN( angel_exact        );
DECLARE_ANGEL_FUN( angel_mobile       );
DECLARE_ANGEL_FUN( angel_note         );
DECLARE_ANGEL_FUN( angel_leftskill    );

#if     defined(_AIX)
char *  crypt           args( ( const char *, const char * ) );
#endif

#if     defined(apollo)
int     atoi            args( ( const char * ) );
void *  calloc          args( ( unsigned, size_t ) );
char *  crypt           args( ( const char *, const char * ) );
#endif

#if     defined(hpux)
char *  crypt           args( ( const char *, const char * ) );
#endif

#if     defined(linux)
char *  crypt           args( ( const char *, const char * ) );
#endif

#if     defined(macintosh)
#define NOCRYPT
#if     defined(unix)
#undef  unix
#endif
#endif

#if     defined(MIPS_OS)
char *  crypt           args( ( const char *, const char * ) );
#endif

#if     defined(MSDOS)
#define NOCRYPT
#if     defined(unix)
#undef  unix
#endif
#endif

#if     defined(NeXT)
char *  crypt           args( ( const char *, const char * ) );
#endif

#if     defined(sequent)
char *  crypt           args( ( const char *, const char * ) );
int     fclose          args( ( FILE * ) );
int     fprintf         args( ( FILE *, const char *, ... ) );
int     fread           args( ( void *, int, int, FILE * ) );
int     fseek           args( ( FILE *, long, int ) );
void    perror          args( ( const char * ) );
int     ungetc          args( ( int, FILE * ) );
#endif

#if     defined(sun)
char *  crypt           args( ( const char *, const char * ) );
int     fclose          args( ( FILE * ) );
int     fprintf         args( ( FILE *, const char *, ... ) );
int     fread           args( ( void *, int, int, FILE * ) );
int     fseek           args( ( FILE *, long, int ) );
void    perror          args( ( const char * ) );
int     ungetc          args( ( int , FILE * ) );
#endif

#if     defined(ultrix)
char *  crypt           args( ( const char *, const char * ) );
#endif

#if     defined(NOCRYPT)
#define crypt(s1, s2)   (s1)
#endif

#define INI_FILE        "merc.ini"
#define SHUTDOWN_FILE   "shutdown.txt"

#define CD      CHAR_DATA
#define MID     MOB_INDEX_DATA
#define OD      OBJ_DATA
#define OID     OBJ_INDEX_DATA
#define RID     ROOM_INDEX_DATA
#define SF      SPEC_FUN
#define DD      DESCRIPTOR_DATA
#define SD      SECTOR_DATA
#define OTD     OBJ_TYPE_DATA

/* act_comm.c */
void    add_follower    args( ( CD *, CD * ) );
void    stop_follower   args( ( CD * ) );
void    die_follower    args( ( CD * ) );
bool    is_same_group   args( ( CD *, CD * ) );
bool    is_note_to      args( ( CD *, NOTE_DATA * ) );
bool    can_quit        args( ( CD *, bool ) );
bool    check_password  args( ( const char * ) );
bool    check_email_address args( ( char * ) );
bool    write_to_descriptor args( ( DD *, char *, int ) );
void    talk_channel_2  args( ( char * , int , const char * ) );
void    extract_failcode args( ( CD * ) );
void    show_failcode    args( ( CD * ) );
void    notes_update     args( ( void ) );
extern  void talk_channel args( ( CD *, char *, int, const char * ) );

/* act_info.c */
char *  check_damage            args( ( OD * ) );
bool    check_blind             args( ( CD * ) );
void    set_title               args( ( CD *, char * ) );
char *  return_percentage       args( ( CD *, int, int, int ) );
size_t  get_usernum             args( ( void ) );
size_t  get_attemptnum          args( ( void ) );
size_t  get_total_user          args( ( void ) );
char *  get_worktime_string     args( ( void ) );
char *  date_string             args( ( int ) );
char *  time_format             args( ( time_t , const char * ) );
char *  time_string             args( ( TIMEVAL * ) );
char *  showtime                args( ( int ) );

/* act_move.c */
bool            move_char          args( ( CD *, int ) );
size_t          learn_count        args( ( CD * ) );
size_t          learn_rating_count args( ( CD *, int ) );
int             find_door          args( ( CD * , char * ) );
EXIT_DATA *     create_exit        args( ( int, int, int ) );
void            close_exit         args( ( int, int ) );

/* act_obj.c */
CD *    find_keeper     args( ( CD * , int ) );
void    message_driver  args( ( CD *, OD *, int ) );
size_t  add_firman      args( ( CD *, int ) );
bool    can_store       args( ( OD * ) );
void    wear_obj        args( ( CD * , OD * , bool, bool ) );

/* act_wiz.c */
RID *   find_location   args( ( CD *, char * ) );
char *  get_position    args( ( int ) );
char *  get_log         args( ( int ) );

/* comm.c */
void    close_socket    args( ( DD * ) );
void    write_to_buffer args( ( DD *, const char *, int ) );
void    send_to_all_char args( ( const char * ) );
void    send_to_club    args( ( const char *, CLUB_DATA * ) );
void    send_to_char    args( ( const char *, CD * ) );
void    sendmsg_to_room args( ( const char *, CD * ) );
void    sendmsg_to_someroom args( ( const char *, RID * ) );
void    show_string     args( ( DD *, char * ) );
void    act             args( ( const char *, CD *,
                            const void *, const void *, int ) );

void    sact            args( ( CD *, CD *, OD *, char * ) );
bool    check_parse_name        args( ( char * ) );
void    cease_stack     args( ( DD * ) );
bool    set_descriptor_stack args( ( DD * ) );
void    process_stack   args( ( DD * ) );

/* db.c */
void    boot_db         args( ( void ) );
CD *    create_mobile   args( ( MID * ) );
OD *    create_object   args( ( OID *, int ) );
void    clear_char      args( ( CD * ) );
void    free_char       args( ( CD * ) );
char *  get_extra_descr args( ( const char *, EXTRA_DESCR_DATA * ) );
MID  *  get_mob_index   args( ( int ) );
int     get_mob_count   args( ( int ) );
SD   *  get_sector_index args( ( int ) );

OID  *  get_obj_index   args( ( int ) );
RID  *  get_room_index  args( ( int ) );
AREA_DATA * get_room_area args( ( int ) );
RID  *  random_room     args( ( AREA_DATA * ) );
char    fread_letter    args( ( FILE * ) );
int     fread_number    args( ( FILE * ) );
char *  fread_string    args( ( FILE * ) );
void    fread_to_eol    args( ( FILE * ) );
char *  fread_word      args( ( FILE * ) );
char *  fread_alpha     args( ( FILE * ) );
bool    fread_if_eol    args( ( FILE * ) );
bool    if_eof          args( ( FILE * ) );
void    smash_tilde     args( ( char * ) );
void    smash_point     args( ( char * ) );
void    tail_chain      args( ( void ) );
void    reset_area      args( ( AREA_DATA * ) );
void    mine_reset_area args( ( AREA_DATA * ) );
MPROG_DATA *    mprog_file_read args( ( char * , MPROG_DATA *, MID * ) );

/* mem.c */
void    memory_ini      args( ( void ) );
void *  alloc_string    args( ( int ) );
void *  alloc_struct    args( ( int ) );
void    free_struct     args( ( void *, int ) );
void    free_string     args( ( char * ) );

/* random.c */
void    init_mm         args( ( void ) );
int     number_door     args( ( void ) );
int     number_fuzzy    args( ( int ) );
int     number_range    args( ( int, int ) );
int     number_percent  args( ( void ) );
int     number_bits     args( ( int ) );
int     dice            args( ( int, int ) );
int     variation       args( ( int, int ) );

/* fight.c */
void    violence_update args( ( void ) );
void    striking        args( ( CD *, CD *, int ) );
void    damage          args( ( CD *, CD *, int, int ) );
void    update_pos      args( ( CD * ) );
void    stop_fighting   args( ( CD *, bool ) );
void    death_cry       args( ( CD * ) );
bool    can_fight       args( ( CD *, CD * ) );
int     get_hitroll     args( ( CD * ) );
int     get_damroll     args( ( CD * ) );
int     get_ac          args( ( CD * ) );
void    check_killer    args( ( CD * , CD * ) );
void    set_fighting    args( ( CD * , CD * ) );

/* bit.c */
const char * adeptation_name        args( ( int ) );
const char * direction_name         args( ( int ) );
const char * direction_ename        args( ( int ) );
const char * get_homename           args( ( int ) );
const char * tcp_status             args( ( int ) );
const char * bounty_type            args( ( int ) );
const char * bounty_unit            args( ( int ) );
const char * status_message         args( ( CD * ) );
char     *  obj_cast_location       args( ( int ) );
char     *  effect_type_name        args( ( int ) );
char     *  ship_status             args( ( SHIP_DATA * ) );
char     *  restrict_value          args( ( RESTRICT_DATA *, CD * ) );
char     *  message_type            args( ( int ) );
char     *  player_status           args( ( int ) );
char     *  skill_type              args( ( int ) );
char     *  club_status             args( ( CLUB_DATA * ) );
char     *  item_type_name          args( ( OID * ) );
char     *  skill_rating            args( ( int ) );
char     *  item_kind_name          args( ( int ) );
char     *  affect_loc_name         args( ( int ) );
char     *  area_bit_name           args( ( int ) );
char     *  sector_flag_name        args( ( int ) );
char     *  shop_type_name          args( ( int ) );
char     *  affect_bit_name         args( ( int ) );
char     *  skill_affect            args( ( int ) );
char     *  extra_bit_name          args( ( int ) );
char     *  wear_bit_name           args( ( int ) );
char     *  ban_bit_name            args( ( int ) );
char     *  xnames_bit_name         args( ( int ) );
char     *  attack_situs            args( ( int ) );
char     *  wear_location_string    args( ( int ) );
char     *  room_bit_name           args( ( int ) );
char     *  weapon_type_name        args( ( int ) );
char     *  container_bit_name      args( ( int ) );
char     *  act_bit_name            args( ( int ) );
char     *  wiz_bit_name            args( ( int ) );
char     *  turn_bit_name           args( ( int ) );
char     *  progtypes_bit_name      args( ( int ) );
char     *  get_obj_value_usage     args( ( int , int * ) );
char     *  object_locate           args( ( OD * , CD * ) );
CD       *  object_owner            args( ( OD * ) );

/* handler.c */
int         get_trust       args( ( CD * ) );
int         get_age         args( ( CD * ) );
int         get_curr_hit    args( ( CD * ) );
int         get_curr_mana   args( ( CD * ) );
int         get_curr_move   args( ( CD * ) );
int         get_curr_str    args( ( CD * ) );
int         get_str_train   args( ( CD * ) );
int         get_curr_int    args( ( CD * ) );
int         get_int_train   args( ( CD * ) );
int         get_curr_wis    args( ( CD * ) );
int         get_wis_train   args( ( CD * ) );
int         get_curr_dex    args( ( CD * ) );
int         get_dex_train   args( ( CD * ) );
int         get_curr_con    args( ( CD * ) );
int         get_con_train   args( ( CD * ) );
int         can_carry_n     args( ( CD * ) );
int         can_carry_w     args( ( CD * ) );
int         get_carry_weight args( ( CD * ) );
void        affect_to_char  args( ( CD *, AFFECT_DATA * ) );
void        affect_remove   args( ( CD *, AFFECT_DATA * ) );
void        affect_release  args( ( CD *, int sn ) );
bool        is_affected     args( ( CD *, int ) );
void        affect_join     args( ( CD *, AFFECT_DATA * ) );
void        char_from_room  args( ( CD * ) );
void        char_to_room    args( ( CD *, RID * ) );
void        gold_to_room    args( ( RID *, int ) );
void        gold_to_char    args( ( CD *, int ) );
void        gold_from_char  args( ( CD *, int ) );
void        fix_gold_weight args( ( CD * ) );
void        obj_to_char     args( ( OD *, CD * ) );
void        obj_from_char   args( ( OD * ) );
int         apply_ac        args( ( OD *, int ) );
OD *        get_eq_char     args( ( CD *, int ) );
void        equip_char      args( ( CD *, OD *, int ) );
void        unequip_char    args( ( CD *, OD * ) );
int         count_obj_list  args( ( OID *, OD * ) );
int         obj_type_room   args( ( CD *, int ) );
int         obj_type_char   args( ( CD *, int ) );
void        obj_from_room   args( ( OD * ) );
void        obj_to_room     args( ( OD *, RID * ) );
void        obj_to_obj      args( ( OD *, OD * ) );
void        obj_from_obj    args( ( OD * ) );
void        extract_obj     args( ( OD * ) );
void        extract_char    args( ( CD *, bool ) );
CD *        get_pc_room     args( ( CD *, const char * ) );
CD *        get_pc_world    args( ( CD *, const char * ) );
CD *        get_char_room   args( ( CD *, char * ) );
CD *        get_char_world  args( ( CD *, char * ) );
MID *       get_char_protype args( ( char * ) );
OD *        get_obj_type    args( ( OID * ) );
OD *        get_obj_list    args( ( CD *, char *, OD * ) );
OD *        get_obj_carry   args( ( CD *, char * ) );
OD *        get_obj_wear    args( ( CD *, char * ) );
OD *        get_obj_here    args( ( CD *, char * ) );
OD *        get_obj_world   args( ( CD *, char * ) );
OID *       get_obj_protype args( ( char * ) );
RID *       get_obj_room    args( ( OD * ) );
OD *        create_money    args( ( int ) );
int         get_obj_number  args( ( OD * ) );
int         get_obj_weight  args( ( OD * ) );
bool        room_is_dark    args( ( RID * ) );
bool        room_is_private args( ( RID * ) );
bool        can_see         args( ( CD *, CD * ) );
bool        can_see_mask    args( ( CD *, CD * ) );
bool        can_see_obj     args( ( CD *, OD * ) );
bool        can_drop_obj    args( ( CD *, OD * ) );
bool        can_see_room    args( ( CD * ) );
int         search_cost     args( ( CD * ) );
OD *        get_wield       args( ( CD * ) );
void        light_adjust    args( ( CD *, OD *, int ) );
int         dimemsion_position  args( ( int *, int , bool ) );
bool        check_repeat    args( ( CD *, const char * ) );
void        delete_chat     args( ( CD * ) );
bool        check_chat_xname args( ( CD *, char * ) );
bool        check_cname_xname args( ( char * ) );
void        multi_damage    args( (CD *, CD *, int, int, int * ) );
CD *        shape_mobile    args( ( MID *, RID * ) );
void        adjust_carry    args( ( CD * ) );
void        identify_obj    args( ( CD *, OD * ) );
LIQ_DATA  * liq_lookup      args( ( int ) );
bool        check_obj_restrict args( ( CD *, OD *, bool ) );
bool        check_skill_restrict args( ( CD *, SKILL_DATA *, bool ) );
bool        check_skill_cast args( ( CD *, SKILL_DATA *, bool ) );
bool        check_valid_rating args( ( CD *, SKILL_DATA *, bool ) );
time_t      time_at         args( ( char * ) );
bool        on_line         args( ( const char *, CD * ) );
bool        is_keeper       args( ( CD * ) );
bool        biliwick        args( ( CD *, CD * ) );
void        fix_color       args( ( char * ) );
bool        is_dead         args( ( CD * ) );
bool        can_damage      args( ( CD * ) );
bool        can_char_from_room args( ( CD *, bool ) );
bool        check_restrict  args( ( CD *, RESTRICT_DATA *, bool ) );
void        cancel_skill    args( ( CD *, int ) );
char      * host_name       args( ( DESCRIPTOR_DATA * ) );
bool        poison_char     args( ( CD *, OD * ) );
int         get_adeptation  args( ( SKILL_DATA *, MID * ) );
void        calculate_armor args( ( CD * ) );
void        check_home      args( ( CD * ) );
AREA_DATA * get_home        args( ( CD * ) );
RID       * get_hometown    args( ( CD * ) );
void        set_variable    args( ( const char *, int, int ) );
int         check_variable  args( ( const char *, int ) );
bool        char_autofood   args( ( CD * ) );
bool        char_autodrink  args( ( CD * ) );
size_t      get_learnable   args( ( CD * ) );
const char * numberize      args( ( int ) );
bool        is_server       args( ( const char * ) );
int         personal_asset  args( ( CD * ) );
bool        over_scale      args( ( CD * ) );
char *      return_array    args( ( ARRAY_DATA [], int, int ) );

/* interp.c */
void    interpret       args( ( CD *, char * ) );
int     number_argument args( ( char *, char * ) );
char *  one_argument    args( ( char *, char * ) );
char *  one_statement   args( ( char *, char * ) );

/* magic.c */
SKILL_DATA      * get_skill     args( ( int ) );
SKILL_DATA      * skill_isname  args( ( const char * ) );
bool    saves_spell     args( ( int, CD * ) );
void    mprog_wordlist_check    args( ( char *, CD *, CD *, OD *, void *, int ) );
void    mprog_percent_check     args( ( CD *, CD *, OD *, void *, int ) );
void    mprog_act_trigger       args( ( char *, CD *, CD *, OD *, void * ) );
void    mprog_bribe_trigger     args( ( CD *, CD *, int ) );
void    mprog_entry_trigger     args( ( CD * ) );
void    mprog_give_trigger args( ( CD *, CD *, OD * ) );
void    mprog_greet_trigger     args( ( CD * ) );
void    mprog_fight_trigger     args( ( CD *, CD * ) );
void    mprog_hitprcnt_trigger  args( ( CD *, CD * ) );
void    mprog_death_trigger     args( ( CD *, CD * ) );
void    mprog_random_trigger    args( ( CD * ) );
void    mprog_speech_trigger    args( ( char * , CD * ) );

/* save.c */
void    save_char_obj   args( ( CD * , int ) );
int     load_char_obj   args( ( DD *, char * ) );
void    check_null_object args( ( CD * ) );
char *  initial         args( ( const char * ) );
char *  file_name       args( ( const char *, int ) );
void    save_club       args( ( void ) );
void    set_file_mode   args( ( const char * ) );
void    fwrite_failcode args( ( CD *, const char * ) );
void    char_filesize   args( ( CD * ) );
void    autosave_update args( ( void ) );
bool    excess_filequota args( ( CD * ) );
void    player_log      args( ( CD *, const char * ) );

/* special.c */
SF *    spec_lookup     args( ( const char * ) );

/* update.c */
void    advance_level   args( ( CD * ) );
void    gain_exp        args( ( CD *, int ) );
void    gain_condition  args( ( CD *, int, int ) );
void    update_handler  args( ( void ) );
void    area_update     args( ( void ) );
void    ship_update     args( ( void ) );
void    foggy_update    args( ( int ) );

/* auction.c */
void    init_auction    args( ( void ) );
void    auction_update  args( ( void ) );

/* alias.c */
extern  int     max_alias;
extern  int     alias_repeat;

void    extract_alias   args( ( CD * ) );
int     get_alias_count args( ( CD * ) );
void    translate_alias args( ( DD * , char * ) );

/* deposit.c */
void    obj_to_char_deposit   args( ( OD * , CD * ) );
void    obj_from_char_deposit args( ( OD * ) );
OD *    get_obj_deposit       args( ( CD * , char * ) );
void    obj_to_obj_dep        args( ( OD * , OD * ) );
size_t  deposit_count         args( ( CD * ) );
void    deposit_update        args( ( void ) );

/* string.c */
char *  str_dup                 args( ( const char * ) );
bool    is_name                 args( ( const char *, char * ) );
bool    is_fullname             args( ( const char *, char * ) );
bool    is_number               args( ( char *arg ) );
char *  test_number             args( ( char * , int * ) );
size_t  str_len                 args( ( const char * ) );
size_t  ansi_str_len            args( ( char * ) );
char *  str_cat                 args( ( char * , const char * ) );
char *  str_cpy                 args( ( char * , const char * ) );
char *  str_ncpy                args( ( char * , const char *, size_t ) );
char *  str_str                 args( ( char *, char * ) );
bool    str_cmp                 args( ( const char * , const char * ) );
bool    str_prefix              args( ( const char * , const char * ) );
bool    str_infix               args( ( const char * , const char * ) );
bool    str_suffix              args( ( const char * , const char * ) );
char *  normalize               args( ( const char * ) );
void    str_nset                args( ( char * , int , size_t ) );
void    smash_char              args( ( char *, char ) );
char *  str_space               args( ( char *, size_t ) );
char *  chinese_number          args( ( int , char * ) );

/* load.c */
AREA_DATA *  load_area          args( ( char * ) );
void         load_mobiles       args( ( char * , AREA_DATA * ) );
void         load_room          args( ( char * , AREA_DATA * ) );
void         load_object        args( ( char * , AREA_DATA * ) );
void         load_shop          args( ( char * , AREA_DATA * ) );
void         load_resets        args( ( char * , AREA_DATA * ) );
void         load_mineral       args( ( char * , AREA_DATA * ) );
void         load_notes         args( ( void ) );
void         load_new_notes     args( ( const char * ) );
void         load_specials      args( ( FILE * ) );
void         load_help          args( ( char * ) );
void         load_sector        args( ( char * ) );
void         load_class         args( ( char * ) );
void         load_liq           args( ( char * ) );
void         load_joke          args( ( const char * ) );
void         load_social        args( ( char * , char * ) );
void         load_angel         args( ( const char * ) );
void         load_symbol        args( ( char * ) );
void         load_greeting      args( ( char * ) );
void         load_welcome       args( ( char * ) );
void         load_welcome_immortal args( ( char * ) );
void         load_site          args( ( char * ) );
void         load_server        args( ( const char * ) );
void         load_xnames        args( ( char * ) );
void         load_stock         args( ( const char * ) );
void         load_promotion     args( ( const char * ) );
void         load_hero          args( ( const char * ) );
void         load_skill         args( ( char * , char * ) );
void         load_instrument    args( ( char * , char * ) );
void         load_bus           args( ( char * ) );
void         load_ship          args( ( const char * ) );
void         load_quest         args( ( const char * ) );
void         load_question      args( ( const char * ) );
void         load_event         args( ( const char * ) );
void         load_gift          args( ( const char * ) );
void         load_bounty        args( ( const char * ) );
void         load_immlist       args( ( const char * ) );
void         load_donate        args( ( const char * ) );
void         load_club          args( ( const char * ) );
void         load_internal      args( ( char * ) );
void         load_sale          args( ( const char * ) );
void         set_vote_default   args( ( VOTE_DATA * ) );

/* ansi.c */
void    filter_ansi     args( ( char * ) );
void    tablize         args( ( int, char *, int , char *, int ) );
char *  ansi_code       args( ( char *, char *, int * ) );
char *  format_string   args( ( const char *, int ) );
void    ansi_transcribe args( ( char *, char * ) );

/* check.c */
extern  int     serial_time;
extern  int     serial_loop;

void initial_serial_time args( ( void ) );
void set_serial          args( ( SERIAL_DATA * ) );
void check_serial_number args( ( CD * ) );

/* buffer.c */
void   notify          args( ( int, int, const char *, ... ) );
void   clear_buffer    args( ( void ) );
void   clear_stack     args( ( void ) );
void   send_to_buffer  args( ( const char *, ... ) );
void   send_to_stack   args( ( const char *, ... ) );
void   print_buffer    args( ( CD * ) );
void   print_stack     args( ( CD * ) );
char * return_stack    args( ( void ) );
void   print_to_char   args( ( CD * , const char *, ... ) );
void   mudlog          args( ( int , const char *, ... ) );
void   output_buffer   args( ( void ) );

/* gamble.c */
void    initial_gamble args( ( void ) );
void    gamble_update  args( ( void ) );
void    extract_gamble args( ( CD * ) );

/* system.c */
char *          get_loading       args( ( void ) );
unsigned long   get_uptime        args( ( void ) );
bool            check_limit_ip    args( ( DD * ) );

/* enable.c */
extern          int     max_enable;
void            extract_an_enable  args( ( CD *, int ) );
void            set_enable         args( ( CD *, SKILL_DATA * ) );
ENABLE_DATA *   enable_repeat      args( ( ENABLE_DATA * , int ) );
void            extract_enable     args( ( CD * ) );
size_t          enable_count       args( ( CD * ) );
bool            exert_fight_enable args( ( CD *, CD * ) );
bool            exert_dodge_enable args( ( CD *, CD * ) );
bool            check_skill_enable args( ( CD *, SKILL_DATA * ) );

/* socket.c */
char  * get_user_name           args( ( int , SOCKET_DATA * ) );
void    check_multi_update      args( ( void ) );
char *  address_lookup          args( ( const char * ) );
void    set_address_data        args( ( const char * , const char * ) );
char *  address_mode            args( ( const char *, int mode ) );

/* signal.c */
void    signal_setup            args( ( void ) );
void    push_function           args( ( const char * ) );
void    pop_function            args( ( void ) );
void    close_all_socket        args( ( void ) );
bool    verify_char             args( ( CD * ) );
bool    verify_obj              args( ( OD * ) );
bool    verify_desc             args( ( DD * ) );

/* file.c */
FILE *  FOPEN                   args( ( const char *, const char * ) );
int     FCLOSE                  args( ( FILE * ) );
void    open_area_directory     args( ( void ) );
void    fill_path               args( ( char * ) );
void    load_help               args( ( char * ) );
bool    file_ext                args( ( const char * , const char * ) );
bool    is_regular              args( ( const char *  ) );
bool    is_directory            args( ( const char * ) );

extern  char                    LastFileName[MAX_FILE_LENGTH];

/* limit.c */
int  check_hand         args( ( CD *, int ) );
bool check_continue     args( ( CD *, CD * ) );
int  check_skill_rating args( ( char * ) );
bool check_can_kill     args( ( CD *, CD * ) );

/* ini.c */
void    read_ini                 args( ( const char * ) );
void    default_file             args( ( void ) );
void    adjust_filename          args( ( void ) );

/* lotto.c */
extern  int     lotto_paper;
extern  int     LottoFirst;
extern  int     LottoSecond;
extern  int     LottoThird;
extern  int     LottoForth;
void    lotto_generate           args( ( int ) );

void    lotto_update             args( ( void ) );

/* function.c */
void *  command_function_name    args( ( const char * ) );
void *  skill_function_name      args( ( const char * ) );
void *  check_function_name      args( ( const char * ) );
void *  check_routine_name       args( ( const char * ) );
void *  angel_function           args( ( const char * ) );
EVENT_FUN *     event_function   args( ( const char * ) );

/* verify.c */
int     verify_file              args( ( DD * ) );

/* ipc.c */
extern  int                     merc_ipc;
extern  int                     shmid;

void    init_share_memory       args( ( int ) );
void    delete_share_memory     args( ( int ) );
void    inc_share_memory_timer  args( ( void ) );
void    update_share_memory     args( ( DD * ) );
void    handle_share_memory     args( ( void ) );
int     get_free_share_memory   args( ( DD *, int ) );
void    set_share_memory_text   args( ( int , char * ) );
void    clean_share_memory_address args( ( int ) );

/* mount.c */
bool    unmount_char            args( ( CD *, CD * ) );
CD    * get_mount               args( ( CD * ) );
CD    * get_rider               args( ( CD * ) );

/* bus.c */
extern  char *                  company_name;
extern  char *                  platform_descr;
extern  char *                  loge_descr;
extern  char *                  platform_short;
extern  char *                  loge_short;

bool    check_station           args( ( RID * ) );
RID   * create_platform         args( ( int, char *, AREA_DATA * ) );
RID   * create_loge             args( ( int, char *, AREA_DATA * ) );
int     save_room               args( ( RID * ) );
bool    link_path               args( ( RID *, RID * ) );
void    bus_update              args( ( void ) );
BUS_DATA * is_station           args( ( RID * ) );
BUS_DATA * is_platform          args( ( RID * ) );
BUS_DATA * is_loge              args( ( RID * ) );

/* body.c */
void    random_situs            args( ( CD * ) );
void    init_max_situs          args( ( void ) );
int     damage_situs            args( ( CD *, int ) );
bool    is_armor                args( ( OD * ) );

extern int eq_max_capcity;
extern int eq_min_capcity;

/* mob_prog.c */
void    mprog_driver            args( ( char *, CD *, CD *, OD *, void * ) );

/* net.c */
extern  int                     internal_port;

NET_DATA * get_net_data         args( ( char * , int ) );
bool       valid_socket         args( ( NET_DATA *, int ) );
void       launch_internal      args( ( int ) );
void       close_net_socket     args( ( NET_DATA *, int ) );
bool       init_client          args( ( NET_DATA * ) );

/* ff7.c */
bool       is_magic_stone       args( ( OD * ) );
bool       can_cachet           args( ( OD * ) );
int        have_stone           args( ( CD * ) );
int        obj_stone            args( ( OD * ) );
void       check_wear_stone     args( ( CD *, int ) );
void       check_remove_stone   args( ( CD *, int ) );
void       gain_stone_exp       args( ( CD *, int ) );

/* club.c */
extern  int     club_room;
extern  int     max_club;

bool        char_to_club        args( ( char *, CLUB_DATA *, int ) );
bool        is_same_club        args( ( CD *, CD * ) );
CD *        is_online           args( ( const char * ) );
char *      club_name           args( ( CD * ) );
char *      is_club_class       args( ( CD * ) );
char *      club_class          args( ( CD *, CLUB_DATA * ) );
void        char_attach_club    args( ( CD * ) );
RID  *      club_recall         args( ( CD * ) );
RID *       club_location       args( ( CLUB_DATA * ) );
size_t      club_count          args( ( void ) );
size_t      club_notes          args( ( CD * ) );
size_t      club_unread         args( ( CD * ) );
CLUB_DATA * clubname_lookup args( ( const char *, int ) );

/* skill.c */
void        driver_flee         args( ( SKILL_DATA *, CD * ) );
int         get_practice        args( ( CD *, int ) );
bool        effect_driver       args( ( CD *, CD *, EFFECT_DATA * ) );
bool        gain_skill_exp      args( ( CD * , int , bool ) );

/* class.c */
char *      class_name          args( ( CLASS_DATA * ) );
bool        is_same_class       args( ( CD *, CD * ) );
int         get_skill_class_level args( ( SKILL_DATA *, CLASS_DATA * ) );
CLASS_DATA * is_class           args( ( char *, bool ) );
CLASS_DATA * class_lookup       args( ( int ) );

/* job.c */
JOB_FUN * job_lookup   args( ( const char * ) );

/* fs.c */
char * pw_lookup        args( ( int ) );
char * gr_lookup        args( ( int ) );
char * perm_of_file     args( ( mode_t ) );

/* enroll.c */
void set_enroll        args( ( CD *, CD * ) );
bool is_enroll         args( ( CD *, CD * ) );
void extract_enroll    args( ( CD *, const char * ) );
void mprog_enroll_trigger args( ( CD * ) );

/* stock.c */
void stock_update      args( ( void ) );
void save_stock        args( ( void ) );
int  stock_value       args( ( CD * ) );
void bote_stock        args( ( CD * ) );
void set_stock_value   args( ( int, int ) );

extern int	       StockShock;
extern int             StockTax;
extern int             StockBote;
extern int             StockQuota;
extern int             StockRelease;

/* quest.c */
void set_quest         args( ( CD *, char * ) );
void rem_quest         args( ( CD *, const char * ) );
bool is_quest          args( ( CD *, char *, char * ) );

/* enemy.c */
void set_enemy         args( ( CD *, char * ) );
void rem_enemy         args( ( CD *, const char * ) );
bool is_enemy          args( ( CD *, char *, char * ) );
bool check_enemy       args( ( CD *, const char * ) );
QUEST_INFO * quest_lookup args( ( const char * ) );

/* wizard.c */
IMMLIST_DATA *  imm_lookup      args( ( const char * ) );
void            system_cleanup  args( ( void ) );
bool            jail_someone    args( ( CD *, CD *, int, bool ) );

/* friend.c */
extern  int             max_friend;
void    extract_friend  args( ( CD * ) );
void    friend_msg      args( ( CD * ) );
size_t  friend_count    args( ( CD * ) );
FRIEND_DATA * is_friend args( ( CD *, const char * ) );

/* wedding.c */
void    check_mate      args( ( CD * ) );
char *  mate_name       args( ( CD * ) );
bool    is_couple       args( ( CD *, CD * ) );

/* spirit.c */
CD *    jade_to_spirit  args( ( CD *, OD * ) );
void    spirit_from_char args( ( CD * ) );

/* board.c */
extern  int     max_board;

void            board_update            args( ( void ) );
void            open_board_directory    args( ( void ) );
int             post_count              args( ( BOARD_DATA *, int type ) );
void            show_board_title        args( ( CD *, BOARD_DATA * ) );
BOARD_DATA *    board_lookup            args( ( int ) );
int             unread_post             args( ( CD *, BOARD_DATA * ) );

/* hero.c */
size_t          hero_count              args( ( void ) );
void            hero_add                args( ( CD * ) );
void            add_hero_bonus          args( ( CD * ) );
void            update_hero             args( ( void ) );
void            check_hero              args( ( char * ) );

/* hire.c */
void            all_mercenary_from_char args( ( CD * ) );
void            mercenary_from_char     args( ( CD *, CD * ) );
int             hire_cost               args( ( MID *, SHOP_DATA *, int ) );

/* angel.c */
void            angel_update            args( ( void ) );

/* arena.c */
extern int      pk_level;
extern int      pk_age;
extern int      pk_limit;
extern int      PkContrastLevel;
extern int      MinPKGold;
extern int      MaxPKGold;
extern int      MaxPKTotal;

void            fight_update            args( ( void ) );
void            init_fight              args( ( FIGHT_DATA * ) );
bool            is_pk                   args( ( CD * ) );
void            send_ante               args( ( int ) );
void            stop_pk                 args( ( void * ) );
void            return_ante             args( ( void ) );

/* top.c */
void            top_update              args( ( void ) );

/* wanted.c */
void            check_wanted            args( ( CD *, CD * ) );
extern int      WantedThreshold;

/* vote.c */
void            load_vote               args( ( const char * ) );
int             vote_count              args( ( CD * ) );

/* edit.c */
void            accept_edit             args( ( CD *, char * ) );
void            show_editor             args( ( CD * ) );
bool            is_edit                 args( ( DD * ) );

/* automap.c */
void            set_map                 args( ( CD *, int ) );
void            clear_trace             args( ( CD *, bool ) );
void            stop_automap            args( ( DD * ) );

/* chance.c */
void            generate_ticket         args( ( int ) );
void            dice_ticket             args( ( void ) );

extern int              TicketTotal;
extern int              TicketCost;
extern int              TicketReset;
extern int              ticketreset;
extern ORDER_DATA *     order_list;

/* gift.c */
void            set_gift_time           args( ( GIFT_DATA * ) );
void            check_gift              args( ( void ) );
void            gift_update             args( ( void ) );
bool            is_gift_stamp           args( ( int ) );
void            set_gift_stamp          args( ( CD *, int ) );
bool            check_gift_stamp        args( ( CD *, int ) );

/* event.c */
void            event_update            args( ( void ) );

/* bounty.c */
void            bounty_update           args( ( void ) );
void            check_bounty            args( ( CD *, CD * ) );
extern int      NowBounty;
extern int      BountyLimit;

/* question.c */
void            question_update         args( ( void ) );
void            send_answer             args( ( CD *, CD * ) );
extern int      PlyQuota;
extern int      PlyPenalty;
extern int      QuestionTimer;
extern int      QuestionFalse;
extern int      QuestionAlarm;

/* scan.c */
void            clean_scan              args( ( void ) );
void            scan_room               args( ( int, int, int ) );
void            print_scan              args( ( CD *, OD * ) );
extern SCAN_DATA                        ScanData[];
extern int                              ScanPointer;

/* variable.c */
extern  int                     RoomJailVnum;
extern  ROOM_INDEX_DATA *       RoomJail;
extern  int                     RoomLimboVnum;
extern  ROOM_INDEX_DATA *       RoomLimbo;
extern  int                     RoomDeadVnum;
extern  ROOM_INDEX_DATA *       RoomDead;
extern  int                     RoomRecallVnum;
extern  ROOM_INDEX_DATA *       RoomRecall;
extern  int                     RoomSchoolVnum;
extern  ROOM_INDEX_DATA *       RoomSchool;
extern  int                     RoomFailVnum;
extern  ROOM_INDEX_DATA *       RoomFail;
extern  int                     RoomChatVnum;
extern  ROOM_INDEX_DATA *       RoomChat;
extern  int                     RoomCorpseVnum;
extern  ROOM_INDEX_DATA *       RoomCorpse;
extern  AREA_DATA *             DefaultArea;
extern  int                     MobVampireVnum;
extern  MOB_INDEX_DATA *        MobVampire;
extern  int                     ObjProtypeVnum;
extern  OBJ_INDEX_DATA *        ObjProtype;
extern  int                     ObjMoneyVnum;
extern  OBJ_INDEX_DATA *        ObjMoney;
extern  int                     ObjMoneySomeVnum;
extern  OBJ_INDEX_DATA *        ObjMoneySome;
extern  int                     ObjCorpseNPCVnum;
extern  OBJ_INDEX_DATA *        ObjCorpseNPC;
extern  int                     ObjCorpsePCVnum;
extern  OBJ_INDEX_DATA *        ObjCorpsePC;
extern  int                     ObjHeadVnum;
extern  OBJ_INDEX_DATA *        ObjHead;
extern  int                     ObjHeartVnum;
extern  OBJ_INDEX_DATA *        ObjHeart;
extern  int                     ObjArmVnum;
extern  OBJ_INDEX_DATA *        ObjArm;
extern  int                     ObjLegVnum;
extern  OBJ_INDEX_DATA *        ObjLeg;
extern  int                     ObjTurdVnum;
extern  OBJ_INDEX_DATA *        ObjTurd;
extern  int                     ObjMushroomVnum;
extern  OBJ_INDEX_DATA *        ObjMushroom;
extern  int                     ObjLightVnum;
extern  OBJ_INDEX_DATA *        ObjLight;
extern  int                     ObjSpringVnum;
extern  OBJ_INDEX_DATA *        ObjSpring;
extern  int                     ObjDumplingVnum;
extern  OBJ_INDEX_DATA *        ObjDumpling;
extern  int                     ObjBougiVnum;
extern  OBJ_INDEX_DATA *        ObjBougi;
extern  int                     ObjPonVnum;
extern  OBJ_INDEX_DATA *        ObjPon;
extern  int                     ObjChickenVnum;
extern  OBJ_INDEX_DATA *        ObjChicken;
extern  int                     ObjMagicStoneVnum;
extern  OBJ_INDEX_DATA *        ObjMagicStone;
extern  int                     ObjMeatVnum;
extern  OBJ_INDEX_DATA *        ObjMeat;
extern  int                     ObjLetterVnum;
extern  OBJ_INDEX_DATA *        ObjLetter;
extern  bool                    ChatLog;
extern  bool                    ChannelAuction;
extern  bool                    ChannelChat;
extern  bool                    ChannelBulletin;
extern  bool                    ChannelImmtalk;
extern  bool                    ChannelMusic;
extern  bool                    ChannelQuestion;
extern  bool                    ChannelShout;
extern  bool                    ChannelYell;
extern  bool                    ChannelGamble;
extern  bool                    ChannelClass;
extern  bool                    ChannelClub;
extern  bool                    ChannelSemote;
extern  bool                    ChannelWeather;
extern  bool                    ChannelPhone;
extern  bool                    ChannelSuicide;
extern  bool                    ChannelRumor;
extern  bool                    ChannelNotice;
extern  bool                    ChannelGroup;
extern  bool                    ChannelPK;
extern  bool                    ConfigAutoExit;
extern  bool                    ConfigAutoLoot;
extern  bool                    ConfigAutoSac;
extern  bool                    ConfigBlank;
extern  bool                    ConfigBrief;
extern  bool                    ConfigCombine;
extern  bool                    ConfigPrompt;
extern  bool                    ConfigExact;
extern  bool                    ConfigMessage;
extern  bool                    ConfigFlee;
extern  bool                    ConfigAngel;
extern  bool                    ConfigAutoFood;
extern  bool                    ConfigAutoDrink;
extern  bool                    ConfigRebirth;
extern  bool                    ConfigTrain;
extern  bool                    ConfigPractice;
extern  bool                    ConfigAnsi;
extern  bool                    ConfigLotto;
extern  int                     MaxRepeat;
extern  int                     MinCNameLen;
extern  int                     MaxCNameLen;
extern  int                     MinPasswordLen;
extern  int                     AuthPort;
extern  int                     FingerPort;
extern  int                     TelnetPort;
extern  bool                    NotifyDebug;
extern  bool                    NotifyInfo;
extern  bool                    NotifyWizard;
extern  bool                    NotifyNewplayer;
extern  bool                    NotifyFailpass;
extern  bool                    NotifyEmerg;
extern  bool                    NotifyCrit;
extern  bool                    NotifyErr;
extern  bool                    NotifyXname;
extern  bool                    NotifyNet;
extern  int                     MaxLoginError;
extern  int                     MaxLoginIdle;
extern  int                     MaxPlayingIdle;
extern  int                     MaxCorpseIdle;
extern  int                     MaxGameIdle;
extern  int                     GoldWeight;
extern  int                     PryCost;
extern  int                     MaxAuctionGold;
extern  int                     AngelLevel;
extern  int                     MaxWhereGold;
extern  int                     MinWhereGold;
extern  int                     FindCost;
extern  int                     NoteLevel;
extern  int                     MaxHitroll;
extern  char                    DefaultEmail[];
extern  char                    DefaultUnit[];
extern  char                    FromUnknown[];

#define PUSH_FUNCTION( a )       push_function( (a) );
#define POP_FUNCTION()           pop_function();
#define RETURN( a )              { POP_FUNCTION(); return (a); }
#define RETURN_NULL()            { POP_FUNCTION(); return;     }

#undef  CD
#undef  MID
#undef  OD
#undef  OID
#undef  RID
#undef  SF
#undef  DD
#undef  SD
#undef  OTD
