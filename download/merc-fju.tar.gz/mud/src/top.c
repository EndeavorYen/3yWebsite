/***************************************************************************
*  �o�O�ѻ��j�ƾǨt�s�@�s�Ҽ��g���C���M�D��� merc ��s�ӨӡM�Ҧ������v    *
*  �N�|�Q�O�d�M���w��j�a�ק�M���ڭ̤]�Ʊ�A�̤]�ണ�ѵ��j�a�M�Ҧ�����    *
*  �~�欰�N���Q���\�C                                                      *
*                                                                          *
*  paul@mud.ch.fju.edu.tw                                                  *
*  lc@mud.ch.fju.edu.tw                                                    *
*                                                                          *
***************************************************************************/

#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "merc.h"

void top_update( void )
{
  TOP_DATA        * pTop;
  DESCRIPTOR_DATA * pDesc;
  struct tm       * sTime;
  time_t            nowtime;
  int               count;

  PUSH_FUNCTION( "update_top" );

  nowtime = time( NULL );
  if ( !( sTime = localtime( &nowtime ) ) ) RETURN_NULL();

  if ( !top_list
    || top_list->day  != sTime->tm_mday
    || top_list->hour != sTime->tm_hour )
  {
    pTop         = alloc_struct( STRUCT_TOP_DATA );
    pTop->day    = sTime->tm_mday;
    pTop->hour   = sTime->tm_hour;
    pTop->nRead  = 0;
    pTop->nWrite = 0;

    pTop->next = top_list;
    top_list   = pTop;
  }

  for ( count = 0, pDesc = descriptor_list; pDesc; pDesc = pDesc->next )
    if ( !pDesc->delete ) count++;

  top_list->number = UMAX( top_list->number, count );
  RETURN_NULL();
}

FUNCTION( do_top )
{
  TOP_DATA * pTop;
  TOP_DATA * pMax;
  TOP_DATA * pMin;
  int        max = -1;
  int        min = max_connect;
  int        number;
  int        loop;

  PUSH_FUNCTION( "do_top" );

  if ( !top_list ) top_update();

  pMax = top_list;
  pMin = top_list;

  clear_buffer();
  send_to_buffer( "�u�W���a�ƶq�έp���R\n\r%s", VERTICAL_LINE );

  for ( pTop = top_list; pTop; pTop = pTop->next )
  {
    number = UMIN( 45, ( pTop->number / 3 ) + 1 );

    send_to_buffer( "%2d��%s%2d�I %5dK/%5dK [%3d�H] \e[1;32m"
      , pTop->day
      , pTop->hour < 12 ? "���W" : ( pTop->hour >= 18 ? "�ߤW" : "�U��" )
      , pTop->hour % 12
      , pTop->nWrite / 1000
      , pTop->nRead  / 1000
      , pTop->number );

    for ( loop = 0; loop < number; loop++ ) send_to_buffer( "*" );
    send_to_buffer( "\e[0m\n\r" );

    if ( pTop->number > max )
    {
      max  = pTop->number;
      pMax = pTop;
    }

    if ( pTop->number < min )
    {
      min  = pTop->number;
      pMin = pTop;
    }
  }

  send_to_buffer(
    "%s�ɶ�%2d��%2d�I�ɡM���̤j�W�u�H�� %d�H�C"
    "\n\r�ɶ�%2d��%2d�I�ɡM���̤֤W�u�H�� %d�H�C\n\r"
    , VERTICAL_LINE
    , pMax->day, pMax->hour, max
    , pMin->day, pMin->hour, min );

  print_buffer( ch );
  RETURN_NULL();
}
