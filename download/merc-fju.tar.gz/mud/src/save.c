/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*  �o�O�ѻ��j�ƾǨt�s�@�s�Ҽ��g���C���M�D��� merc ��s�ӨӡM�Ҧ������v    *
*  �N�|�Q�O�d�M���w��j�a�ק�M���ڭ̤]�Ʊ�A�̤]�ണ�ѵ��j�a�M�Ҧ�����    *
*  �~�欰�N���Q���\�C                                                      *
*                                                                          *
*  paul@mud.ch.fju.edu.tw                                                  *
*  lc@mud.ch.fju.edu.tw                                                    *
*                                                                          *
***************************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "merc.h"
#include "directory.h"

#if !defined(macintosh)
extern  int     _filbuf         args( ( FILE * ) );
#endif

#define MAX_NEST        100
static  OBJ_DATA *      rgObjNest       [MAX_NEST];

#define SAVE_OBJ        1
#define DEPOSIT_OBJ     2
#define SAVE_CORPSE     3
#define BLANK_LENGTH    17

/* �ϰ��� */
void    fwrite_char     args( ( CHAR_DATA *, FILE * ) );
void    fwrite_obj      args( ( CHAR_DATA *, OBJ_DATA *, FILE *, int , int ) );
bool    fread_char      args( ( CHAR_DATA *, FILE * ) );
bool    fread_failcode  args( ( CHAR_DATA *, FILE * ) );
bool    fread_obj       args( ( CHAR_DATA *, FILE *, int ) );
void    fprint_string   args( ( FILE *, char *, const char * ) );
void    fprint_word     args( ( FILE *, char *, const char * ) );
void    fprint_number   args( ( FILE *, char *, int ) );
void    create_dir      args( ( const char * ) );
void    save_basic_file args( ( CHAR_DATA * ) );

char * initial( const char * str )
{
  static char strint[ MAX_STRING_LENGTH ];

  PUSH_FUNCTION( "initial" );
  strint[0] = LOWER( str[ 0 ] );
  RETURN( strint );
}

void create_dir( const char * name )
{
  struct stat file_stat;

  char pathname[MAX_STRING_LENGTH];

  PUSH_FUNCTION( "create_dir" );

  if ( !name || !*name )
  {
    mudlog( LOG_DEBUG, "create_name: �ӷ������T." );
    RETURN_NULL();
  }

  sprintf( pathname, "%s/%s/%s"
    , player_dir, initial( name ), normalize( name ) );

  if ( stat( pathname, &file_stat ) != 0 )
  {
    if ( mkdir( pathname, S_IRWXU | S_IRWXG ) != 0 )
      mudlog( LOG_DEBUG, "create_dir: �L�k�إߥؿ� %s.", name );

    RETURN_NULL();
  }

  if ( !S_ISDIR( file_stat.st_mode ) )
    mudlog( LOG_DEBUG, "create_dir: %s �w�g�إ�, �����O�ؿ�.", name );

  RETURN_NULL();
}

char * file_name( const char * name, int type )
{
  static char filename[ MAX_STRING_LENGTH ];

  PUSH_FUNCTION( "file_name" );

  if ( !name || !*name )
  {
    mudlog( LOG_DEBUG, "file_name: �ӷ������T." );
    filename[0] = '\x0';
    RETURN( filename );
  }

  switch( type )
  {
  default :
    filename[0] = '\x0';
    mudlog( LOG_DEBUG, "file_name: ���~���Ҧ� %d.", type );
    break;

  case SAVE_FILE:
    sprintf( filename, "%s/%s/%s/data"
      , player_dir, initial( name ), normalize( name ) );
    break;

  case BACKUP_FILE:
    sprintf( filename, "%s/%s/%s/backup"
      , player_dir, initial( name ), normalize( name ) );
    break;

  case FAILCODE_FILE:
    sprintf( filename, "%s/%s/%s/failcode"
      , player_dir, initial( name ), normalize( name ) );
    break;

  case BASIC_FILE:
    sprintf( filename, "%s/%s/%s/basic"
      , player_dir, initial( name ), normalize( name ) );
    break;

  case LOG_FILE:
    sprintf( filename, "%s/%s/%s/log"
      , player_dir, initial( name ), normalize( name ) );
    break;

  }

  RETURN( filename );
}

void save_char_obj( CHAR_DATA * ch , int type )
{
  char   strsave[MAX_FILE_LENGTH];
  FILE * pFile;

  PUSH_FUNCTION( "save_char_obj" );

  if ( !ch )
  {
    mudlog( LOG_DEBUG, "save_char_obj: �ӷ������T." );
    RETURN_NULL();
  }

  if ( IS_NPC( ch )
    || ( ch->desc && ch->desc->connected != CON_PLAYING )
    || ch->level <= 0 )
      RETURN_NULL();

  ch->save_time = current_time;
  str_cpy( strsave, file_name( ch->name , type ) );

  create_dir( ch->name );

  if ( !( pFile = FOPEN( strsave, "w" ) ) )
  {
    mudlog( LOG_DEBUG , "Save_char_obj: �}���ɮ� %s ���~.", ch->name );
  }

  else
  {
    fwrite_char( ch, pFile );
    if ( ch->carrying ) fwrite_obj( ch, ch->carrying, pFile, 0, SAVE_OBJ    );
    if ( ch->deposit  ) fwrite_obj( ch, ch->deposit , pFile, 0, DEPOSIT_OBJ );
    fprintf( pFile , "#END\n" );
    FCLOSE( pFile );

    /* �����ɮצs���Ҧ� */
    set_file_mode( strsave );

    /* Ū���ɮפj�p */
    char_filesize( ch );

    save_basic_file( ch );
  }

  RETURN_NULL();
}

void fwrite_char( CHAR_DATA * ch, FILE * fp )
{
  AFFECT_DATA * paf;
  ALIAS_DATA  * temp;
  ENABLE_DATA * enable;
  SKILL_DATA  * pSkill;
  QUEST_DATA  * pQuest;
  ENEMY_DATA  * pEnemy;
  FRIEND_DATA * pFriend;
  TRACE_DATA  * pTrace;
  STAMP_DATA  * pStamp;
  IP_DATA     * pIp;
  int           sn;
  int           loop;

  PUSH_FUNCTION( "fwrite_char" );

  fprintf( fp, "#PLAYER\n" );
  fprint_string( fp, "Name" , ch->name  );
  fprint_string( fp, "Cname", ch->cname );
  fprint_number( fp, "Room"
    , save_room( ( ch->in_room == RoomLimbo && ch->was_in_room )
      ? ch->was_in_room : ch->in_room ) );

  /* �Y�����`�_�u */
  fprint_string( fp, "LastHost"
    , ( ch->desc ) ? ch->desc->host : "�����`�_�u" );

  fprint_string( fp, "ShortDescr" , ch->short_descr );
  fprint_string( fp, "LongDescr"  , ch->long_descr  );
  fprint_string( fp, "Description", ch->description );
  fprint_string( fp, "Prompt"     , ch->prompt      );
  fprint_string( fp, "Email"      , ch->email       );
  fprint_string( fp, "Class"      ,
    ch->class ? ch->class->name : class_demos->name );

  fprint_string( fp, "Password"   , ch->pcdata->pwd        );
  fprint_string( fp, "Bamfin"     , ch->pcdata->bamfin     );
  fprint_string( fp, "Bamfout"    , ch->pcdata->bamfout    );
  fprint_number( fp, "Contract"   , ch->pcdata->contract   );
  fprint_number( fp, "SerialHigh" , ch->serial.high        );
  fprint_number( fp, "SerialLow"  , ch->serial.low         );
  fprint_string( fp, "Mate"       , ch->pcdata->mater      );
  fprint_string( fp, "Title"      , ch->pcdata->title      );
  fprint_number( fp, "Deny"       , ch->pcdata->deny       );
  fprint_number( fp, "Suspect"    , ch->pcdata->suspect    );
  fprint_number( fp, "PKWin"      , ch->pcdata->pkwin      );
  fprint_number( fp, "PKLost"     , ch->pcdata->pklost     );
  fprint_number( fp, "Kills"      , ch->pcdata->kills      );
  fprint_number( fp, "KillLevel"  , ch->pcdata->kill_level );
  fprint_number( fp, "Imprison"   , ch->pcdata->imprison   );
  fprint_number( fp, "FightWin"   , ch->fight_win          );
  fprint_number( fp, "FightLost"  , ch->fight_lost         );
  fprint_number( fp, "Rechristen" , ch->rechristen         );
  fprint_number( fp, "ClubLog"    , ch->clublog            );
  fprint_number( fp, "Firman"     , ch->firman             );
  fprint_number( fp, "Xname"      , ch->xname              );
  fprint_number( fp, "Jail"       , ch->jail               );
  fprint_number( fp, "Fail"       , ch->failed             );
  fprint_number( fp, "Steal"      , ch->steal              );
  fprint_number( fp, "Murder"     , ch->murder             );
  fprint_number( fp, "Sex"        , ch->sex                );
  fprint_number( fp, "Level"      , ch->level              );
  fprint_number( fp, "Trust"      , ch->trust              );
  fprint_number( fp, "Adviser"    , ch->adviser            );

  /* �����l�ܸ��| */
  for ( loop = 0; loop < MAX_TRACE; loop++ )
  {
    if ( !( pTrace = ch->pcdata->map[loop] ) ) continue;

    fprintf( fp, "AutoMap         %d %d %d"
      , loop, pTrace->starting, pTrace->ending );

    for ( sn = 0; sn < MAX_PATH; sn++ )
    {
      if ( pTrace->path[sn] == ERRORCODE ) break;
      fprintf( fp, " %d", pTrace->path[sn] );
    }

    fprintf( fp, "\n" );
  }

  fprint_number( fp, "Played",
    (int) ( ch->played ) + ( (int) current_time - (int) ch->logon) );

  if ( ch->home >= 0 ) fprint_number( fp, "Home", ch->home );

  if ( ch->autosave   > 0 ) fprint_number( fp, "AutoSave"  , ch->autosave   );
  if ( ch->autobackup > 0 ) fprint_number( fp, "AutoBackup", ch->autobackup );

  fprint_number( fp, "Dormancy" , ch->dormancy );
  fprint_number( fp, "EqCapcity", ch->eq_capcity );

  fprint_number( fp, "Note"      , ( int ) ch->last_note );
  fprint_number( fp, "Joke"      , ( int ) ch->last_joke );
  fprint_number( fp, "ClubNote"  , ( int ) ch->last_clubnote );
  fprint_number( fp, "Hit"       , ch->hit               );
  fprint_number( fp, "HitMax"    , ch->max_hit           );
  fprint_number( fp, "HItMod"    , ch->mod_hit           );
  fprint_number( fp, "Mana"      , ch->mana              );
  fprint_number( fp, "ManaMax"   , ch->max_mana          );
  fprint_number( fp, "ManaMod"   , ch->mod_mana          );
  fprint_number( fp, "Move"      , ch->move              );
  fprint_number( fp, "MoveMax"   , ch->max_move          );
  fprint_number( fp, "MoveMod"   , ch->mod_move          );
  fprint_number( fp, "Limit"     , ch->limit             );
  fprint_number( fp, "Gold"      , ch->gold              );
  fprint_number( fp, "Bank"      , ch->bank              );
  fprint_number( fp, "Pills"     , ch->pills             );
  fprint_number( fp, "Dosage"    , ch->dosage            );
  fprint_number( fp, "Ply"       , ch->pcdata->ply       );
  fprint_number( fp, "Donate"    , ch->donate            );
  fprint_number( fp, "Exp"       , ch->exp               );
  fprint_number( fp, "Act"       , ch->act               );
  fprint_number( fp, "WizFlags"  , ch->wizflags          );
  fprint_number( fp, "Tribunal"  , ch->tribunal_timer    );
  fprint_number( fp, "Angel"     , ch->angel_set         );
  fprint_number( fp ,"Turn"      , ch->turn              );
  fprint_number( fp ,"Notify"    , ch->notify            );
  fprint_number( fp, "AffectedBy", ch->affected_by       );
  fprint_number( fp, "Position"
    , ch->position == POS_FIGHTING ? POS_STANDING : ch->position );

  if ( IS_AFFECTED( ch, AFF_MASK ) && get_mob_index( ch->mask ) )
  {
    fprint_number( fp, "Mask", ch->mask );
  }

  fprint_number( fp, "Practice"   , ch->practice        );
  fprint_number( fp, "SavingThrow", ch->saving_throw    );
  fprint_number( fp, "Alignment"  , ch->alignment       );
  fprint_number( fp, "Hitroll"    , ch->hitroll         );
  fprint_number( fp, "Damroll"    , ch->damroll         );
  fprint_number( fp, "Armor"      , ch->armor           );
  fprint_number( fp, "Wimpy"      , ch->wimpy           );
  fprint_number( fp, "Deaf"       , ch->deaf            );
  fprint_number( fp, "Str"        , ch->now_str         );
  fprint_number( fp, "StrMod"     , ch->pcdata->mod_str );
  fprint_number( fp, "Int"        , ch->now_int         );
  fprint_number( fp, "IntMod"     , ch->pcdata->mod_int );
  fprint_number( fp, "Wis"        , ch->now_wis         );
  fprint_number( fp, "WisMod"     , ch->pcdata->mod_wis );
  fprint_number( fp, "Dex"        , ch->now_dex         );
  fprint_number( fp, "DexMod"     , ch->pcdata->mod_dex );
  fprint_number( fp, "Con"        , ch->now_con         );
  fprint_number( fp, "ConMod"     , ch->pcdata->mod_con );
  fprint_number( fp, "Drunk"      , ch->pcdata->condition[0] );
  fprint_number( fp, "Full"       , ch->pcdata->condition[1] );
  fprint_number( fp, "Thirst"     , ch->pcdata->condition[2] );
  fprint_number( fp, "Pagelen"    , ch->pcdata->pagelen );
  fprint_number( fp, "NSkill"     , ch->nskill          );

  /* �O���ǰe�I */
  fprintf( fp, str_space( "Recall" , BLANK_LENGTH ) );
  for ( loop = 0; loop < MAX_RECALL; loop++ )
      fprintf( fp ,"%-5d ", ch->recall[loop] );
  fprintf( fp ,"\n" );

  for ( pEnemy = ch->enemy; pEnemy; pEnemy = pEnemy->next )
    fprintf( fp, "%s%s~\n", str_space( "Enemy", BLANK_LENGTH ), pEnemy->city );

  for ( pStamp = ch->stamp; pStamp; pStamp = pStamp->next )
    fprintf( fp, "%s%d\n", str_space( "Stamp", BLANK_LENGTH ), pStamp->number );

  for ( pQuest = ch->quest; pQuest; pQuest = pQuest->next )
  {
    if ( !pQuest->link ) continue;
    fprintf( fp, "%s%s~\n", str_space( "Quest", BLANK_LENGTH )
     , pQuest->link->mark );
  }

  for ( pFriend = ch->friend; pFriend; pFriend = pFriend->next )
  {
    fprintf( fp, "%s%s~\n", str_space( "Friend", BLANK_LENGTH )
      , pFriend->name );
  }

  for ( temp = ch->alias; temp; temp = temp->next )
  {
    fprintf( fp, "%s%s~ %s~\n"
      , str_space( "Alias", BLANK_LENGTH ), temp->text, temp->macro );
  }

  for ( loop = 0; loop < MAX_NOTEPAD; loop++ )
  {
    if ( ch->notepad[loop] == NULL || ch->notepad[loop][0] == '\x0' )
      continue;

    fprintf( fp, "%s %2d %s~\n"
      , str_space( "NotePad", BLANK_LENGTH ), loop, ch->notepad[loop] );
  }

  for ( pIp = ch->connect; pIp; pIp = pIp->next )
  {
    fprintf( fp, "%s%s~\n"
      , str_space( "LimitIP", BLANK_LENGTH ), pIp->address );
  }

  for ( enable = ch->enable; enable; enable = enable->next )
    fprint_word( fp, "Enable" , get_skill( enable->slot)->name );

  /* ��Ѳ��g�J���a�ɮ� */
  for ( sn = 0; sn < MAX_STOCK; sn++ )
  {
    if ( ch->stock[sn] > 0 && stock_data[sn].name )
    {
      fprintf( fp, "%s%d %d %d\n"
        , str_space( "Stocks", BLANK_LENGTH )
        , sn + 1, ch->stock[sn], ch->asset[sn] );
    }
  }

  /* �⪩��Ū���O���g���ɮ� */
  for ( sn = 0; sn < max_board; sn++ )
  {
    if ( ch->board[sn] > 0 && board_lookup( sn ) )
      fprintf( fp, "%s%d %d\n", str_space( "Board", BLANK_LENGTH )
        , sn, ch->board[sn] );
  }

  /* ��ޯ�g�J���a���ɮפ��� */
  for ( sn = 0; sn < MAX_SKILL; sn++ )
  {
    if ( ch->skill[sn] > 0 && ( ( pSkill = get_skill(sn) ) != NULL ) )
    {
      fprintf( fp, "%s%d '%s'\n"
        , str_space( "Learn" , BLANK_LENGTH )
        , ch->skill[sn], pSkill->name );
    }
  }

  for ( paf = ch->affected; paf; paf = paf->next )
  {
    fprintf( fp, "%s%3d %3d %3d %3d %10d\n"
      , str_space( "Affect" , BLANK_LENGTH )
      , paf->type, paf->duration, paf->modifier
      , paf->location, paf->bitvector );
  }

  fprintf( fp, "End\n\n" );
  RETURN_NULL();
}

/* �g�J���~ */
void fwrite_obj( CHAR_DATA * ch, OBJ_DATA * obj, FILE * fp
                , int iNest, int type )
{
  int                loop;
  EXTRA_DESCR_DATA * ed;
  AFFECT_DATA      * paf;
  CACHET_DATA      * pCachet;

  PUSH_FUNCTION( "fwrite_obj" );

  if ( obj->next_content )
    fwrite_obj( ch, obj->next_content, fp, iNest , type );

  if ( ( ch->level + 10 ) < obj->level
     || obj->item_type == ITEM_KEY
     || obj->item_type == ITEM_POTION
     || IS_SET( obj->extra_flags, ITEM_NOSAVE ) )
     RETURN_NULL();

  set_serial( &obj->serial );

  switch ( type )
  {
  default :
    fprintf( fp, "#UNKNOWN\n" );
    break;

  case SAVE_OBJ:
    fprintf( fp , "#OBJECT\n" );
    break;

  case DEPOSIT_OBJ:
    fprintf( fp , "#DEPOSIT\n" );
    break;

  case SAVE_CORPSE:
    fprintf( fp , "#CORPSE\n" );
    break;
  }

  fprint_number( fp, "Nest"       , iNest );
  fprint_string( fp, "Name"       , obj->name );
  fprint_string( fp, "ShortDescr" , obj->short_descr      );
  fprint_string( fp, "Description", obj->description      );
  fprint_number( fp, "Vnum"       , obj->pIndexData->vnum );
  fprint_number( fp, "ExtraFlags" , obj->extra_flags      );
  fprint_number( fp, "WearFlags"  , obj->wear_flags       );
  fprint_number( fp, "WearLoc"    , obj->wear_loc         );
  fprint_number( fp, "ItemType"   , obj->item_type        );
  fprint_number( fp, "Weight"     , obj->weight           );
  fprint_number( fp, "Level"      , obj->level            );
  fprint_number( fp, "SerialHigh" , obj->serial.high      );
  fprint_number( fp, "SerialLow"  , obj->serial.low       );
  fprint_number( fp, "Timer"      , obj->timer            );
  fprint_number( fp, "Cost"       , obj->cost             );

  if ( obj->owner.high > 0 && obj->owner.low > 0 )
  {
    fprint_number( fp, "OwnerHigh" , obj->owner.high );
    fprint_number( fp, "OwnerLow"  , obj->owner.low  );
  }

  /* �O�_���r */
  if ( obj->venom > 0 ) fprint_number( fp, "Venom", obj->venom );

  if ( obj->max_armor > 0 )
  {
    fprint_number( fp, "MaxArmor"   , obj->max_armor        );
    fprint_number( fp, "Armor"      , obj->armor            );
  }

  fprintf( fp, str_space( "Values" , BLANK_LENGTH ) );
  for ( loop = 0; loop < MAX_OBJECT_VALUE; loop++ )
      fprintf( fp ,"%d ", obj->value[loop] );
  fprintf( fp ,"\n" );

  for ( pCachet = obj->cachet; pCachet; pCachet = pCachet->next )
  {
    fprintf( fp, "%s%d\n"
      , str_space( "Cachet", BLANK_LENGTH ), pCachet->vnum );
  }

  for ( paf = obj->affected; paf; paf = paf->next )
  {
    fprintf( fp, "%s%d %d %d %d %d\n"
      , str_space( "Affect" , BLANK_LENGTH )
      , paf->type, paf->duration, paf->modifier
      , paf->location, paf->bitvector );
  }

  for ( ed = obj->extra_descr; ed; ed = ed->next )
    fprintf( fp, "%s%s~ %s~\n", str_space( "ExtraDescr" , BLANK_LENGTH )
      , ed->keyword, ed->description );

  fprintf( fp, "End\n\n" );
  if ( obj->contains ) fwrite_obj( ch, obj->contains, fp, iNest + 1 , type );

  RETURN_NULL();
}

int load_char_obj( DESCRIPTOR_DATA * d, char * name )
{
  char        strsave[MAX_INPUT_LENGTH];
  CHAR_DATA * ch;
  FILE      * pFile;
  int         loop;
  int         iNest;

  PUSH_FUNCTION( "load_char_obj" );

  /* �t�m�O���� */
  clear_char( ch = alloc_struct( STRUCT_CHAR_DATA ) );

  /* �t�m�O���� */
  ch->pcdata = alloc_struct( STRUCT_PC_DATA );

  memset( ch->pcdata, 0, sizeof( PC_DATA ) );

  d->character           = ch;
  ch->desc               = d;
  ch->name               = str_dup( name );
  ch->cname              = str_dup( "" );
  ch->prompt             = str_dup( "" );
  ch->email              = str_dup( "" );
  ch->wizflags           = 0;
  ch->tribunal_timer     = 0;
  ch->act                = 0;
  ch->now_str            = DefaultStr;
  ch->now_int            = DefaultInt;
  ch->now_wis            = DefaultWis;
  ch->now_dex            = DefaultDex;
  ch->now_con            = DefaultCon;
  ch->pcdata->pwd        = str_dup( "" );
  ch->pcdata->bamfin     = str_dup( "" );
  ch->pcdata->bamfout    = str_dup( "" );
  ch->pcdata->title      = str_dup( "" );
  ch->pcdata->lasthost   = str_dup( "" );
  ch->pcdata->mater      = str_dup( "" );
  ch->pcdata->contract   = FALSE;
  ch->pcdata->pagelen    = 20;
  ch->pcdata->condition[COND_THIRST]  = 100;
  ch->pcdata->condition[COND_FULL]    = 100;

  ch->pcdata->trace = NULL;
  for ( loop = 0; loop < MAX_TRACE; loop++ ) ch->pcdata->map[loop] = NULL;

  str_cpy( strsave, file_name( name, SAVE_FILE ) );
  if ( access( strsave , R_OK ) != 0 ) RETURN( FILE_NEW );

  if ( ( pFile = FOPEN( strsave, "r" ) ) )
  {
    for ( iNest = 0; iNest < MAX_NEST; iNest++ ) rgObjNest[iNest] = NULL;

    for ( ;; )
    {
      char   letter;
      char * word;

      letter = fread_letter( pFile );
      if ( letter == '*' )
      {
        fread_to_eol( pFile );
        continue;
      }

      if ( letter != '#' )
      {
        mudlog( LOG_DEBUG , "Load_char_obj: ���o�{�� # �Ÿ� ." );
        FCLOSE( pFile );
        RETURN( FILE_ERROR );
      }

      word = fread_word( pFile );
      if ( !str_cmp( word, "PLAYER" ) )
      {
        if ( !fread_char( ch, pFile ) )
        {
          FCLOSE( pFile );
          RETURN( FILE_ERROR );
        }
      }

      else if ( !str_cmp( word, "OBJECT" ) )
      {
        if ( !fread_obj( ch, pFile , LOAD_OBJECT ) )
        {
          FCLOSE( pFile );
          RETURN( FILE_ERROR );
        }
      }

      else if ( !str_cmp( word, "DEPOSIT" ) )
      {
        if ( !fread_obj( ch, pFile , LOAD_DEPOSIT ) )
        {
          FCLOSE( pFile );
          RETURN( FILE_ERROR );
        }
      }

      else if ( !str_cmp( word, "END" ) ) break;

      else
      {
        mudlog( LOG_DEBUG , "Load_char_obj: ���a�ɮפ����T�����A." );
        FCLOSE( pFile );
        RETURN( FILE_ERROR );
      }
    }

    FCLOSE( pFile );

    /* Ū���ɮפj�p */
    char_filesize( ch );
  }

  str_cpy( strsave, file_name( name, FAILCODE_FILE ) );
  if ( access( strsave, R_OK ) == 0 && ( pFile = FOPEN( strsave, "r" ) ) )
  {
    if ( !fread_failcode( ch, pFile ) )
    {
      FCLOSE( pFile );
      RETURN( FILE_ERROR );
    }

    FCLOSE( pFile );
  }

  RETURN( FILE_CORRECT );
}

void fwrite_failcode( CHAR_DATA * ch, const char * address )
{
  char   failcode[MAX_FILE_LENGTH];
  char   pAddress[MAX_STRING_LENGTH];
  FILE * pFile;

  PUSH_FUNCTION( "fwrite_failcode" );

  if ( !ch || IS_NPC( ch ) || !address || !*address )
  {
    mudlog( LOG_DEBUG, "fwrite_failcode: �ӷ������T." );
    RETURN_NULL();
  }

  str_cpy( failcode, file_name( ch->name, FAILCODE_FILE ) );

  if ( ( pFile = FOPEN( failcode, "a" ) ) )
  {
    str_cpy( pAddress, address );
    smash_tilde( pAddress );
    fprintf( pFile, "%s%s~ %d\n"
      , str_space( "FailCode", BLANK_LENGTH ), pAddress, ( int ) current_time );

    FCLOSE( pFile );

    /* �����ɮצs���Ҧ� */
    set_file_mode( failcode );
  }

  else
  {
    mudlog( LOG_DEBUG, "fwrite_failcode: �L�k�g�J���~�K�X�O����%s.", failcode );
  }
  RETURN_NULL();
}

#if defined(KEY)
#undef KEY
#endif

#define KEY( literal, field, value )                                    \
                                if ( !str_cmp( word, literal ) )        \
                                {                                       \
                                    field  = value;                     \
                                    fMatch = TRUE;                      \
                                    break;                              \
                                }

bool fread_char( CHAR_DATA * ch, FILE * fp )
{
  char * word;
  bool   fMatch;

  PUSH_FUNCTION( "fread_char" );

  for ( ; ; )
  {
    word   = feof( fp ) ? "End" : fread_word( fp );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( fp );
      break;

    case 'A':
      KEY( "AutoSave",   ch->autosave,    fread_number( fp ) );
      KEY( "AutoBackup", ch->autobackup,  fread_number( fp ) );
      KEY( "Act",        ch->act,         fread_number( fp ) );
      KEY( "AffectedBy", ch->affected_by, fread_number( fp ) );
      KEY( "Alignment",  ch->alignment,   fread_number( fp ) );
      KEY( "Armor",      ch->armor,       fread_number( fp ) );
      KEY( "Adviser",    ch->adviser,     fread_number( fp ) );

      if ( !str_cmp( word, "Angel" ) )
      {
        ch->angel_set = ch->angel_left = fread_number( fp );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "Alias" ) )
      {
        ALIAS_DATA * pAlias;
        ALIAS_DATA * zAlias;
        char       * point;

        pAlias = alloc_struct( STRUCT_ALIAS_DATA );

        point  = ( char * ) fread_string( fp );
        str_cpy( pAlias->text , point );
        free_string( point );

        point = ( char * ) fread_string( fp );
        str_cpy( pAlias->macro , point );
        free_string( point );

        pAlias->next = NULL;

        for ( zAlias = ch->alias;
          zAlias && zAlias->next;
          zAlias = zAlias->next );

        if ( !zAlias ) ch->alias    = pAlias;
        else           zAlias->next = pAlias;
        fMatch       = TRUE;
        break;
      }

      if ( !str_cmp( word, "Affect" ) )
      {
        AFFECT_DATA * paf;

        /* �t�m�O���� */
        paf = alloc_struct( STRUCT_AFFECT_DATA );

        paf->type      = fread_number( fp );
        paf->duration  = fread_number( fp );
        paf->modifier  = fread_number( fp );
        paf->location  = fread_number( fp );
        paf->bitvector = fread_number( fp );
        paf->next      = ch->affected;
        ch->affected   = paf;
        fMatch         = TRUE;
        break;
      }

      if ( !str_cmp( word, "AutoMap" ) )
      {
        TRACE_DATA * pTrace;
        int          sn;
        int          loop = 0;

        pTrace = alloc_struct( STRUCT_TRACE_DATA );

        sn               = fread_number( fp );
        sn               = UMIN( MAX_TRACE -1 , UMAX( 0, sn ) );
        pTrace->starting = fread_number( fp );
        pTrace->ending   = fread_number( fp );

        for ( loop = 0; loop < MAX_PATH; loop++ )
          pTrace->path[loop] = ERRORCODE;

        loop = 0;

        for ( loop = 0; loop < MAX_PATH; loop++ )
        {
          if ( fread_if_eol( fp ) ) break;
          pTrace->path[loop] = fread_number( fp );
        }

        if ( !get_room_index( pTrace->starting )
          || !get_room_index( pTrace->ending )
          || ch->pcdata->map[sn] )
        {
          free_struct( pTrace, STRUCT_TRACE_DATA );
        }

        else
        {
          ch->pcdata->map[sn] = pTrace;
        }

        fread_to_eol( fp );

        fMatch = TRUE;
        break;
      }
      break;

    case 'B':
      KEY( "Bamfin",  ch->pcdata->bamfin , fread_string( fp ) );
      KEY( "Bamfout", ch->pcdata->bamfout, fread_string( fp ) );
      KEY( "Bank",    ch->bank           , fread_number( fp ) );

      if ( !str_cmp( word, "Board" ) )
      {
        int sn;

        sn = fread_number( fp );

        if ( sn < 0 || sn >= max_board || !board_lookup( sn ) )
          mudlog( LOG_DEBUG, "fread_char: ���������� %d.", sn );

        else
          ch->board[sn] = fread_number( fp );

        fMatch = TRUE;
        break;
      }
      break;

    case 'C':

      if ( !str_cmp( word , "Class" ) )
      {
        char       * pName;
        CLASS_DATA * pClass;

        if ( !( pClass = is_class( ( pName = fread_string( fp ) ), TRUE ) ) )
        {
          mudlog( LOG_DEBUG , "%s ��¾�~ %s �q��.", ch->name , pName );
          pClass  = class_demos;
        }

        free_string( pName );
        fMatch    = TRUE;
        ch->class = pClass;
        break;
      }

      KEY( "Clublog" , ch->clublog         , fread_number( fp ) );
      KEY( "ClubNote", ch->last_clubnote   , fread_number( fp ) );
      KEY( "Cname"   , ch->cname           , fread_string( fp ) );
      KEY( "Con"     , ch->now_con         , fread_number( fp ) );
      KEY( "ConMod"  , ch->pcdata->mod_con , fread_number( fp ) );
      KEY( "Contract", ch->pcdata->contract, fread_number( fp ) );
      break;

    case 'D':
      KEY( "Damroll"    , ch->damroll        , fread_number( fp ) );
      KEY( "Deaf"       , ch->deaf           , fread_number( fp ) );
      KEY( "Deny"       , ch->pcdata->deny   , fread_number( fp ) );
      KEY( "Description", ch->description    , fread_string( fp ) );
      KEY( "Dex"        , ch->now_dex        , fread_number( fp ) );
      KEY( "DexMod"     , ch->pcdata->mod_dex, fread_number( fp ) );
      KEY( "Dormancy"   , ch->dormancy       , fread_number( fp ) );
      KEY( "Dosage"     , ch->dosage         , fread_number( fp ) );
      KEY( "Donate"     , ch->donate         , fread_number( fp ) );
      KEY( "Drunk"      , ch->pcdata->condition[0] , fread_number( fp ) );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) ) RETURN( TRUE );

      KEY( "Exp"      , ch->exp       , fread_number( fp ) );
      KEY( "EqCapcity", ch->eq_capcity, fread_number( fp ) );

      if ( !str_cmp( word, "Enable" ) )
      {
        SKILL_DATA * pSkill;

        /* �p�G�ޯ�w�g���s�b */
        if ( !( pSkill = skill_isname( fread_word( fp ) ) ) )
        {
          fMatch = TRUE;
          break;
        }

        /* �p�G���� */
        if ( ( enable_repeat( ch->enable , pSkill->slot ) ) )
        {
          fMatch = TRUE;
          break;
        }

        set_enable( ch, pSkill );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "Enemy" ) )
      {
        char * mark;

        mark = fread_string( fp );
        set_enemy( ch, mark );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word , "Email" ) )
      {
         free_string( ch->email );
         ch->email = fread_string( fp );
         fMatch = TRUE;
         break;
      }

      break;

    case 'F':

      KEY( "Full"     , ch->pcdata->condition[1] , fread_number( fp ) );
      KEY( "Firman"   , ch->firman               , fread_number( fp ) );
      KEY( "Fail"     , ch->failed               , fread_number( fp ) );
      KEY( "FightWin" , ch->fight_win            , fread_number( fp ) );
      KEY( "FightLost", ch->fight_lost           , fread_number( fp ) );

      if ( !str_cmp( word, "Friend" ) )
      {
        FRIEND_DATA * pFriend;
        char        * name;

        pFriend = alloc_struct( STRUCT_FRIEND_DATA );
        name  = ( char * ) fread_string( fp );
        str_cpy( pFriend->name, name );
        free_string( name );

        pFriend->next = ch->friend;
        ch->friend    = pFriend;

        fMatch       = TRUE;
        break;
      }

      break;

    case 'G':
      KEY( "Gold", ch->gold, fread_number( fp ) );
      break;

    case 'H':
      KEY( "Hit"    , ch->hit    , fread_number( fp ) );
      KEY( "HitMax" , ch->max_hit, fread_number( fp ) );
      KEY( "HitMod" , ch->mod_hit, fread_number( fp ) );
      KEY( "Hitroll", ch->hitroll, fread_number( fp ) );
      KEY( "Home"   , ch->home   , fread_number( fp ) );
      break;

    case 'I':
      KEY( "Int"     , ch->now_int         , fread_number( fp ) );
      KEY( "IntMod"  , ch->pcdata->mod_int , fread_number( fp ) );
      KEY( "Imprison", ch->pcdata->imprison, fread_number( fp ) );
      break;

    case 'J':
      KEY( "Jail", ch->jail , fread_number( fp ) );
      KEY( "Joke", ch->last_joke, fread_number( fp ) );
      break;

    case 'K':
      KEY( "Kills" ,    ch->pcdata->kills ,      fread_number( fp ) );
      KEY( "KillLevel", ch->pcdata->kill_level , fread_number( fp ) );
      break;

    case 'L':
      KEY( "Level",     ch->level,            fread_number( fp ) );
      KEY( "Limit",     ch->limit,            fread_number( fp ) );
      KEY( "LongDescr", ch->long_descr,       fread_string( fp ) );
      KEY( "LastHost",  ch->pcdata->lasthost, fread_string( fp ) );

      if ( !str_cmp( word, "LimitIP" ) )
      {
        IP_DATA    * pIp;

        pIp = alloc_struct( STRUCT_IP_DATA );
        pIp->address = fread_string( fp );
        pIp->next    = ch->connect;
        ch->connect  = pIp;

        fMatch       = TRUE;
        break;
      }

      if ( !str_cmp( word, "Learn" ) )
      {
        SKILL_DATA * pSkill;
        int          value;

        value  = fread_number( fp );

        if ( ( pSkill = skill_isname( fread_word( fp ) ) ) == NULL )
        {
          mudlog( LOG_DEBUG , "Fread_char: �������ޯ�." );
        }
        else
        {
          ch->skill[pSkill->slot] = value;
        }

        fMatch = TRUE;
        break;
      }

      break;

    case 'M':

      KEY( "Mana"   , ch->mana         , fread_number( fp ) );
      KEY( "ManaMax", ch->max_mana     , fread_number( fp ) );
      KEY( "ManaMod", ch->mod_mana     , fread_number( fp ) );
      KEY( "Mate"   , ch->pcdata->mater, fread_string( fp ) );
      KEY( "Move"   , ch->move         , fread_number( fp ) );
      KEY( "MoveMax", ch->max_move     , fread_number( fp ) );
      KEY( "MoveMod", ch->mod_move     , fread_number( fp ) );
      KEY( "Murder" , ch->murder       , fread_number( fp ) );

      if ( !str_cmp( word, "Mask" ) )
      {
        int mask;

        if ( ( get_mob_index( mask = fread_number( fp ) ) ) )
          ch->mask = mask;

        fMatch = TRUE;
        break;
      }

      break;

    case 'N':

      KEY( "Note"  , ch->last_note, fread_number( fp ) );
      KEY( "Notify", ch->notify   , fread_number( fp ) );
      KEY( "NSkill", ch->nskill   , fread_number( fp ) );

      if ( !str_cmp( word, "Name" ) )
      {
        fread_to_eol( fp );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "NotePad" ) )
      {
        int loop;

        loop = fread_number( fp );
        loop = UMIN( MAX_NOTEPAD - 1, UMAX( loop, 0 ) );
        free_string( ch->notepad[loop] );
        ch->notepad[loop] = fread_string( fp );

        fMatch = TRUE;
        break;
      }
      break;

    case 'P':
      KEY( "Pagelen",  ch->pcdata->pagelen, fread_number( fp ) );
      KEY( "Password", ch->pcdata->pwd,     fread_string( fp ) );
      KEY( "PKLost",   ch->pcdata->pklost , fread_number( fp ) );
      KEY( "PKWin" ,   ch->pcdata->pkwin ,  fread_number( fp ) );
      KEY( "Played",   ch->played,          fread_number( fp ) );
      KEY( "Position", ch->position,        fread_number( fp ) );
      KEY( "Practice", ch->practice,        fread_number( fp ) );
      KEY( "Pills"   , ch->pills,           fread_number( fp ) );
      KEY( "Ply"     , ch->pcdata->ply,     fread_number( fp ) );

      if ( !str_cmp( word , "Prompt" ) )
      {
         free_string( ch->prompt );
         ch->prompt = fread_string( fp );
         fMatch = TRUE;
         break;
      }

      break;

    case 'Q':

      if ( !str_cmp( word, "Quest" ) )
      {
        char * mark;

        if ( quest_lookup( mark = fread_string( fp ) ) ) set_quest( ch, mark );
        else          mudlog( LOG_DEBUG , "Fread_char: ���������� %s.", mark );

        fMatch = TRUE;
        break;
      }

      break;

    case 'R':

      if ( !str_cmp( word, "Recall" ) )
      {
        int               loop;
        ROOM_INDEX_DATA * pRoom;

        for ( loop = 0; loop < MAX_RECALL; loop++ )
        {
          ch->recall[loop] = fread_number( fp );

          if ( ch->recall[loop] > 0 )
          {
            if ( !( pRoom = get_room_index( ch->recall[loop] ) )
              || !IS_SET( pRoom->room_flags, ROOM_MEMORIZE ) )
              ch->recall[loop] = 0;
          }
        }

        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "Room" ) )
      {
        if ( !( ch->in_room = get_room_index( fread_number( fp ) ) ) )
        {
          send_to_char( "�䤣��A��Ӫ��ж��M�u�n��A�ǰe��_�l�I�T\n\r" , ch );
          ch->in_room = get_hometown( ch );
        }

        fMatch = TRUE;
        break;
      }

      KEY( "Rechristen", ch->rechristen, fread_number( fp ) );
      break;

    case 'S':

      KEY( "SerialHigh" , ch->serial.high    , fread_number( fp ) );
      KEY( "SerialLow"  , ch->serial.low     , fread_number( fp ) );
      KEY( "Str"        , ch->now_str        , fread_number( fp ) );
      KEY( "StrMod"     , ch->pcdata->mod_str, fread_number( fp ) );
      KEY( "SavingThrow", ch->saving_throw   , fread_number( fp ) );
      KEY( "Suspect"    , ch->pcdata->suspect, fread_number( fp ) );
      KEY( "Sex"        , ch->sex            , fread_number( fp ) );
      KEY( "ShortDescr" , ch->short_descr    , fread_string( fp ) );
      KEY( "Steal"      , ch->steal          , fread_number( fp ) );

      if ( !str_cmp( word, "Stocks" ) )
      {
        int sn;
        int number;
        int gold;

        sn     = fread_number( fp ) - 1;
        number = fread_number( fp );
        gold   = fread_number( fp );

        if ( sn < 0 || sn >= MAX_STOCK || !stock_data[sn].name )
          mudlog( LOG_DEBUG, "fread_char: �������Ѳ��ƭ� %d.", sn );

        ch->stock[sn] = UMIN( max_stock_buy, UMAX( 0, number ) );

        if ( ( ch->asset[sn] = gold ) <= 0 )
          ch->asset[sn] = stock_data[sn].cost;

        ch->asset[sn] = UMIN( MAX_STOCK_COST, ch->asset[sn] );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "Stamp" ) )
      {
        int number;

        if ( is_gift_stamp( number = fread_number( fp ) ) )
          set_gift_stamp( ch, number );

        fMatch = TRUE;
        break;
      }

      break;

    case 'T':
      KEY( "Thirst"  , ch->pcdata->condition[2], fread_number( fp ) );
      KEY( "Trust"   , ch->trust               , fread_number( fp ) );
      KEY( "Turn"    , ch->turn                , fread_number( fp ) );
      KEY( "Title"   , ch->pcdata->title       , fread_string( fp ) );
      KEY( "Tribunal", ch->tribunal_timer      , fread_number( fp ) );
      break;

    case 'V':
      if ( !str_cmp( word, "Vnum" ) )
      {
        ch->pIndexData = get_mob_index( fread_number( fp ) );
        fMatch = TRUE;
        break;
      }
      break;

    case 'W':
      KEY( "WizFlags", ch->wizflags       , fread_number( fp ) );
      KEY( "Wimpy"   , ch->wimpy          , fread_number( fp ) );
      KEY( "Wis"     , ch->now_wis        , fread_number( fp ) );
      KEY( "WisMod"  , ch->pcdata->mod_wis, fread_number( fp ) );
      break;

    case 'X':
      KEY( "Xname", ch->xname, fread_number( fp ) );
      break;
    }

    if ( !fMatch )
    {
      mudlog( LOG_DEBUG , "Fread_char: �䤣�쥿�T�����A." );
      RETURN( FALSE );
    }
  }
}

bool fread_obj( CHAR_DATA * ch, FILE * fp , int type )
{
  OBJ_DATA * obj;
  char     * word;
  int        iNest;
  bool       fMatch;
  bool       fNest;
  bool       fVnum;

  PUSH_FUNCTION( "fread_obj" );

  /* �t�m�O���� */
  obj = alloc_struct( STRUCT_OBJ_DATA );

  /* �]�w�w�]�� */
  obj->name        = str_dup( "" );
  obj->short_descr = str_dup( "" );
  obj->description = str_dup( "" );

  for ( fNest = FALSE, fVnum = TRUE, iNest = 0; ; )
  {
    word   = feof( fp ) ? "End" : fread_word( fp );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( fp );
      break;

    case 'A':

      if ( !str_cmp( word, "Affect" ) )
      {
        AFFECT_DATA * paf;

        /* �t�m�O���� */
        paf = alloc_struct( STRUCT_AFFECT_DATA );

        paf->type      = fread_number( fp );
        paf->duration  = fread_number( fp );
        paf->modifier  = fread_number( fp );
        paf->location  = fread_number( fp );
        paf->bitvector = fread_number( fp );
        paf->next      = obj->affected;
        obj->affected  = paf;
        fMatch         = TRUE;
        break;
      }

      KEY( "Armor", obj->armor, fread_number( fp ) );
      break;

    case 'C':

      KEY( "Cost", obj->cost, fread_number( fp ) );

      if ( !str_cmp( word, "Cachet" ) )
      {
        CACHET_DATA * pCachet;
        int           vnum;

        if ( get_obj_index( ( vnum = fread_number( fp ) ) ) )
        {
          pCachet = alloc_struct( STRUCT_CACHET_DATA );
          pCachet->vnum = vnum;
          pCachet->next = obj->cachet;
          obj->cachet   = pCachet;
        }

        fMatch = TRUE;
        break;
      }

      break;

    case 'D':
      KEY( "Description", obj->description, fread_string( fp ) );
      break;

    case 'E':
      KEY( "ExtraFlags", obj->extra_flags, fread_number( fp ) );

      if ( !str_cmp( word, "ExtraDescr" ) )
      {
        EXTRA_DESCR_DATA * ed;

        /* �t�m�O���� */
        ed = alloc_struct( STRUCT_EXTRA_DESCR_DATA );

        ed->keyword      = fread_string( fp );
        ed->description  = fread_string( fp );
        ed->next         = obj->extra_descr;
        obj->extra_descr = ed;
        fMatch           = TRUE;
      }

      if ( !str_cmp( word, "End" ) )
      {
        if ( !fNest || !fVnum )
        {
          mudlog( LOG_DEBUG , "Fread_obj: ���~��Ƥ�����." );
          free_string( obj->name        );
          free_string( obj->description );
          free_string( obj->short_descr );

          /* ���񵲺c�O���� */
          free_struct( obj , STRUCT_OBJ_DATA );
          RETURN( TRUE );
        }

        obj->pIndexData->count++;

        /* ���~��� */
        obj->unit = ( obj->pIndexData && obj->pIndexData->unit )
                  ? obj->pIndexData->unit : DefaultUnit;

        switch( type )
        {
        case LOAD_OBJECT:
          if ( iNest == 0 || rgObjNest[iNest] == NULL )
            obj_to_char( obj, ch );
          else
            obj_to_obj( obj, rgObjNest[iNest-1] );
          break;

        case LOAD_DEPOSIT:
          if ( iNest == 0 || rgObjNest[iNest] == NULL )
            obj_to_char_deposit( obj, ch );
          else
            obj_to_obj_dep( obj, rgObjNest[iNest-1] );
          break;

        default:
          break;
        }

        /* �ץ��ƭ� 4.24 */
        switch( obj->item_type )
        {
        case ITEM_WEAPON:
          obj->value[1] = obj->pIndexData->value[1];
          obj->value[2] = obj->pIndexData->value[2];
          break;

        case ITEM_ARMOR:
          obj->value[0] = obj->pIndexData->value[0];
          break;
        }

        /* �p�G�O�������� */
        if ( is_armor( obj ) && obj->max_armor <= 0 )
        {
          obj->max_armor = obj->level * 100;
          obj->armor     = obj->level * 100;
        }

        RETURN( TRUE );
      }
      break;

    case 'I':
      KEY( "ItemType", obj->item_type, fread_number( fp ) );
      break;

    case 'L':
      KEY( "Level", obj->level, fread_number( fp ) );
      break;

    case 'M':
      KEY( "MaxArmor", obj->max_armor, fread_number( fp ) );
      break;

    case 'N':
      KEY( "Name", obj->name, fread_string( fp ) );

      if ( !str_cmp( word, "Nest" ) )
      {
        iNest = fread_number( fp );
        if ( iNest < 0 || iNest >= MAX_NEST )
        {
          mudlog( LOG_DEBUG , "Fread_obj: bad nest %d.", iNest );
        }
        else
        {
          rgObjNest[iNest] = obj;
          fNest            = TRUE;
        }
        fMatch = TRUE;
      }
      break;

    case 'O':

      KEY( "OwnerHigh", obj->owner.high, fread_number( fp ) );
      KEY( "OwnerLow" , obj->owner.low , fread_number( fp ) );

      break;

    case 'S':

      KEY( "SerialHigh", obj->serial.high, fread_number( fp ) );
      KEY( "SerialLow",  obj->serial.low,  fread_number( fp ) );
      KEY( "ShortDescr", obj->short_descr, fread_string( fp ) );

      if ( !str_cmp( word, "Spell" ) )
      {
        SKILL_DATA * pSkill;
        int          iValue;

        iValue = fread_number( fp );

        if ( !( pSkill = skill_isname( fread_word( fp ) ) ) )
        {
          mudlog( LOG_DEBUG , "Fread_obj: �������ޯ�." );
        }

        else if ( iValue < 0 || iValue > 3 )
        {
          mudlog( LOG_DEBUG , "Fread_obj: ���~���ƭ� %d.", iValue );
        }

        else
        {
          obj->value[iValue] = pSkill->slot;
        }

        fMatch = TRUE;
        break;
      }

      break;

    case 'T':
      KEY( "Timer", obj->timer, fread_number( fp ) );
      break;

    case 'V':
      if ( !str_cmp( word, "Values" ) )
      {
        int loop;
        for ( loop = 0; loop < MAX_OBJECT_VALUE; loop ++ )
          obj->value[loop] = fread_number( fp );

        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "Vnum" ) )
      {
        if ( !( obj->pIndexData = get_obj_index( fread_number( fp ) ) ) )
          obj->pIndexData = ObjProtype;

        fVnum  = TRUE;
        fMatch = TRUE;
        break;
      }

      KEY( "Venom", obj->venom, fread_number( fp ) );
      break;

    case 'W':
      KEY( "WearFlags", obj->wear_flags, fread_number( fp ) );
      KEY( "WearLoc",   obj->wear_loc,   fread_number( fp ) );
      KEY( "Weight",    obj->weight,     fread_number( fp ) );
      break;
    }

    if ( !fMatch )
    {
      mudlog( LOG_DEBUG , "Fread_obj: ���~���A�����T." );
      RETURN( FALSE );
    }
  }
}

bool fread_failcode( CHAR_DATA * ch, FILE * pFile )
{
  FAILCODE_DATA * pFailCode;
  char * word;
  bool   fMatch;

  PUSH_FUNCTION( "fread_failcode" );

  for ( ; ; )
  {
    word   = feof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case EOF:
      RETURN( TRUE );

    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) ) RETURN( TRUE );
      break;

    case 'F':

      if ( !str_cmp( word, "FailCode" ) )
      {
        pFailCode = alloc_struct( STRUCT_FAILCODE_DATA );

        pFailCode->address = fread_string( pFile );
        pFailCode->timer   = fread_number( pFile );

        /* �@�wŪ���@�� */
        fread_to_eol( pFile );

        pFailCode->next = ch->failcode;
        ch->failcode    = pFailCode;

        fMatch = TRUE;
        break;
      }

      break;
    }

    if ( !fMatch )
    {
      mudlog( LOG_DEBUG , "fread_failcode: �䤣�쥿�T�����A." );
      RETURN( FALSE );
    }
  }
}

void check_null_object( CHAR_DATA * ch )
{
  OBJ_DATA * obj;
  OBJ_DATA * obj_next;
  bool       found;

  PUSH_FUNCTION( "check_null_object" );

  for ( found = FALSE, obj = ch->carrying; obj; obj = obj_next )
  {
    obj_next = obj->next;
    if ( obj->pIndexData == ObjProtype )
    {
      found = TRUE;

      act( "$1�A�����~$p�䤣����ޡM�ҥH�t�Φ۰ʱN���l���T$0"
        , ch, obj, NULL, TO_CHAR );

      extract_obj( obj );
    }
  }

  if ( found ) send_to_char( "\n\r\n\r" , ch );
  RETURN_NULL();
}

/* �^�s������� */
void save_club( void )
{
  CLUB_DATA * pClub;
  FILE      * pFile;
  bool        bStart = TRUE;
  int         loop;

  PUSH_FUNCTION( "save_club" );

  if ( !( pFile = FOPEN( club_file, "w" ) ) )
  {
    mudlog( LOG_DEBUG , "Save_club: �}�������ɮ� %s ���~.", club_file );
    RETURN_NULL();
  }

  for ( pClub = club_list; pClub; pClub = pClub->next )
  {
    if ( !pClub->master ) continue;

    /* �Y�O���O�Ĥ@�� */
    if ( !bStart ) fprintf( pFile, "\n" );
    bStart = FALSE;

    fprintf( pFile, "#CLUB\n" );

    fprint_string( pFile, "Name"   , pClub->name   );
    fprint_string( pFile, "Cname"  , pClub->cname  );
    fprint_string( pFile, "Master" , pClub->master );

    if ( pClub->vicemaster )
      fprint_string( pFile, "Vicemaster" , pClub->vicemaster );

    fprint_number( pFile, "Timer"  , pClub->timer  );
    fprint_number( pFile, "Status" , pClub->status );
    fprint_number( pFile, "Money"  , pClub->money  );

    for ( loop = 0; loop < MAX_CLUB_DOYEN; loop++ )
    {
      if ( pClub->doyen[loop] )
        fprint_string( pFile, "Doyen" , pClub->doyen[loop] );
    }

    for ( loop = 0; loop < MAX_CLUB_MEMBER; loop++ )
    {
      if ( pClub->member[loop] && pClub->verify[loop] )
        fprint_string( pFile, "Member", pClub->member[loop] );
    }

    for ( loop = 0; loop < MAX_CLUB_MEMBER; loop++ )
    {
      if ( pClub->member[loop] && !pClub->verify[loop] )
        fprint_string( pFile, "Follower", pClub->member[loop] );
    }

    fprintf( pFile, "End\n" );
  }

  FCLOSE( pFile );

  /* �����ɮצs���Ҧ� */
  set_file_mode( club_file );

  RETURN_NULL();
}

void fprint_string( FILE * pFile, char * title, const char * string )
{
  PUSH_FUNCTION( "fprint_string" );
  fprintf( pFile , "%s%s~\n", str_space( title, BLANK_LENGTH ), string );
  RETURN_NULL();
}

void fprint_word( FILE * pFile, char * title, const char * string )
{
  PUSH_FUNCTION( "fprint_word" );
  fprintf( pFile , "%s'%s'\n", str_space( title, BLANK_LENGTH ), string );
  RETURN_NULL();
}

void fprint_number( FILE * pFile, char * title, int number )
{
  PUSH_FUNCTION( "fprint_number" );
  fprintf( pFile, "%s%d\n" , str_space( title, BLANK_LENGTH ), number );
  RETURN_NULL();
}

void set_file_mode( const char * name )
{
  PUSH_FUNCTION( "set_file_mode" );

  /* �Y�O���}�� */
  if ( !SetFileMode ) RETURN_NULL();

  if ( !name || !*name )
  {
    mudlog( LOG_DEBUG, "set_file_mode: �ӷ������T." );
    RETURN_NULL();
  }

  if ( chmod( name, FileMode ) != 0 )
  {
    mudlog( LOG_DEBUG, "set_file_mode: �]�w�ɮ� %s �Ҧ����~.", name );
    RETURN_NULL();
  }

  RETURN_NULL();
}

FUNCTION( do_filestat )
{
  PUSH_FUNCTION( "do_filestat" );

  if ( !SetFileMode )
  {
    send_to_char( "�ثe�t�Χ��Ҧ����}�ҡT\n\r", ch );
    RETURN_NULL();
  }

  print_to_char( ch,
    "�ثe%s���ɮצs�J�Ҧ��O�R\n\r"
    "�ϥΪ� �iŪ�R%s �i�g�R%s �i����R%s\n\r"
    "�P�ڸs �iŪ�R%s �i�g�R%s �i����R%s\n\r"
    "��L�� �iŪ�R%s �i�g�R%s �i����R%s\n\r"
    , mud_name
    , YESNO( FileMode & S_IRUSR )
    , YESNO( FileMode & S_IWUSR )
    , YESNO( FileMode & S_IXUSR )
    , YESNO( FileMode & S_IRGRP )
    , YESNO( FileMode & S_IWGRP )
    , YESNO( FileMode & S_IXGRP )
    , YESNO( FileMode & S_IROTH )
    , YESNO( FileMode & S_IWOTH )
    , YESNO( FileMode & S_IXOTH ) );

  RETURN_NULL();
}

void char_filesize( CHAR_DATA * ch )
{
  struct stat sData;
  char        strsave[MAX_FILE_LENGTH];

  PUSH_FUNCTION( "char_filesize" );

  if ( IS_NPC( ch ) ) RETURN_NULL();

  str_cpy( strsave, file_name( ch->name , SAVE_FILE ) );

  if ( stat( strsave, &sData ) != 0 )
  {
    mudlog( LOG_DEBUG, "char_filesize: Ū���ɮ� %s ���~.", strsave );
    RETURN_NULL();
  }

  ch->file_size = sData.st_size;
  RETURN_NULL();
}

bool excess_filequota( CHAR_DATA * ch )
{
  PUSH_FUNCTION( "excess_filequota" );

  if ( !ch )
  {
    mudlog( LOG_DEBUG, "excess_filequota: �ӷ������T." );
    RETURN( TRUE );
  }

  if ( IS_NPC( ch ) )               RETURN( FALSE );
  if ( ch->file_size > file_quota ) RETURN( TRUE );

  RETURN( FALSE );
}

void autosave_update( void )
{
  DESCRIPTOR_DATA * man;
  CHAR_DATA       * ch;

  PUSH_FUNCTION( "autosave_update" );

  for ( man = descriptor_list; man; man = man->next )
  {
    if ( verify_desc( man )
      && man->connected == CON_PLAYING
      && ( ch = man->character ) )
    {
      if ( ch->autosave_tick > 0 && --ch->autosave_tick <= 0 )
      {
        do_save( ch, "" );
        ch->autosave_tick = ch->autosave;
      }

      if ( ch->autobackup_tick > 0 && --ch->autobackup_tick <= 0 )
      {
        do_backup( ch, "" );
        ch->autobackup_tick = ch->autobackup;
      }
    }
  }

  RETURN_NULL();
}

void save_basic_file( CHAR_DATA * ch )
{
  char   strsave[MAX_FILE_LENGTH];
  FILE * pFile;

  PUSH_FUNCTION( "save_basic_file" );

  if ( !ch )
  {
    mudlog( LOG_DEBUG, "save_basic_file: �ӷ������T." );
    RETURN_NULL();
  }

  if ( IS_NPC( ch ) ) RETURN_NULL();

  str_cpy( strsave, file_name( ch->name , BASIC_FILE ) );

  if ( !( pFile = fopen( strsave, "w" ) ) )
  {
    mudlog( LOG_DEBUG , "Save_basic_obj: �}���ɮ� %s ���~.", ch->name );
  }

  else
  {
    fprintf( pFile, "Name            %s\n", ch->name  );
    fprintf( pFile, "Cname           %s\n", ch->cname );
    fprintf( pFile, "Email           %s\n", ch->email );
    fprintf( pFile, "LastHost        %s\n"
      , ( ch->desc ) ? ch->desc->host : "�����`�_�u" );

    fprintf( pFile, "Level           %d\n", ch->level );
    fprintf( pFile, "Sex             %d\n", ch->sex   );
    fprintf( pFile, "Played          %d\n"
      , (int) ( ch->played ) + ( (int) current_time - (int) ch->logon) );

    fclose( pFile );
  }

  RETURN_NULL();
}

void player_log( CHAR_DATA * ch, const char * string )
{
  char   strsave[MAX_FILE_LENGTH];
  FILE * pFile;

  PUSH_FUNCTION( "player_log" );

  if ( !ch || !string )
  {
    mudlog( LOG_DEBUG, "player_log: �ӷ������T." );
    RETURN_NULL();
  }

  if ( IS_NPC( ch ) || !*string ) RETURN_NULL();

  str_cpy( strsave, file_name( ch->name , LOG_FILE ) );

  if ( ( pFile = fopen( strsave, "a" ) ) )
  {
    fprintf( pFile ,"(%s) %s\n"
      , time_format( time( NULL ) , "%r, %a-%d-%b-%y" ), string );

    fclose( pFile );
  }

  RETURN_NULL();
}
