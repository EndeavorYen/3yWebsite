/***************************************************************************
 *  Original Diku Mud copyright (C) 1990, 1991 by Sebastian Hammer,        *
 *  Michael Seifert, Hans Henrik St{rfeldt, Tom Madsen, and Katja Nyboe.   *
 *                                                                         *
 *  Merc Diku Mud improvments copyright (C) 1992, 1993 by Michael          *
 *  Chastain, Michael Quan, and Mitchell Tse.                              *
 *                                                                         *
 *  In order to use any part of this Merc Diku Mud, you must comply with   *
 *  both the original Diku license in 'license.doc' as well the Merc       *
 *  license in 'license.txt'.  In particular, you may not remove either of *
 *  these copyright notices.                                               *
 *                                                                         *
 *  Much time and thought has gone into this software and you are          *
 *  benefitting.  We hope that you share your changes too.  What goes      *
 *  around, comes around.                                                  *
 ***************************************************************************/

/***************************************************************************
*  �o�O�ѻ��j�ƾǨt�s�@�s�Ҽ��g���C���M�D��� merc ��s�ӨӡM�Ҧ������v    *
*  �N�|�Q�O�d�M���w��j�a�ק�M���ڭ̤]�Ʊ�A�̤]�ണ�ѵ��j�a�M�Ҧ�����    *
*  �~�欰�N���Q���\�C                                                      *
*                                                                          *
*  paul@mud.ch.fju.edu.tw                                                  *
*  lc@mud.ch.fju.edu.tw                                                    *
*                                                                          *
***************************************************************************/

#include <sys/types.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <glob.h>
#include "merc.h"

#if defined(KEY)
#undef KEY
#endif

/* �~���ܼ� */
extern bool               fBootDb;
extern SYMBOL_DATA *      symbol_hash[26][20];

/* �~����� */
extern void    mprog_read_programs     args( ( FILE * , MOB_INDEX_DATA * ) );
extern void    set_exit_default        args( ( EXIT_DATA * ) );
extern int     glob_file        args( ( const char *, const char *, glob_t * ) );

/* �ϰ��� */
void set_area_default     args( ( AREA_DATA       * ) );
void set_room_default     args( ( ROOM_INDEX_DATA * ) );
void set_exit_default     args( ( EXIT_DATA       * ) );
void set_shop_default     args( ( SHOP_DATA       * ) );
void set_mineral_default  args( ( MINERAL_DATA    * ) );
void set_object_default   args( ( OBJ_INDEX_DATA  * ) );
void set_obj_affect_default args( ( AFFECT_DATA   * ) );
void set_mobile_default   args( ( MOB_INDEX_DATA  * ) );
void set_teach_default    args( ( TEACH_DATA      * ) );
void set_skill_default    args( ( SKILL_DATA      * ) );
void set_damage_default   args( ( DAMAGE_DATA     * ) );
void set_command_default  args( ( CMD_DATA        * ) );
void set_sector_default   args( ( SECTOR_DATA     * ) );
void set_class_default    args( ( CLASS_DATA      * ) );
void set_liq_default      args( ( LIQ_DATA        * ) );
void set_bus_default      args( ( BUS_DATA        * ) );
void set_job_default      args( ( JOB_DATA        * ) );
void set_enquire_default  args( ( ENQUIRE_DATA    * ) );
void set_station_default  args( ( NET_DATA        * ) );
void set_club_default     args( ( CLUB_DATA       * ) );
void load_mob_teach       args( ( MOB_INDEX_DATA  * , FILE * ) );
void load_exit            args( ( ROOM_INDEX_DATA * , FILE * ) );
void load_room_key        args( ( ROOM_INDEX_DATA * , FILE * ) );
AFFECT_DATA * load_obj_affect      args( ( FILE * ) );
void load_obj_extra       args( ( OBJ_INDEX_DATA  * , FILE * ) );
void load_station         args( ( NET_DATA        * , FILE * ) );
void load_a_club          args( ( CLUB_DATA       * , FILE * ) );
void load_a_quest         args( ( QUEST_INFO      * , FILE * ) );
void load_a_question      args( ( QUESTION_DATA   * , FILE * ) );
void load_a_event         args( ( EVENT_DATA      * , FILE * ) );
void load_a_gift          args( ( GIFT_DATA       * , FILE * ) );
void load_a_bounty        args( ( BOUNTY_DATA     * , FILE * ) );
void load_a_immlist       args( ( IMMLIST_DATA    * , FILE * ) );
void load_a_sale          args( ( SALE_DATA       * , FILE * ) );
void load_a_ship          args( ( SHIP_DATA       * , FILE * ) );
void load_a_vote          args( ( VOTE_DATA       * , FILE * ) );
void load_a_joke          args( ( JOKE_DATA       * , FILE * ) );
void load_damage          args( ( SKILL_DATA      * , FILE * ) );
void set_restrict_default args( ( RESTRICT_DATA * ) );
void set_quest_default    args( ( QUEST_INFO    * ) );
void set_question_default args( ( QUESTION_DATA * ) );
void set_event_default    args( ( EVENT_DATA    * ) );
void set_gift_default     args( ( GIFT_DATA     * ) );
void set_bounty_default   args( ( BOUNTY_DATA   * ) );
void set_immlist_default  args( ( IMMLIST_DATA  * ) );
void set_sale_default     args( ( SALE_DATA     * ) );
void set_ship_default     args( ( SHIP_DATA     * ) );
void set_effect_default   args( ( EFFECT_DATA   * ) );
void set_message_default  args( ( MESSAGE_DATA  * ) );
void set_angel_default    args( ( ANGEL_DATA    * ) );
void set_joke_default     args( ( JOKE_DATA     * ) );
void set_server_default   args( ( SERVER_DATA  * ) );

RESTRICT_DATA * load_restrict args( ( FILE * ) );
MESSAGE_DATA  * load_message  args( ( FILE * ) );
JOB_DATA      * load_job      args( ( FILE * ) );
ENQUIRE_DATA  * load_enquire  args( ( FILE * ) );
ANGEL_DATA    * load_a_angel  args( ( FILE * ) );

#define KEY( literal, field, value ) \
  if ( !str_cmp( word, literal ) )   \
  {                                  \
    field  = value;                  \
    fMatch = TRUE;                   \
    break;                           \
  }

/* �]�w�ϰ��ɤ����ϰ쪺�w�]�� */
void set_area_default( AREA_DATA * pArea )
{
  PUSH_FUNCTION( "set_area_default" );
  pArea->reset_first = NULL;
  pArea->reset_last  = NULL;
  pArea->list        = NULL;
  pArea->attribute   = 1;
  pArea->name        = NULL;
  pArea->editor      = NULL;
  pArea->description = NULL;
  pArea->filename    = NULL;
  pArea->mineral     = NULL;
  pArea->age         = 15;
  pArea->serial      = ERRORCODE;
  pArea->upper       = ERRORCODE;
  pArea->lower       = ERRORCODE;
  pArea->foggy       = ERRORCODE;
  pArea->nplayer     = 0;
  pArea->room        = 0;
  pArea->obj         = 0;
  pArea->mob         = 0;
  pArea->shop        = 0;
  pArea->reset       = 0;
  pArea->flag        = 0;
  pArea->mine        = 0;
  pArea->capital_no  = 0;
  pArea->capital     = NULL;
  RETURN_NULL();
}

/* �]�w�ϰ��ɤ����Ǫ����w�]�� */
void set_mobile_default( MOB_INDEX_DATA * pMobIndex )
{
  int loop;

  PUSH_FUNCTION( "set_mobile_default" );

  pMobIndex->player_name       = NULL;
  pMobIndex->short_descr       = NULL;
  pMobIndex->long_descr        = NULL;
  pMobIndex->description       = NULL;
  pMobIndex->filename          = NULL;
  pMobIndex->deadmsg           = NULL;
  pMobIndex->auction           = NULL;
  pMobIndex->enable            = NULL;
  pMobIndex->job               = NULL;
  pMobIndex->area              = NULL;
  pMobIndex->vnum              = ERRORCODE;
  pMobIndex->act               = ACT_IS_NPC;
  pMobIndex->affected_by       = 0;
  pMobIndex->pShop             = NULL;
  pMobIndex->alignment         = 0;
  pMobIndex->level             = 1;
  pMobIndex->hitroll           = 0;
  pMobIndex->ac                = 0;
  pMobIndex->damroll           = 0;
  pMobIndex->reborn_vnum       = 0;
  pMobIndex->reborn_room       = 0;
  pMobIndex->migrate           = 0;
  pMobIndex->now_str           = DefaultStr;
  pMobIndex->now_int           = DefaultInt;
  pMobIndex->now_wis           = DefaultWis;
  pMobIndex->now_dex           = DefaultDex;
  pMobIndex->now_con           = DefaultCon;
  pMobIndex->hit               = 0;
  pMobIndex->mana              = 0;
  pMobIndex->move              = 0;
  pMobIndex->class             = class_demos;
  pMobIndex->country_alignment = 0;
  pMobIndex->gold              = 0;
  pMobIndex->sex               = 0;
  pMobIndex->tractable         = -1;
  pMobIndex->multipile         = 100;
  pMobIndex->fight_flags       = 0;
  pMobIndex->hitnodice         = 100;
  pMobIndex->hitsizedice       = 100;
  pMobIndex->hitplus           = 100;
  pMobIndex->damnodice         = 100;
  pMobIndex->damsizedice       = 100;
  pMobIndex->damplus           = 100;
  pMobIndex->attack_ratio      = 100;
  pMobIndex->dodge_ratio       = 100;
  pMobIndex->speak             = TRUE;

  for ( loop = 0; loop < MAX_SKILL; loop++ ) pMobIndex->skill[loop] = 0;
  RETURN_NULL();
}

/* �]�w�ϰ��ɤ����Ǫ��оɪ��w�]�� */
void set_teach_default( TEACH_DATA * teach )
{
  PUSH_FUNCTION( "set_teach_default" );
  teach->slot      = ERRORCODE;
  teach->cost      =  0;
  teach->adept     = 20;
  teach->inventory =  0;
  RETURN_NULL();
}

/* �]�w�ϰ��ɤ����ж����w�]�� */
void set_room_default( ROOM_INDEX_DATA * pRoomIndex )
{
  PUSH_FUNCTION( "set_room_default" );
  pRoomIndex->people       = NULL;
  pRoomIndex->next_in_area = NULL;
  pRoomIndex->contents     = NULL;
  pRoomIndex->extra_descr  = NULL;
  pRoomIndex->job          = NULL;
  pRoomIndex->club         = NULL;
  pRoomIndex->board        = NULL;
  pRoomIndex->mine         = NULL;
  pRoomIndex->enquire      = NULL;
  pRoomIndex->vnum         = ERRORCODE;
  pRoomIndex->name         = NULL;
  pRoomIndex->description  = NULL;
  pRoomIndex->filename     = NULL;
  pRoomIndex->room_flags   = ROOM_INDOORS;
  pRoomIndex->sector       = NULL;
  pRoomIndex->light        = 0;
  RETURN_NULL();
}

/* �Ʃw�ж��X�f���w�]�� */
void set_exit_default( EXIT_DATA * pExit )
{
  PUSH_FUNCTION( "set_exit_default" );
  pExit->description = NULL;
  pExit->keyword     = NULL;
  pExit->message     = NULL;
  pExit->exit_info   =  0;
  pExit->key         =  0;
  pExit->foggy       = FALSE;
  pExit->vnum        = ERRORCODE;
  RETURN_NULL();
}

/* �]�w���~���w�]�� */
void set_object_default( OBJ_INDEX_DATA * pObjIndex )
{
  int loop;

  PUSH_FUNCTION( "set_obj_default" );
  pObjIndex->vnum        = ERRORCODE;
  pObjIndex->item_type   = ERRORCODE;
  pObjIndex->wear_flags  = ERRORCODE;
  pObjIndex->level       = 1;
  pObjIndex->weight      = 1;
  pObjIndex->cost        = ERRORCODE;
  pObjIndex->armor       = ERRORCODE;
  pObjIndex->name        = NULL;
  pObjIndex->short_descr = NULL;
  pObjIndex->long_descr  = NULL;
  pObjIndex->description = NULL;
  pObjIndex->wearmsg     = NULL;
  pObjIndex->remmsg      = NULL;
  pObjIndex->filename    = NULL;
  pObjIndex->unit        = NULL;
  pObjIndex->job         = NULL;
  pObjIndex->restrict    = NULL;
  pObjIndex->message     = NULL;
  pObjIndex->affected    = NULL;
  pObjIndex->impact      = NULL;
  pObjIndex->disappear   = FALSE;
  pObjIndex->exp         = 0;

  for ( loop = 0; loop < MAX_OBJECT_VALUE; loop++ )
    pObjIndex->value[ loop ] = 0;

  RETURN_NULL();
}

/* �]�w���~�ݩʪ��w�]�� */
void set_obj_affect_default( AFFECT_DATA * paf )
{
  PUSH_FUNCTION( "set_obj_affect_default" );
  paf->type        = ERRORCODE;
  paf->duration    = ERRORCODE;
  paf->location    = ERRORCODE;
  paf->modifier    = 0;
  paf->bitvector   = 0;
  RETURN_NULL();
}

/* �]�w�ө����w�w�� */
void set_shop_default( SHOP_DATA * pShop )
{
  int Trade;

  PUSH_FUNCTION( "set_shop_default" );

  pShop->keeper      = ERRORCODE;
  pShop->type        = ERRORCODE;
  pShop->filename    = NULL;
  pShop->sential     = NULL;
  pShop->profit_buy  = 100;
  pShop->profit_sell = 100;
  pShop->open_hour   =   0;
  pShop->close_hour  =  23;

  for ( Trade = 0; Trade < MAX_TRADE; Trade++ ) pShop->buy_type[Trade] = 0;
  RETURN_NULL();
}

void set_mineral_default( MINERAL_DATA * pMineral )
{
  PUSH_FUNCTION( "set_mineral_default" );

  pMineral->mineral = NULL;
  pMineral->message = NULL;
  pMineral->count   = ERRORCODE;
  pMineral->flags   = 0;
  RETURN_NULL();
}

void set_skill_default( SKILL_DATA * pSkill )
{
  PUSH_FUNCTION( "set_skill_default" );
  pSkill->position        = POS_FIGHTING;
  pSkill->name            = NULL;
  pSkill->cname           = NULL;
  pSkill->msg_off         = NULL;
  pSkill->help            = NULL;
  pSkill->message         = NULL;
  pSkill->limit           = NULL;
  pSkill->check           = NULL;
  pSkill->damage          = NULL;
  pSkill->restrict        = NULL;
  pSkill->function        = NULL;
  pSkill->type            = TAR_IGNORE;
  pSkill->cost_type       = COST_MANA;
  pSkill->cost            = 0;
  pSkill->wait            = 0;
  pSkill->exp             = 0;
  pSkill->associate       = ERRORCODE;
  pSkill->degree          = 1;
  pSkill->chance          = 0;
  pSkill->affect          = 0;
  pSkill->affect_id       = 0;
  pSkill->rating          = ERRORCODE;
  pSkill->antirating      = ERRORCODE;
  pSkill->choosen         = 0;
  pSkill->adeptation      = 0;
  pSkill->weapon          = ERRORCODE;
  pSkill->slot            = ERRORCODE;
  pSkill->enable          = FALSE;
  pSkill->say_spell       = FALSE;
  pSkill->teach           = FALSE;
  pSkill->concentration   = FALSE;
  pSkill->cast            = TRUE;
  pSkill->innate          = FALSE;
  pSkill->canask          = FALSE;
  pSkill->valid           = TRUE;
  pSkill->ply             = 0;
  pSkill->qutoient        = 1;
  RETURN_NULL();
}

void set_damage_default( DAMAGE_DATA * pDamage )
{
  PUSH_FUNCTION( "set_damage_default" );

  pDamage->description = NULL;
  pDamage->innate      = NULL;
  pDamage->routine     = NULL;
  pDamage->effect      = NULL;
  pDamage->chance      = ERRORCODE;
  pDamage->value       = ERRORCODE;
  pDamage->vicevalue   = 0;
  pDamage->situs       = ATTACK_RANDOM;
  pDamage->obj_vnum    = ERRORCODE;
  pDamage->parry       = 0;
  pDamage->multiple    = 0;
  RETURN_NULL();
}

void set_command_default( CMD_DATA * pCommand )
{
  PUSH_FUNCTION( "set_command_default" );
  pCommand->name     = NULL;
  pCommand->cname    = NULL;
  pCommand->help     = NULL;
  pCommand->function = NULL;
  pCommand->position = POS_STANDING;
  pCommand->level    = 0;
  pCommand->exec     = 0;
  pCommand->log      = LOG_NORMAL;
  pCommand->lock     = FALSE;
  pCommand->canlock  = TRUE;
  pCommand->mobonly  = FALSE;
  pCommand->chat     = FALSE;
  pCommand->wizlog   = FALSE;
  pCommand->jail     = FALSE;
  pCommand->dead     = FALSE;
  pCommand->order    = FALSE;
  pCommand->lost     = FALSE;
  pCommand->limit    = FALSE;
  RETURN_NULL();
}

void set_sector_default( SECTOR_DATA * pSector )
{
  PUSH_FUNCTION( "set_sector_default" );

  pSector->vnum     = ERRORCODE;
  pSector->movement = ERRORCODE;
  pSector->flags    = 0;
  pSector->cname    = NULL;
  pSector->dark     = TRUE;
  RETURN_NULL();
}

void set_class_default( CLASS_DATA * pClass )
{
  int loop;

  PUSH_FUNCTION( "set_class_default" );

  pClass->name         = NULL;
  pClass->cname        = NULL;
  pClass->title        = NULL;
  pClass->msg_limit    = NULL;
  pClass->vnum         = ERRORCODE;
  pClass->low_rebirth  = 0;
  pClass->high_rebirth = 0;
  pClass->rebirth_gold = 0;
  pClass->warn         = 0;
  pClass->associate    = ERRORCODE;
  pClass->limit        = -1;
  pClass->nskill       = ERRORCODE;
  pClass->multiplier   = 2;
  pClass->fMana        = FALSE;
  pClass->rudiment     = FALSE;
  pClass->force        = FALSE;
  pClass->innate       = FALSE;
  pClass->select       = FALSE;

  for ( loop = 0; loop < MAX_ATTR; loop++ )
  {
    pClass->max_default[loop] = 0;
    pClass->min_default[loop] = 0;
    pClass->hero[loop]        = 0;
    pClass->attr[loop]        = 0;
    pClass->factor[loop]      = 0;
  }

  for ( loop = 0; loop < MAX_LEVEL; loop++ )
    pClass->rank[loop] = NULL;

  RETURN_NULL();
}

void set_liq_default( LIQ_DATA * pLiq )
{
  PUSH_FUNCTION( "set_liq_default" );

  pLiq->name   = NULL;
  pLiq->color  = NULL;
  pLiq->slot   = ERRORCODE;
  pLiq->full   = 0;
  pLiq->thirst = 0;
  pLiq->drunk  = 0;
  pLiq->water  = FALSE;
  RETURN_NULL();
}

/* �]�w�a�K��ƪ��w�]�� */
void set_bus_default( BUS_DATA * pBus )
{
  PUSH_FUNCTION( "set_bus_default" );

  pBus->next      = NULL;
  pBus->station   = NULL;
  pBus->platform  = NULL;
  pBus->loge      = NULL;
  pBus->name      = NULL;
  pBus->cost      = 100;
  pBus->count     = 0;
  RETURN_NULL();
}

void set_job_default( JOB_DATA * pJob )
{
  PUSH_FUNCTION( "set_job_default" );

  pJob->keyword  = NULL;
  pJob->function = NULL;
  pJob->position = ERRORCODE;

  RETURN_NULL();
}

void set_enquire_default( ENQUIRE_DATA * pEnquire )
{
  PUSH_FUNCTION( "set_enquire_default" );

  pEnquire->keyword = NULL;

  RETURN_NULL();
}
/* �]�w���ڳs�u���w�]�� */
void set_station_default( NET_DATA * pNet )
{
  PUSH_FUNCTION( "set_station_default" );

  pNet->name            = NULL;
  pNet->cname           = NULL;
  pNet->address         = NULL;
  pNet->port            = -1;
  pNet->import          = -1;
  pNet->export          = -1;
  pNet->nRead           = 0;
  pNet->nWrite          = 0;
  pNet->timer           = 0;
  pNet->import_duration = 0;
  pNet->export_duration = 0;
  pNet->log             = FALSE;
  pNet->valid           = TRUE;
  pNet->message[0]      = '\x0';
  RETURN_NULL();
}

/* �M����������� */
void set_club_default( CLUB_DATA * pClub )
{
  int loop;
  int loop_2;

  PUSH_FUNCTION( "set_club_default" )

  pClub->name        = NULL;
  pClub->cname       = NULL;
  pClub->master      = NULL;
  pClub->vicemaster  = NULL;
  pClub->location    = NULL;
  pClub->timer       = -1;
  pClub->money       = 0;
  pClub->status      = CLUB_STATUS_UNKNOW;

  /* �M����������� */
  for ( loop = 0; loop < MAX_CLUB_MEMBER; loop++ )
  {
    pClub->verify[loop] = MEMBER_NO_VERIFY;
    pClub->member[loop] = NULL;
  }

  /* �M�����Ѫ���� */
  for ( loop = 0; loop < MAX_CLUB_DOYEN; loop++ )
    pClub->doyen[loop] = NULL;

  /* �M�����w����� */
  for ( loop = 0; loop < MAX_LEVEL; loop++ )
  {
    for ( loop_2 = 0; loop_2 < MAX_STAFF; loop_2++ )
    {
      pClub->staff[loop][loop_2] = NULL;
    }
  }

  RETURN_NULL();
}

/* �]�w���~����c��� */
void set_restrict_default( RESTRICT_DATA * pRestrict )
{
  PUSH_FUNCTION( "set_restrict_default" );

  if ( pRestrict )
  {
    pRestrict->occasion  = OCCASION_NONE;
    pRestrict->type      = ERRORCODE;
    pRestrict->value     = ERRORCODE;
    pRestrict->vicevalue = 0;
  }

  else mudlog( LOG_DEBUG, "set_restrict_default: �ǤJ���c���s�b." );

  RETURN_NULL();
}

void set_quest_default( QUEST_INFO * pQuest )
{
  PUSH_FUNCTION( "Set_qeuest_default" );

  pQuest->mark = NULL;
  pQuest->info = NULL;
  pQuest->help = str_dup( "" );
  pQuest->show = FALSE;

  RETURN_NULL();
}

void set_question_default( QUESTION_DATA * pQuestion )
{
  int loop;

  PUSH_FUNCTION( "set_question_default" );

  pQuestion->title = NULL;
  pQuestion->count = 0;
  pQuestion->fail  = 0;

  for ( loop = 0; loop < MAX_QUESTION; loop++ )
  {
    pQuestion->question[loop] = NULL;
    pQuestion->answer[loop]   = FALSE;
  }

  RETURN_NULL();
}
void set_event_default( EVENT_DATA * pEvent )
{
  PUSH_FUNCTION( "set_event_default" );

  pEvent->title    = NULL;
  pEvent->chance   = ERRORCODE;
  pEvent->count    = 0;
  pEvent->lock     = FALSE;
  pEvent->function = NULL;
  pEvent->keyword  = NULL;
  RETURN_NULL();
}

void set_gift_default( GIFT_DATA * pGift )
{
  PUSH_FUNCTION( "set_gift_default" );

  if ( pGift )
  {
    pGift->gift     = NULL;
    pGift->title    = NULL;
    pGift->message  = NULL;
    pGift->month    = ERRORCODE;
    pGift->day      = ERRORCODE;
    pGift->high     = ERRORCODE;
    pGift->low      = ERRORCODE;
    pGift->sender   = ERRORCODE;
    pGift->count    = 0;
    pGift->gold     = 0;
    pGift->stamp    = ERRORCODE;
    pGift->duration = ERRORCODE;
    pGift->tick     = ERRORCODE;
    pGift->days     = ERRORCODE;
    pGift->send     = FALSE;
    pGift->starting = 0;
    pGift->ending   = 0;
  }

  RETURN_NULL();
}

void set_bounty_default( BOUNTY_DATA * pBounty )
{
  PUSH_FUNCTION( "set_bounty_default" );

  pBounty->mob       = NULL;
  pBounty->msg       = NULL;
  pBounty->chance    = ERRORCODE;
  pBounty->max       = ERRORCODE;
  pBounty->type      = ERRORCODE;
  pBounty->migration = ERRORCODE;
  pBounty->room      = ERRORCODE;
  pBounty->value     = 0;
  pBounty->occurred  = 0;
  pBounty->killed    = 0;
  pBounty->count     = 0;
  pBounty->lock      = FALSE;
  RETURN_NULL();
}

void set_immlist_default( IMMLIST_DATA * pImmlist )
{
  PUSH_FUNCTION( "set_immlist_default" );
  pImmlist->name        = NULL;
  pImmlist->description = str_dup( "" );
  pImmlist->level       = ERRORCODE;
  pImmlist->trust       = ERRORCODE;
  pImmlist->adviser     = ERRORCODE;
  RETURN_NULL();
}

void set_sale_default( SALE_DATA * pSale )
{
  PUSH_FUNCTION( "set_sale_default" );
  pSale->obj     = NULL;
  pSale->visible = TRUE;
  pSale->cost    = ERRORCODE;
  pSale->times   = 0;
  pSale->gold    = 0;
  pSale->sold    = 0;
  RETURN_NULL();
}

void set_ship_default( SHIP_DATA * pShip )
{
  PUSH_FUNCTION( "set_ship_default" );
  pShip->name         = NULL;
  pShip->msg_land     = NULL;
  pShip->msg_entrance = NULL;
  pShip->description  = NULL;
  pShip->starting     = NULL;
  pShip->destination  = NULL;
  pShip->cabin        = NULL;
  pShip->cost         = ERRORCODE;
  pShip->sailing      = ERRORCODE;
  pShip->waiting      = ERRORCODE;
  pShip->sailing_tick = ERRORCODE;
  pShip->waiting_tick = ERRORCODE;
  pShip->count        = 0;
  pShip->pirate       = 0;
  pShip->pirate_count = 0;
  pShip->delay        = 0;
  pShip->lock         = FALSE;
  RETURN_NULL();
}

void set_effect_default( EFFECT_DATA * pEffect )
{
  int loop;

  PUSH_FUNCTION( "set_effect_default" );

  pEffect->next      = NULL;
  pEffect->type      = EFFECT_NONE;

  for ( loop = 0; loop < MAX_EFFECT_VALUE; loop++ ) pEffect->value[loop] = 0;
  RETURN_NULL();
}

void set_message_default( MESSAGE_DATA * pMessage )
{
  PUSH_FUNCTION( "set_message_default" );

  pMessage->type   = ERRORCODE;
  pMessage->self   = NULL;
  pMessage->others = NULL;

  RETURN_NULL();
}

void set_angel_default( ANGEL_DATA * pAngel )
{
  PUSH_FUNCTION( "set_angel_default" );

  pAngel->lower       = 0;
  pAngel->higher      = ANGEL_LEVEL;
  pAngel->position    = POS_STANDING;
  pAngel->description = NULL;
  pAngel->function    = NULL;
  RETURN_NULL();
}

void set_vote_default( VOTE_DATA * pVote )
{
  int loop;

  PUSH_FUNCTION( "set_vote_default" );

  if ( !pVote )
  {
    mudlog( LOG_DEBUG, "set_vote_default: �ʥF�ӷ�." );
    RETURN_NULL();
  }

  pVote->next    = NULL;
  pVote->poster  = str_dup( "" );
  pVote->subject = str_dup( "" );
  pVote->text    = str_dup( "" );
  pVote->date    = str_dup( "" );
  pVote->club    = str_dup( "" );
  pVote->days    = VOTE_DAYS;
  pVote->stamp   = 0;
  pVote->lock    = FALSE;
  pVote->level   = VOTE_LEVEL;
  pVote->moninal = TRUE;

  for ( loop = 0; loop < MAX_VOTES; loop++ )
  {
    pVote->poll[loop]    = 0;
    pVote->message[loop] = str_dup( "" );
  }

  for ( loop = 0; loop < MAX_POLL; loop++ )
  {
    pVote->poller[loop] = str_dup( "" );
    pVote->vote[loop]   = -1;
  }

  RETURN_NULL();
}

void set_joke_default( JOKE_DATA * pJoke )
{
  PUSH_FUNCTION( "set_joke_default" );

  pJoke->next  = NULL;
  pJoke->stamp = ERRORCODE;
  pJoke->title = NULL;
  pJoke->org   = NULL;
  pJoke->text  = NULL;

  RETURN_NULL();
}

void set_server_default( SERVER_DATA * pServer )
{
  PUSH_FUNCTION( "set_server_default" );

  pServer->address = NULL;
  RETURN_NULL();
}

/* ���J�s�榡���ϰ��ɪ��ϰ�榡 */
AREA_DATA * load_area( char * filename )
{
  AREA_DATA * pArea;
  AREA_DATA * zArea;
  FILE      * pFile;
  char      * word;
  bool        fMatch;

  PUSH_FUNCTION( "load_area" );

  if ( !( pFile = FOPEN( filename , "r" ) ) ) RETURN( NULL );

  /* �t�m�O����H�γ]�w�w�]�� */
  set_area_default( pArea = alloc_struct( STRUCT_AREA_DATA ) );

  /* ���J�ϰ쪺�D�{������ */
  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    /* ���� */
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'C':
      KEY( "Capital", pArea->capital_no, fread_number( pFile ) );
      break;

    case 'D':

      if ( !str_cmp( word, "Description" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pArea->description = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "Default" ) )
      {
        if ( fread_number( pFile ) )
        {
          if ( DefaultArea ) mudlog( LOG_ERR , "Load_area: �w�]�ϰ쭫��." );
          DefaultArea = pArea;
        }

        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        /* �ˬd�O�_�����~ */
        if ( !pArea->name )
          mudlog( LOG_ERR , "Load_area: �ɮ� %s �ʥF�ϰ�W�r." , filename );

        if ( !pArea->editor )
          mudlog( LOG_ERR , "Load_area: �ɮ� %s �ʥF�ϰ켶�g��." , filename );

        if ( IS_ERROR( pArea->serial ) )
          mudlog( LOG_ERR, "load_area: �ϰ� %s �ʥF�Ǹ�.", pArea->name );

        if ( !pArea->description ) pArea->description = str_dup( "" );

        if ( !area_first ) area_first      = pArea;
        if (  area_last  ) area_last->next = pArea;

        area_last   = pArea;
        pArea->next = NULL;
        top_area++;

        FCLOSE( pFile );
        RETURN( pArea );
      }

      KEY( "Echo",   pArea->attribute , fread_number( pFile ) );
      KEY( "Editor", pArea->editor    , fread_string( pFile ) );
      break;

    case 'F':
      KEY( "Flags", pArea->flag , fread_number( pFile ) );
      KEY( "Fog",   pArea->foggy, fread_number( pFile ) );
      break;

    case 'L':

      KEY( "Lower",   pArea->lower , fread_number( pFile ) );
      break;

    case 'N':

      KEY( "Name",   pArea->name , fread_string( pFile ) );
      break;

    case 'S':
      if ( !str_cmp( word, "Serial" ) )
      {
        int serial;

        serial = fread_number( pFile );

        for ( zArea = area_first; zArea; zArea = zArea->next )
        {
          if ( zArea->serial == serial )
             mudlog( LOG_ERR, "�ϰ�Ǹ� %d ����.", serial );
        }

        pArea->serial = serial;
        fMatch = TRUE;
        break;
      }
      break;

    case 'U':

      KEY( "Upper",   pArea->upper , fread_number( pFile ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_Area �ɮשR�O %s ���~." , word );
  }
  RETURN( NULL );
}

/* ���J�s�榡���ϰ��ɪ��Ǫ��榡 */
void load_mobiles( char * filename , AREA_DATA * pArea )
{
  MOB_INDEX_DATA * pMobIndex;
  FILE           * pFile;
  char           * word;
  bool             fMatch;

  PUSH_FUNCTION( "load_mobiles" );

  if ( !( pFile = FOPEN( filename , "r" ) ) )
  {
    mudlog( LOG_FAILLOAD , "���J�Ǫ��ɮ� %s ����.\n" , filename );
    RETURN_NULL();
  }

  /* �w�]�@�Ǽƭ� */
  pMobIndex = alloc_struct( STRUCT_MOB_INDEX_DATA );
  set_mobile_default( pMobIndex );

  for ( ;; )
  {
    int vnum = ERRORCODE;
    int iHash;

    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    /* ���� */
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case '#':

      if ( !str_cmp( word, "#Job" ) )
      {
        JOB_DATA * pJob;

        pJob           = load_job( pFile );
        pJob->next     = pMobIndex->job;
        pMobIndex->job = pJob;
        fMatch         = TRUE;
        break;
      }

      if ( !str_cmp( word , "#Learn" ) )
      {
        /* �קK�S���Ǫ����X�N���J�оɵ��c */
        if ( IS_ERROR( pMobIndex->vnum ) )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ��S�����X, �ӥ����о�." );

        load_mob_teach( pMobIndex , pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'A':

      KEY( "Act"       , pMobIndex->act , fread_number( pFile ) | ACT_IS_NPC );
      KEY( "Affect"    , pMobIndex->affected_by , fread_number( pFile ) );
      KEY( "Alignment" , pMobIndex->alignment   , fread_number( pFile ) );
      KEY( "AttackRatio", pMobIndex->attack_ratio, fread_number( pFile ) );

      if ( !str_cmp( word , "Auction" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pMobIndex->auction = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "AutoEnable" ) )
      {
        int           practice;
        ENABLE_DATA * pEnable;
        ENABLE_DATA * zEnable;
        SKILL_DATA  * pSkill;

        /* �p�G�ޯ�w�g���s�b */
        if ( !( pSkill = skill_isname( fread_word( pFile ) ) ) )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ��ޯ�P����~." );

        /* �ݬݳo�ӧޯ�O�_�i�H�Q�P�� */
        if ( !pSkill->enable )
          mudlog( LOG_DEBUG, "Load_mobiles: �Ǫ��P�� %s �O����P�઺."
            , pSkill->cname );

        /* �p�G���� */
        if ( ( enable_repeat( pMobIndex->enable , pSkill->slot ) ) )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ��ޯ�P�୫��." );

        if ( ( practice = get_adeptation( pSkill, pMobIndex ) ) < 0 )
          mudlog( LOG_DEBUG , "Load_mobiles: �o���ޯ�L�k�۰ʭP��." );

        if ( practice >= 100 )
        {
          mudlog( LOG_FAILENABLE, "�Ǫ��s�� %d �ޯ� %s �Ӯt�M��ĳ����."
            , pMobIndex->vnum, pSkill->name );

          practice = 100;
        }

        if ( practice <= 1 )
        {
          mudlog( LOG_FAILENABLE, "�Ǫ��s�� %d �ޯ� %s �Ӱ��M��ĳ����."
            , pMobIndex->vnum, pSkill->name );

          practice = 1;
        }

        /* �]�w���m�� */
        pMobIndex->skill[pSkill->slot] = practice;

        /* �p�G�s�b�~�t�m�O���鵹�L */
        pEnable       = alloc_struct( STRUCT_ENABLE_DATA );
        pEnable->slot = pSkill->slot;
        pEnable->next = NULL;

        /* ��X�̫�@�� */
        for ( zEnable = pMobIndex->enable;
              zEnable && zEnable->next;
              zEnable = zEnable->next );

        if ( !zEnable ) pMobIndex->enable = pEnable;
        else            zEnable->next     = pEnable;

        fMatch = TRUE;
        break;
      }

      break;

    case 'C':

      if ( !str_cmp( word , "Class" ) )
      {
        CLASS_DATA * pClass;
        int          vnum;

        if ( !( pClass = class_lookup( vnum = fread_number( pFile ) ) ) )
        {
          mudlog( LOG_DEBUG, "load_class: ���X %d ���Ǫ�¾�~ %d �q��"
            , pMobIndex->vnum , vnum );

          pClass = class_demos;
        }

        pMobIndex->class = pClass;
        fMatch           = TRUE;
        break;
      }

      KEY( "Con"   , pMobIndex->now_con , fread_number( pFile ) );
      break;

    case 'D':

      KEY( "DodgeRatio", pMobIndex->dodge_ratio, fread_number( pFile ) );
      KEY( "Damroll"   , pMobIndex->damroll    , fread_number( pFile ) );
      KEY( "Dex"       , pMobIndex->now_dex    , fread_number( pFile ) );

      if ( !str_cmp( word , "Description" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pMobIndex->description = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word , "Deadmsg" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pMobIndex->deadmsg = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "Enable" ) )
      {
        int           practice;
        ENABLE_DATA * pEnable;
        ENABLE_DATA * zEnable;
        SKILL_DATA  * pSkill;

        /* ��Ū�J���m�� */
        if ( ( practice = fread_number( pFile ) ) > 100 || practice <= 0 )
          mudlog( LOG_DEBUG, "Load_mobiles: �Ǫ��ޯ���m�צ����D." );

        /* �p�G�ޯ�w�g���s�b */
        if ( !( pSkill = skill_isname( fread_word( pFile ) ) ) )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ��ޯ�P����~." );

        /* �ݬݳo�ӧޯ�O�_�i�H�Q�P�� */
        if ( !pSkill->enable )
          mudlog( LOG_DEBUG, "Load_mobiles: �Ǫ��P�� %s �O����P�઺."
            , pSkill->cname );

        /* �p�G���� */
        if ( ( enable_repeat( pMobIndex->enable , pSkill->slot ) ) )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ��ޯ�P�୫��." );

        /* �]�w���m�� */
        pMobIndex->skill[pSkill->slot] = practice;

        /* �p�G�s�b�~�t�m�O���鵹�L */
        pEnable       = alloc_struct( STRUCT_ENABLE_DATA );
        pEnable->slot = pSkill->slot;
        pEnable->next = NULL;

        /* ��X�̫�@�� */
        for ( zEnable = pMobIndex->enable;
              zEnable && zEnable->next;
              zEnable = zEnable->next );

        if ( !zEnable ) pMobIndex->enable = pEnable;
        else            zEnable->next     = pEnable;

        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "End" ) )
      {
        if ( IS_ERROR( pMobIndex->vnum ) )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ��S�����X." );

        if ( !pMobIndex->player_name )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ� %d �S���W�r."
            , pMobIndex->vnum );

        if ( !pMobIndex->short_descr )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ� %d �S���u�y�z."
            , pMobIndex->vnum );

        if ( !pMobIndex->long_descr )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ� %d �S�����y�z."
            , pMobIndex->vnum );

        if ( !pMobIndex->description )
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ�%d �S���y�z."
            , pMobIndex->vnum );

        pMobIndex->area       = pArea;
        pMobIndex->filename   = str_dup( filename );
        iHash                 = pMobIndex->vnum % MAX_KEY_HASH;
        pMobIndex->next       = mob_index_hash[iHash];
        mob_index_hash[iHash] = pMobIndex;
        top_mob_index++;
        kill_table[URANGE(0, pMobIndex->level, MAX_LEVEL-1)].number++;

        FCLOSE( pFile );
        RETURN_NULL();
      }

      break;

    case 'G':

      KEY( "Gold" , pMobIndex->gold, fread_number( pFile ) );
      break;

    case 'H':

      KEY( "Hitroll", pMobIndex->hitroll, fread_number( pFile ) );
      KEY( "Hp"     , pMobIndex->hit   , fread_number( pFile ) );
      break;

    case 'I':

      KEY( "Int" , pMobIndex->now_int , fread_number( pFile ) );
      break;

    case 'L':

      if ( !str_cmp( word, "Level" ) )
      {
        int level;

        if ( ( level = fread_number( pFile ) ) <= 0 || level > MAX_LEVEL )
        {
          mudlog( LOG_DEBUG , "Load_mobiles: �Ǫ� %d ���� %d ���X�z."
           , pMobIndex->vnum, level );
        }

        pMobIndex->level = level;
        fMatch           = TRUE;
        break;
      }

      KEY( "LongDesc" , pMobIndex->long_descr , fread_string( pFile ) );
      break;

    case 'M':

      KEY( "Mana"     , pMobIndex->mana     , fread_number( pFile ) );
      KEY( "Move"     , pMobIndex->move     , fread_number( pFile ) );
      KEY( "Multipile", pMobIndex->multipile, fread_number( pFile ) );
      KEY( "Migrate"  , pMobIndex->migrate  , fread_number( pFile ) );
      break;

    case 'N':

      KEY( "Name" , pMobIndex->player_name , fread_string( pFile ) );
      break;

    case 'P':

      KEY( "Protect" , pMobIndex->ac , fread_number( pFile ) );

      if ( !str_cmp( word, "Program" ) )
      {
        if ( IS_ERROR( pMobIndex->vnum ) )
          mudlog( LOG_DEBUG
            , "Load_mobiles: �Ǫ��S�����X, �ӥ����Ǫ��� Program." );

        fread_to_eol( pFile );
        mprog_read_programs( pFile , pMobIndex );
        fMatch  = TRUE;
        break;
      }

      break;

    case 'R':

      KEY( "Reborn"    , pMobIndex->reborn_vnum, fread_number( pFile ) );
      KEY( "Rebornroom", pMobIndex->reborn_room, fread_number( pFile ) );
      break;

    case 'S':

      KEY( "Sex"       , pMobIndex->sex         , fread_number( pFile ) );
      KEY( "ShortDesc" , pMobIndex->short_descr , fread_string( pFile ) );
      KEY( "Str"       , pMobIndex->now_str     , fread_number( pFile ) );

      if ( !str_cmp( word, "Special" ) )
      {
        if ( !( pMobIndex->spec_fun = spec_lookup( fread_word( pFile ) ) ) )
          mudlog( LOG_DEBUG , "Load_mobiles: �S����Ƥ��s�b." );

        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word , "Speak" ) )
      {
        pMobIndex->speak = ( fread_number( pFile ) == TRUE ) ? TRUE : FALSE;
        fMatch = TRUE;
        break;
      }

      break;

    case 'T':
      KEY( "Tractable", pMobIndex->tractable, fread_number( pFile ) );
      break;

    case 'V':

      if ( !str_cmp( word , "Vnum" ) )
      {
        vnum            = fread_number( pFile );
        pMobIndex->vnum = vnum;

        /* �ˬd���X�O�_������ */
        fBootDb = FALSE;
        if ( get_mob_index( vnum ) )
        {
          fBootDb = TRUE;
          mudlog( LOG_DEBUG , "Load_mobiles: �s�� %d �� MOB ���� ." , vnum );
        }

        fBootDb = fMatch = TRUE;
        break;
      }
      break;

    case 'W':

      KEY( "Wis" , pMobIndex->now_wis , fread_number( pFile ) );
      break;

    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_mobiles: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

/* ���J�Ǫ��оɵ��c */
void load_mob_teach( MOB_INDEX_DATA * pMobIndex , FILE * fp )
{
  TEACH_DATA * teach;
  char       * word;
  bool         fMatch;

  PUSH_FUNCTION( "load_mob_teach" );

  /* �t�m�оɩһݭn���O����H�γ]�w�w�]�� */
  set_teach_default( teach = alloc_struct( STRUCT_TEACH_DATA ) );

  for ( ;; )
  {
    word   = if_eof( fp ) ? "End" : fread_word( fp );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( fp );
      break;

    case 'A':

      if ( !str_cmp( word, "Adept" ) )
      {
        teach->adept = fread_number( fp );

        if ( teach->adept < 0 || teach->adept > 100 )
        {
          mudlog( LOG_DEBUG
            , "Load_mob_teach: �Ǫ����X %d ���k�N���m�פ��X�z."
            , pMobIndex->vnum );
        }

        fMatch = TRUE;
        break;
      }

      break;

    case 'C':

      if ( !str_cmp( word , "Cost" ) )
      {
        if ( ( teach->cost = fread_number( fp ) ) < 0 )
        {
          mudlog( LOG_DEBUG
            , "Load_mob_teach: �Ǫ����X %d ���k�N�бª����X�z."
            , pMobIndex->vnum );
        }
        fMatch = TRUE;
        break;
      }

      break;

    case 'E':
      if ( !str_cmp( word, "End" ) )
      {
        if ( IS_ERROR( teach->slot ) )
        {
          mudlog( LOG_DEBUG
            , "Load_mob_teach: �Ǫ����X %d ���S���k�N���X."
            , pMobIndex->vnum );
        }

        teach->next      = pMobIndex->teach;
        pMobIndex->teach = teach;
        top_teach++;
        RETURN_NULL();
      }

      break;

    case 'I':

      if ( !str_cmp( word , "Inventory" ) )
      {
        teach->inventory = fread_number( fp );
        if ( teach->inventory < 0 || teach->inventory > 120 )
        {
          mudlog( LOG_DEBUG
            , "Load_mob_teach: �Ǫ����X %d ���k�N���úX�Ф���."
            , pMobIndex->vnum );
        }
        fMatch  = TRUE;
        break;
      }

      break;

    case 'N':

      if ( !str_cmp( word, "Name" ) )
      {
        char       * name_string;
        SKILL_DATA * pSkill;

        name_string = fread_word( fp );
        if ( !( pSkill = skill_isname( name_string ) ) )
        {
          mudlog( LOG_DEBUG , "Load_mob_teach: �Ǫ����X %d ���k�N %s ����."
            , pMobIndex->vnum , name_string );
        }

        teach->slot = pSkill->slot;
        fMatch      = TRUE;
        break;
      }
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_mob_teach: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

/* ���J�s�榡���ϰ��ɪ��ж��榡 */
void load_room( char * filename , AREA_DATA * pArea )
{
  ROOM_INDEX_DATA * pRoomIndex;
  FILE            * pFile;
  char            * word;
  bool              fMatch;
  int               iHash;

  PUSH_FUNCTION( "load_room" );

  /* �קK�S���ƥ����J���� #AREA */
  if ( !pArea )
  {
    mudlog( LOG_ERR , "Load_room: �S���ޤJ�ϰ�, �ҥH������J�ж�." );
  }

  if ( !( pFile = FOPEN( filename , "r" ) ) )
  {
    mudlog( LOG_FAILLOAD , "���J�ж��ɮ� %s ����.\n" , filename );
    RETURN_NULL();
  }

  /* �t�m�ж��Ŷ��H�γ]�w�w�]�� */
  pRoomIndex = alloc_struct( STRUCT_ROOM_INDEX_DATA );
  set_room_default( pRoomIndex );
  pRoomIndex->area = pArea;

  if ( pArea->list )
  {
    pRoomIndex->next_in_area = pArea->list;
    pArea->list              = pRoomIndex;
  }
  else
  {
    pArea->list = pRoomIndex;
  }

  /* �������J�ϰ��ɤ����ж� */
  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case '#':

      if ( !str_cmp( word , "#Exit" ) )
      {
        /* �קK�S���ж����X�N���J�X�f */
        if ( IS_ERROR( pRoomIndex->vnum ) )
          mudlog( LOG_DEBUG , "Load_room: �ж����X�٨S�]�w, �L�k�]�w�X�f." );

        /* ���J�ж��X�f�榡 */
        load_exit( pRoomIndex , pFile );
        fMatch = TRUE;
        break;
      }

      /* ���J�ж�������r���� */
      if ( !str_cmp( word , "#Keyword" ) )
      {
        /* �קK�S���ж����X�N���J����r */
        if ( IS_ERROR( pRoomIndex->vnum ) )
          mudlog( LOG_DEBUG , "Load_room: �ж����X�٨S�]�w, �L�k�]�w����r." );

        load_room_key( pRoomIndex , pFile );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "#Job" ) )
      {
        JOB_DATA * pJob;

        pJob            = load_job( pFile );
        pJob->next      = pRoomIndex->job;
        pRoomIndex->job = pJob;
        fMatch          = TRUE;
        break;
      }

      if ( !str_cmp( word, "#Enquire" ) )
      {
        ENQUIRE_DATA * pEnquire;

        pEnquire            = load_enquire( pFile );
        pEnquire->next      = pRoomIndex->enquire;
        pRoomIndex->enquire = pEnquire;
        fMatch              = TRUE;
        break;
      }

      break;

    case 'D':

      if ( !str_cmp( word , "Description" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pRoomIndex->description = fread_string( pFile );
        fMatch = TRUE;
        break;
      }
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        /* �קK���ǭ��n�ȩ|�����J�N���� */
        if ( !pRoomIndex->name )
          mudlog( LOG_DEBUG , "Load_room: �ж��S���W��" );

        if ( !pRoomIndex->description )
          mudlog( LOG_DEBUG , "Load_room: �ж��S���y�z." );

        if ( IS_ERROR( pRoomIndex->vnum ) )
          mudlog( LOG_DEBUG , "Load_room: �ж��S�����X." );

        if ( !pRoomIndex->sector )
          mudlog( LOG_DEBUG , "Load_room: �ж��S���a��." );

        pRoomIndex->filename   = str_dup( filename );
        iHash                  = pRoomIndex->vnum % MAX_KEY_HASH;
        pRoomIndex->next       = room_index_hash[iHash];
        room_index_hash[iHash] = pRoomIndex;
        top_room++;

        FCLOSE( pFile );
        RETURN_NULL();
      }

      break;

    case 'N':

      KEY( "Name" , pRoomIndex->name , fread_string( pFile ) );
      break;

    case 'R':

      KEY( "RoomFlag", pRoomIndex->room_flags , fread_number( pFile ) );
      break;

    case 'S':

      if ( !str_cmp( word , "SectorType" ) )
      {
        int iSector;
        SECTOR_DATA * pSector;

        iSector = fread_number( pFile );
        if ( !( pSector = get_sector_index( iSector ) ) )
          mudlog( LOG_DEBUG , "load_room: �ж��a���s�� %d ���s�b" , iSector );

        pRoomIndex->sector = pSector;
        pSector->count++;
        fMatch = TRUE;
        break;
      }

      break;

    case 'V':

      if ( !str_cmp( word , "Vnum" ) )
      {
        pRoomIndex->vnum = fread_number( pFile ) ;
        fBootDb = FALSE;

        /* �קK�ж����X�|������ */
        if ( get_room_index( pRoomIndex->vnum ) )
        {
          mudlog( LOG_DEBUG , "Load_room: �ж����X %d ����."
            , pRoomIndex->vnum );
        }

        fBootDb = fMatch = TRUE;
        break;
      }

      break;
    }

    /* ���O���A���~ */

    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_room: �R�O %s �����T." , word );
  }
}

/* ���J�ж����X�f */
void load_exit( ROOM_INDEX_DATA *pRoomIndex , FILE * fp )
{
  EXIT_DATA * pExit;
  char      * word;
  bool        fMatch;
  int         direction;

  PUSH_FUNCTION( "load_exit" );

  /* �t�m�O����H�γ]�w�w�]�� */
  set_exit_default( pExit = alloc_struct( STRUCT_EXIT_DATA ) );

  /* ���J�ϰ��ɩж��X�f���� */
  for ( direction = -1;; )
  {
    word   = if_eof( fp ) ? "End" : fread_word( fp );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( fp );
      break;

    case 'D':

      if ( !str_cmp( word, "Direction" ) )
      {
        switch( direction = fread_number( fp ) )
        {
        default:
          mudlog( LOG_DEBUG, "load_exit: �ж�%d���~����V %d."
            ,pRoomIndex->vnum , direction );

        case DIR_NORTH:
        case DIR_EAST:
        case DIR_SOUTH:
        case DIR_WEST:
        case DIR_UP:
        case DIR_DOWN:
        case DIR_ENTER:
        case DIR_OUT:
          break;
        }
        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        /* �קK���ǭ��n�ȩ|��Ū���N���} */
        if ( IS_ERROR( direction ) )
          mudlog( LOG_DEBUG , "Load_exit: �ж� %d �X�f��V�S���]�w."
            , pRoomIndex->vnum );

        if ( IS_ERROR( pExit->vnum ) )
          mudlog( LOG_DEBUG , "Load_exit: �ж� %d �X�f�S�����X."
            , pRoomIndex->vnum );

        if ( !pExit->description )
          mudlog( LOG_DEBUG , "Load_exit: �ж� %d �X�f�S���y�z."
            , pRoomIndex->vnum );

        if ( !pExit->keyword )
          mudlog( LOG_DEBUG , "Load_exit: �ж� %d �X�f�S������r."
            , pRoomIndex->vnum );

        pRoomIndex->exit[direction] = pExit;
        top_exit++;

        RETURN_NULL();
      }

      KEY( "ExitKey",  pExit->key  , fread_number( fp ) );
      KEY( "ExitVnum", pExit->vnum , fread_number( fp ) );

      if ( !str_cmp( word , "ExitKeyword" ) )
      {
        pExit->keyword = fread_string( fp );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word , "ExitDesc" ) )
      {
        pExit->description = fread_string( fp );
        fMatch = TRUE;
        break;
      }

      break;

    case 'L':
      KEY( "Lock", pExit->exit_info , fread_number( fp ) );
      break;

    case 'M':
      KEY( "Message", pExit->message, fread_string( fp ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_exit: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

/* ���J�ж�������r */
void load_room_key( ROOM_INDEX_DATA * pRoomIndex , FILE * fp )
{
  EXTRA_DESCR_DATA * ed;
  char             * word;
  bool               fMatch;

  PUSH_FUNCTION( "load_room_key" );

  /* �t�m�O���� */
  ed = alloc_struct( STRUCT_EXTRA_DESCR_DATA );

  /* �]�w�w�]�� */
  ed->keyword     = NULL;
  ed->description = NULL;

  /*���J�ϰ��ɩж�������r���� */

  for ( ;; )
  {
    word   = if_eof( fp ) ? "End" : fread_word( fp );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( fp );
      break;

    case 'D':

      if ( !str_cmp( word , "Description" ) )
      {
        fread_to_eol( fp ); /* �@�w��Ū���@�� */
        ed->description = fread_string( fp );
        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !ed->description )
          mudlog( LOG_DEBUG , "Load_key: �ж����X %d �S���y�z."
            , pRoomIndex->vnum );

        if ( !ed->keyword )
          mudlog( LOG_DEBUG , "Load_key: �ж����X %d �y�z�S������r."
            , pRoomIndex->vnum );

        ed->next                = pRoomIndex->extra_descr;
        pRoomIndex->extra_descr = ed;
        top_ed++;
        RETURN_NULL();
      }

      break;

    case 'K':

      KEY( "Keyword", ed->keyword , fread_string( fp ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_key: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

/* ���J�s�榡���ө��榡 */
void load_shop( char * filename , AREA_DATA * pArea )
{
  MOB_INDEX_DATA  * pMobIndex;
  MOB_INDEX_DATA  * pVictim;
  SHOP_DATA       * pShop;
  FILE            * pFile;
  char            * word;
  int               iTrade;
  bool              fMatch;

  PUSH_FUNCTION( "load_shop" );

  if ( !( pFile = FOPEN( filename , "r" ) ) )
  {
    mudlog( LOG_FAILLOAD , "���J�ө��ɮ� %s ����.\n" , filename );
    RETURN_NULL();
  }

  /* �t�m�ө��һݭn���O����H�γ]�w�w�]�� */
  set_shop_default( pShop = alloc_struct( STRUCT_SHOP_DATA ) );

  /* ���J�ϰ��ɸ̭����ө����� */
  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'B':
      KEY( "BuyProfit", pShop->profit_buy , fread_number( pFile ) );
      break;

    case 'C':
      KEY( "CloseHour", pShop->close_hour , fread_number( pFile ) );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        /* �קK�S�����������~ */
        if ( IS_ERROR( pShop->keeper ) )
          mudlog( LOG_DEBUG , "Load_shop: �S�����J���D." );

        if ( IS_ERROR( pShop->type ) )
          mudlog( LOG_DEBUG, "Load_shop:�S�����J���a���A." );

        pShop->filename  = str_dup( filename );
        pMobIndex        = get_mob_index( pShop->keeper );

        if ( pMobIndex->pShop )
          mudlog( LOG_DEBUG, "load_shop: �Ǫ� %d �w���ө����c."
            , pMobIndex->vnum );

        switch( pShop->type )
        {
        default:
          break;

        case SHOP_MERCENARY:

          fBootDb = FALSE;

          for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
          {
            int slot;

            if ( ( slot = pShop->buy_type[iTrade] ) == 0 ) continue;

            if ( !( get_mob_index( slot ) ) )
            {
              fBootDb = TRUE;
              mudlog( LOG_DEBUG, "load_shop: �ħL���X %d ���s�b.", slot );
            }
          }

          fBootDb = TRUE;
          break;

        case SHOP_COPER:

          fBootDb = FALSE;

          for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
          {
            int slot;

            if ( ( slot = pShop->buy_type[iTrade] ) == 0 ) continue;

            if ( !( pVictim = get_mob_index( slot ) ) )
            {
              fBootDb = TRUE;
              mudlog( LOG_DEBUG, "load_shop: �y�M���X %d ���s�b.", slot );
            }

            if ( pVictim->tractable <= 0 )
            {
              fBootDb = TRUE;
              mudlog( LOG_DEBUG, "load_shop: ���X %d ���O�y�M.", slot );
            }
          }

          fBootDb = TRUE;
          break;
        }

        pMobIndex->pShop = pShop;

        if ( !shop_first ) shop_first      = pShop;
        if (  shop_last  ) shop_last->next = pShop;

        shop_last   = pShop;
        pShop->next = NULL;
        top_shop++;

        FCLOSE( pFile );
        RETURN_NULL();
      }

      break;

    case 'H':

      if ( !str_cmp( word , "Horse" ) )
      {
        for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
        {
          if ( fread_if_eol( pFile ) ) break;
          pShop->buy_type[iTrade] = fread_number( pFile );
        }

        fread_to_eol( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'K':

      KEY( "Keeper", pShop->keeper , fread_number( pFile ) );
      break;

    case 'M':

      if ( !str_cmp( word , "Mercenary" ) )
      {
        for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
        {
          if ( fread_if_eol( pFile ) ) break;
          pShop->buy_type[iTrade] = fread_number( pFile );
        }

        fread_to_eol( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'O':

      KEY( "OpenHour", pShop->open_hour   , fread_number( pFile ) );
      KEY( "Object1",  pShop->buy_type[0] , fread_number( pFile ) );
      KEY( "Object2",  pShop->buy_type[1] , fread_number( pFile ) );
      KEY( "Object3",  pShop->buy_type[2] , fread_number( pFile ) );
      KEY( "Object4",  pShop->buy_type[3] , fread_number( pFile ) );
      KEY( "Object5",  pShop->buy_type[4] , fread_number( pFile ) );

      if ( !str_cmp( word , "Object" ) )
      {
        for ( iTrade = 0; iTrade < MAX_TRADE; iTrade++ )
        {
          if ( fread_if_eol( pFile ) ) break;
          pShop->buy_type[iTrade] = fread_number( pFile );
        }

        fread_to_eol( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'S':
      KEY( "SellProfit", pShop->profit_sell , fread_number( pFile ) );

      if ( !str_cmp( word, "Sential" ) )
      {
        pShop->sential = get_room_index( fread_number( pFile ) );
        fMatch = TRUE;
        break;
      }
      break;

    case 'T':

      if ( !str_cmp( word , "Type" ) )
      {
        switch( ( iTrade = fread_number( pFile ) ) )
        {
        default:
          mudlog( LOG_DEBUG, "load_shop: ���A %d ���~.", iTrade );
          break;

        case SHOP_STORE:
        case SHOP_SMITH:
        case SHOP_MERCENARY:
        case SHOP_COPER:

          pShop->type = iTrade;
          break;
        }

        fMatch = TRUE;
        break;
      }
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_shop: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

/* ���J�s�榡���q���榡 */
void load_mineral( char * filename , AREA_DATA * pArea )
{
  MINERAL_DATA * pMineral;
  FILE         * pFile;
  char         * word;
  bool           fMatch;

  PUSH_FUNCTION( "load_mineral" );

  if ( !( pFile = FOPEN( filename , "r" ) ) )
  {
    mudlog( LOG_FAILLOAD , "���J�q���ɮ� %s ����.\n" , filename );
    RETURN_NULL();
  }

  /* �t�m�ө��һݭn���O����H�γ]�w�w�]�� */
  pMineral = alloc_struct( STRUCT_MINERAL_DATA );
  set_mineral_default( pMineral );

  /* ���J�ϰ��ɸ̭����ө����� */
  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER(word[0]) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'C':
      KEY( "Count", pMineral->count, fread_number( pFile ) );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( IS_ERROR( pMineral->count ) )
          mudlog( LOG_DEBUG , "load_mineral: �S���ƶq." );

        if ( !pMineral->mineral )
          mudlog( LOG_DEBUG , "load_mineral: �S���q��." );

        pMineral->next = pArea->mineral;
        pArea->mineral = pMineral;
        top_mineral++;

        FCLOSE( pFile );
        RETURN_NULL();
      }

      break;

    case 'F':
      KEY( "Flags", pMineral->flags, fread_number( pFile ) );
      break;

    case 'M':
      KEY( "Message", pMineral->message, fread_string( pFile ) );
      break;

    case 'V':

      if ( !str_cmp( word , "Vnum" ) )
      {
        int slot;

        slot    = fread_number( pFile );
        fBootDb = FALSE;

        if ( !( pMineral->mineral = get_obj_index( slot ) ) )
        {
          fBootDb = TRUE;
          mudlog( LOG_DEBUG , "load_mineral: �q�����X %d ���s�b.", slot );
        }

        fBootDb = TRUE;
        fMatch  = TRUE;
        break;
      }

      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "load_mineral: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* ���J���~ */
void load_object( char * filename , AREA_DATA * pArea )
{
  OBJ_INDEX_DATA * pObjIndex;
  RESTRICT_DATA  * pRestrict;
  MESSAGE_DATA   * pMessage;
  SKILL_DATA     * pSkill;
  AFFECT_DATA    * pAffect;
  FILE           * pFile;
  char           * word;
  bool             fMatch;
  int              iHash;
  int              vnum;

  PUSH_FUNCTION( "load_object" );

  if ( !( pFile = FOPEN( filename , "r" ) ) )
  {
    mudlog( LOG_FAILLOAD , "���J���~�ɮ� %s ����.\n" , filename );
    RETURN_NULL();
  }

  /* �t�m���~�һݭn���O����H�γ]�w�w�]�� */
  pObjIndex = alloc_struct( STRUCT_OBJ_INDEX_DATA );
  set_object_default( pObjIndex );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case '#':

      if ( !str_cmp( word , "#Affect" ) )
      {
        /* �קK�S�����~���X�N���J�ݩ� */
        if ( IS_ERROR( pObjIndex->vnum ) )
          mudlog( LOG_DEBUG, "Load_object: ���~���X�٨S�]�w, �L�k�]�w�ݩ�." );

        /* ���J���~�ݩʮ榡 */
        pAffect = load_obj_affect( pFile );

        pAffect->next       = pObjIndex->affected;
        pObjIndex->affected = pAffect;
        top_affect++;
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word , "#Impact" ) )
      {
        /* �קK�S�����~���X�N���J�ݩ� */
        if ( IS_ERROR( pObjIndex->vnum ) )
          mudlog( LOG_DEBUG, "Load_object: ���~���X�٨S�]�w, �L�k�]�w�ݩ�." );

        /* ���J���~�ݩʮ榡 */
        pAffect = load_obj_affect( pFile );

        pAffect->next     = pObjIndex->impact;
        pObjIndex->impact = pAffect;
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "#Restrict" ) )
      {
        /* ���J���~�˳ƭ��� */
        pRestrict = load_restrict( pFile );
        pRestrict->next     = pObjIndex->restrict;
        pObjIndex->restrict = pRestrict;
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "#Message" ) )
      {
        /* ���J���~�˳Ʊԭz */
        pMessage = load_message( pFile );
        pMessage->next     = pObjIndex->message;
        pObjIndex->message = pMessage;
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word , "#Extra" ) )
      {
        /* �קK�S�����~���X�N���J�B�~�y�z */
        if ( IS_ERROR( pObjIndex->vnum ) )
          mudlog( LOG_DEBUG ,
            "Load_object: ���~���X�٨S�]�w, �L�k�]�w�B�~�y�z." );

        /* ���J���~�ݩʮ榡 */
        load_obj_extra( pObjIndex , pFile );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "#Job" ) )
      {
        JOB_DATA * pJob;

        pJob           = load_job( pFile );
        pJob->next     = pObjIndex->job;
        pObjIndex->job = pJob;
        fMatch         = TRUE;
        break;
      }

      break;

    case 'A':
      if ( !str_cmp( word, "Armor" ) )
      {
        pObjIndex->armor = UMIN( MAX_ARMOR, fread_number( pFile ) );
        fMatch = TRUE;
        break;
      }
      break;

    case 'C':

      KEY( "Cost" , pObjIndex->cost , fread_number( pFile ) );
      break;

    case 'D':

      if ( !str_cmp( word , "Description" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pObjIndex->description = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word , "Disappear" ) )
      {
        pObjIndex->disappear = ( fread_number( pFile ) == TRUE ) ? TRUE : FALSE;
        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      KEY( "ExtraFlag" , pObjIndex->extra_flags, fread_number( pFile ) );
      KEY( "Exp"       , pObjIndex->exp        , fread_number( pFile ) );

      if ( !str_cmp( word, "End" ) )
      {
        AFFECT_DATA * paf;
        int           count;

        if ( IS_ERROR( ( vnum = pObjIndex->vnum ) ) )
          mudlog( LOG_DEBUG , "Load_object: ���~�S�����X." );

        if ( !pObjIndex->name )
          mudlog( LOG_DEBUG , "Load_object: ���~ %d �S���W�r.", vnum );

        if ( !pObjIndex->short_descr )
          mudlog( LOG_DEBUG , "Load_object: ���~ %d �S���u�ԭz.", vnum );

        if ( !pObjIndex->description )
          mudlog( LOG_DEBUG , "Load_object: ���~ %d �S�����ԭz.", vnum );

        if ( IS_ERROR( pObjIndex->item_type ) )
          mudlog( LOG_DEBUG , "Load_object: ���~ %d �S�����~���A.", vnum );

        if ( IS_ERROR( pObjIndex->wear_flags ) )
          mudlog( LOG_DEBUG , "Load_object: ���~ %d �S�������X��.", vnum );

        switch( pObjIndex->item_type )
        {
        default:

          if ( pObjIndex->cost > pObjIndex->level * 20 )
            mudlog( LOG_INFO, "[���~�ӶQ] ���~ %d �����Ӱ��C", vnum );

          if ( pObjIndex->item_type == ITEM_MAGICSTONE && !pObjIndex->impact )
            mudlog( LOG_INFO, "�]�� %d �S�����w�����C", vnum );

          if ( pObjIndex->item_type != ITEM_MAGICSTONE && pObjIndex->impact )
            mudlog( LOG_INFO, "�D�]�� %d �����w�����C", vnum );

          for ( count = 0, paf = pObjIndex->affected; paf; paf = paf->next )
          {
            switch( paf->location )
            {
            default:
              break;

            case APPLY_HIT:
            case APPLY_MANA:
            case APPLY_MOVE:
              if ( paf->modifier > pObjIndex->level * 10 )
                mudlog( LOG_DEBUG, "[Alert]: ���~ %-5d ���� %-3d �W�["
                  "�I�� %4d �Ӧh�C", vnum, pObjIndex->level, paf->modifier );
              break;

            case APPLY_STR:
            case APPLY_INT:
            case APPLY_WIS:
            case APPLY_DEX:
            case APPLY_CON:
              if ( paf->modifier > 3 )
                mudlog( LOG_DEBUG, "[Alert]: ���~ %-5d ���� %-3d �W�[��"
                  "�� %2d �Ӧh�C", vnum, pObjIndex->level, paf->modifier );
              count += paf->modifier;
              break;
            }
          }

          if ( count > 2 )
            mudlog( LOG_DEBUG, "[Alert]: ���~ %-5d ���� %-3d �W�[��"
              "�� %2d �Ӧh�C"
              , vnum, pObjIndex->level, count );
          break;

        case ITEM_PILL:
        case ITEM_POTION:
        case ITEM_MYSTERY:
        case ITEM_SCROLL:
        case ITEM_SIGIL:
        case ITEM_VELLUM:
        case ITEM_BOAT:
        case ITEM_FIREWORK:
          break;
        }


        if ( IS_ERROR( pObjIndex->cost ) )
          pObjIndex->cost = pObjIndex->level * 10;

        if ( IS_ERROR( pObjIndex->armor ) )
          pObjIndex->armor = pObjIndex->level * 100;

        if ( pObjIndex->item_type == ITEM_POTION )
          SET_BIT( pObjIndex->extra_flags , ITEM_NODROP );

        /* �ˬd���~�ƭ� */
        switch( pObjIndex->item_type )
        {
        default:
          break;

        case ITEM_WEAPON:

          /* ���Z����ˤp�󵥩�s�ɪ��B�z */
          if ( pObjIndex->value[1] <= 0 || pObjIndex->value[2] <= 0 )
          {
            int max;
            int min;

            max = 100 + ( pObjIndex->level / 2 );
            min = 100;

            switch( pObjIndex->value[3] )
            {
            case WEAPON_AXE:
              max += 7;
              min += 4;
              break;

            case WEAPON_HAMMER:
            case WEAPON_CLUB:
              max += 6;
              min += 4;
              break;

            case WEAPON_BLADE:
              max += 5;
              min += 3;
              break;

            case WEAPON_SWORD:
              max += 4;
              min += 3;
              break;

            case WEAPON_SPEAR:
              max += 3;
              min += 2;
              break;

            case WEAPON_WHIP:
              max += 2;
              min += 2;
              break;

            case WEAPON_BOW:
              max += 1;
              min += 1;
              break;

            case WEAPON_DAGGER:
            case WEAPON_PEN:
              break;
            }

            pObjIndex->value[1] = min;
            pObjIndex->value[2] = max;
          }

          break;

        case ITEM_ARMOR:

          if ( pObjIndex->value[0] <= 0 )
            pObjIndex->value[0]  = UMAX( 1, ( pObjIndex->level / 20 ) );

          break;

        case ITEM_SCROLL:
        case ITEM_POTION:
        case ITEM_PILL:

          switch( pObjIndex->value[1] )
          {
          default:
            mudlog( LOG_DEBUG , "Load_object: �I�k���~ %d �ƭȿ��~.", vnum );

          /* ���ݭn�]�w�ޯู�X */
          case OBJ_CAST_HIT:
          case OBJ_CAST_MANA:
          case OBJ_CAST_MOVE:
          case OBJ_CAST_ALL:
            break;

          /* ���ݭn�]�w�ޯู�X */
          case OBJ_CAST_IDENT:
          case OBJ_CURE_POISON:
          case OBJ_DETECT_INVS:
          case OBJ_DETECT_MASK:
          case OBJ_CAST_FLY:
          case OBJ_CURE_BLIND:
          case OBJ_GIANT_STR:
          case OBJ_DETECT_HIDE:
          case OBJ_SNEAK:
          case OBJ_DETECT_EVIL:
          case OBJ_CHANGE_SEX:
          case OBJ_DETECT_MAGIC:
          case OBJ_DETECT_POISON:
          case OBJ_FAERIE_FOG:
          case OBJ_GATE:
          case OBJ_FIXITY:

            for ( pSkill = skill_list; pSkill; pSkill = pSkill->next )
              if ( pSkill->affect_id == pObjIndex->value[1] ) break;

            if ( !pSkill )
              mudlog( LOG_DEBUG , "Load_object: �I�k���~ %d �ޯ���~.", vnum );

            pObjIndex->value[2] = pSkill->slot;
            break;
          }

          break;
        }

        pObjIndex->filename   = str_dup( filename );
        iHash                 = pObjIndex->vnum % MAX_KEY_HASH;
        pObjIndex->next       = obj_index_hash[iHash];
        obj_index_hash[iHash] = pObjIndex;
        top_obj_index++;

        FCLOSE( pFile );
        RETURN_NULL();
      }

      break;

    case 'I':

      KEY( "ItemType" , pObjIndex->item_type , fread_number( pFile ) );
      break;

    case 'L':

      KEY( "Level"    , pObjIndex->level      , fread_number( pFile ) );
      KEY( "LongDesc" , pObjIndex->long_descr , fread_string( pFile ) );
      break;

    case 'N':

      KEY( "Name" , pObjIndex->name , fread_string( pFile ) );
      break;

    case 'R':

      if ( !str_cmp( word , "Remmsg" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pObjIndex->remmsg = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'S':

      KEY( "ShortDesc" , pObjIndex->short_descr , fread_string( pFile ) );
      break;

    case 'U':
      KEY( "Unit", pObjIndex->unit, fread_string( pFile ) );

      break;

    case 'V':

      KEY( "Value1"  , pObjIndex->value[ 0] , fread_number( pFile ) );
      KEY( "Value2"  , pObjIndex->value[ 1] , fread_number( pFile ) );
      KEY( "Value3"  , pObjIndex->value[ 2] , fread_number( pFile ) );
      KEY( "Value4"  , pObjIndex->value[ 3] , fread_number( pFile ) );
      KEY( "Value5"  , pObjIndex->value[ 4] , fread_number( pFile ) );
      KEY( "Value6"  , pObjIndex->value[ 5] , fread_number( pFile ) );
      KEY( "Value7"  , pObjIndex->value[ 6] , fread_number( pFile ) );
      KEY( "Value8"  , pObjIndex->value[ 7] , fread_number( pFile ) );
      KEY( "Value9"  , pObjIndex->value[ 8] , fread_number( pFile ) );
      KEY( "Value10" , pObjIndex->value[ 9] , fread_number( pFile ) );
      KEY( "Value11" , pObjIndex->value[10] , fread_number( pFile ) );
      KEY( "Value12" , pObjIndex->value[11] , fread_number( pFile ) );
      KEY( "Value13" , pObjIndex->value[12] , fread_number( pFile ) );
      KEY( "Value14" , pObjIndex->value[13] , fread_number( pFile ) );
      KEY( "Value15" , pObjIndex->value[14] , fread_number( pFile ) );

      if ( !str_cmp( word , "Vnum" ) )
      {
        pObjIndex->vnum = fread_number( pFile ) ;
        fBootDb         = FALSE;

        /* �קK���~���X�|������ */
        if ( get_obj_index( pObjIndex->vnum ) )
        {
          fBootDb = TRUE;
          mudlog( LOG_DEBUG , "Load_object: ���~���X %d ����."
            , pObjIndex->vnum );
        }

        fBootDb = TRUE;
        fMatch  = TRUE;
        break;
      }

      if ( !str_cmp( word , "Value" ) )
      {
        int loop = 0;

        while ( loop < MAX_OBJECT_VALUE )
        {
          if ( fread_if_eol( pFile ) ) break;
          pObjIndex->value[ loop++ ] = fread_number( pFile );
        }

        fread_to_eol( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'W':

      KEY( "WearLoc" , pObjIndex->wear_flags , fread_number( pFile ) );
      KEY( "Weight"  , pObjIndex->weight     , fread_number( pFile ) );

      if ( !str_cmp( word , "Wearmsg" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pObjIndex->wearmsg = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_object: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

/* ���J���~���v�T */
AFFECT_DATA * load_obj_affect( FILE * fp )
{
  AFFECT_DATA * paf;
  char        * word;
  bool          fMatch;

  PUSH_FUNCTION( "load_obj_affect" );

  /* �t�m���~�ݩʪ��O����M�]�w�w�]�� */
  paf = alloc_struct( STRUCT_AFFECT_DATA );
  set_obj_affect_default( paf );

  for ( ;; )
  {
    word   = if_eof( fp ) ? "End" : fread_word( fp );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( fp );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( IS_ERROR( paf->location ) )
          mudlog( LOG_DEBUG , "Load_obj_affect: �S���]�w�v�T�ݩʪ����A." );

        RETURN( paf );
      }

      break;

    case 'L':
      KEY( "Location" , paf->location , fread_number( fp ) );
      break;

    case 'M':
      KEY( "Modifier" , paf->modifier , fread_number( fp ) );
      break;

    case 'V':
      KEY( "Value" , paf->modifier , fread_number( fp ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_obj_affect: �R�O %d �����T.", word );
  }

  RETURN( NULL );
}

/* ���J���~�˳ơB�ޯध���� */
RESTRICT_DATA * load_restrict( FILE * pFile )
{
  RESTRICT_DATA * pRestrict;
  char          * word;
  bool            fMatch;

  PUSH_FUNCTION( "load_restrict" );

  /* �t�m���~�ݩʪ��O����M�]�w�w�]�� */
  set_restrict_default( pRestrict = alloc_struct( STRUCT_RESTRICT_DATA ) );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( IS_ERROR( pRestrict->type ) )
          mudlog( LOG_DEBUG, "load_restrict: ����ʥF���A." );

        if ( IS_ERROR( pRestrict->value ) )
          mudlog( LOG_DEBUG, "load_restrict: ����S���ƭ�." );

        switch( pRestrict->type )
        {
        case RES_STR:
          if ( pRestrict->value > MaxStr || pRestrict->value < 0 )
            mudlog( LOG_DEBUG, "Load_restrict: �O�q�ƭ� %d ���X�z."
              , pRestrict->value );
           break;

        case RES_INT:
          if ( pRestrict->value > MaxInt || pRestrict->value < 0 )
            mudlog( LOG_DEBUG, "Load_restrict: ���O�ƭ� %d ���X�z."
              , pRestrict->value );
           break;

        case RES_WIS:
          if ( pRestrict->value > MaxWis || pRestrict->value < 0 )
            mudlog( LOG_DEBUG, "Load_restrict: ���Ѽƭ� %d ���X�z."
              , pRestrict->value );
           break;

        case RES_DEX:
          if ( pRestrict->value > MaxDex || pRestrict->value < 0 )
            mudlog( LOG_DEBUG, "Load_restrict: �ӱ��ƭ� %d ���X�z."
              , pRestrict->value );
           break;

        case RES_CON:
          if ( pRestrict->value > MaxCon || pRestrict->value < 0 )
            mudlog( LOG_DEBUG, "Load_restrict: ���ƭ� %d ���X�z."
              , pRestrict->value );
           break;

        case RES_TRUST:
          if ( pRestrict->value > MAX_LEVEL || pRestrict->value < 0 )
            mudlog( LOG_DEBUG, "Load_restrict: �H���ƭ� %d ���X�z."
              , pRestrict->value );
           break;

        case RES_SEX:

          switch( pRestrict->value )
          {
          default:
            mudlog( LOG_DEBUG, "load_restrict: �ʧO %d ���~."
              , pRestrict->value );

          case SEX_FEMALE:
          case SEX_MALE:
          case SEX_NEUTRAL:
            break;
          }

        case RES_LEVEL:
          if ( pRestrict->value > MAX_LEVEL || pRestrict->value < 0 )
            mudlog( LOG_DEBUG, "Load_restrict: ���żƭ� %d ���X�z."
              , pRestrict->value );

          break;

        case RES_ALIGN:

          if ( pRestrict->value < -1000 || pRestrict->value > 1000 )
            mudlog( LOG_DEBUG, "Load_restrict: �}��ƭ� %d ���X�z."
              , pRestrict->value );
        }

        top_restrict++;
        RETURN( pRestrict );
      }

      break;

    case 'O':

      if ( !str_cmp( word, "Occassion" ) )
      {
        switch( ( pRestrict->occasion = fread_number( pFile ) ) )
        {
        default:
          mudlog( LOG_DEBUG, "load_restrict: �ɾ� %d ���~."
            , pRestrict->occasion );

        case OCCASION_NONE:
          break;
        }

        fMatch = TRUE;
        break;
      }
      break;

    case 'S':

      if ( !str_cmp( word, "Skill" ) )
      {
        char       * pWord;
        SKILL_DATA * pSkill;

        if ( !( pSkill = skill_isname( pWord = fread_word( pFile ) ) ) )
          mudlog( LOG_DEBUG, "load_restrict: �S���o�اޯ� %s.", pWord );

        pRestrict->value = pSkill->slot;
        fMatch = TRUE;
        break;
      }
      break;

    case 'T':

      if ( !str_cmp( word, "Type" ) )
      {
        switch( pRestrict->type = fread_number( pFile ) )
        {
        default:
          mudlog( LOG_DEBUG, "load_restrict: ����A %d ���~."
            , pRestrict->type );

        case RES_STR:
        case RES_INT:
        case RES_WIS:
        case RES_DEX:
        case RES_CON:
        case RES_HP:
        case RES_MANA:
        case RES_MOVE:
        case RES_CLASS:
        case RES_TRUST:
        case RES_SKILL:
        case RES_NOSKILL:
        case RES_SEX:
        case RES_LEVEL:
        case RES_ALIGN:
          break;
        }

        fMatch = TRUE;
        break;
      }
      break;

    case 'V':
      KEY( "Value"    , pRestrict->value    , fread_number( pFile ) );
      KEY( "ViceValue", pRestrict->vicevalue, fread_number( pFile ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_restrict: �R�O %s �����T.", word );
  }

  RETURN( NULL );
}

MESSAGE_DATA * load_message( FILE * pFile )
{
  MESSAGE_DATA  * pMessage;
  char          * word;
  bool            fMatch;

  PUSH_FUNCTION( "load_message" );

  /* �t�m���~�ݩʪ��O����M�]�w�w�]�� */
  set_message_default( pMessage= alloc_struct( STRUCT_MESSAGE_DATA ) );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( IS_ERROR( pMessage->type ) )
          mudlog( LOG_DEBUG, "load_message: �ԭz�S���κA." );

        if ( !pMessage->self )
          mudlog( LOG_DEBUG, "load_message: �ԭz�S���ԭz�r��." );

        if ( !pMessage->others )
          mudlog( LOG_DEBUG, "load_message: �ԭz�S���ԭz�r��." );

        RETURN( pMessage );
      }

      break;

    case 'O':

      if ( !str_cmp( word , "Others" ) )
      {
        if ( pMessage->others )
          mudlog( LOG_DEBUG, "load_message: �ԭz���Щw�q." );

        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pMessage->others = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'S':

      if ( !str_cmp( word , "Self" ) )
      {
        if ( pMessage->self )
          mudlog( LOG_DEBUG, "load_message: �ԭz���Щw�q." );

        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pMessage->self = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word , "String" ) )
      {
        if ( pMessage->self )
          mudlog( LOG_DEBUG, "load_message: �ԭz���Щw�q." );

        if ( pMessage->others )
          mudlog( LOG_DEBUG, "load_message: �ԭz���Щw�q." );

        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pMessage->self   = fread_string( pFile );
        pMessage->others = str_dup( pMessage->self );
        fMatch = TRUE;
        break;
      }

      break;

    case 'T':

      if ( !str_cmp( word, "Type" ) )
      {
        switch( pMessage->type = fread_number( pFile ) )
        {
        default:
          mudlog( LOG_DEBUG, "load_message: �ԭz���A %d ���~."
            , pMessage->type );

        case ACT_WHEN_EAT:
        case ACT_WHEN_WEAR:
        case ACT_WHEN_DROP:
        case ACT_WHEN_REMOVE:
        case ACT_WHEN_SACRIFICE:
        case ACT_WHEN_GET:
        case ACT_WHEN_PUT:
        case ACT_WHEN_GIVE:
        case ACT_WHEN_FILL:
        case ACT_WHEN_DRINK:
        case ACT_WHEN_RECITE:
        case ACT_WHEN_BUY:
        case ACT_WHEN_SELL:
        case ACT_WHEN_VALUE:
        case ACT_WHEN_LOOK:
        case ACT_WHEN_COMPARE:
        case ACT_WHEN_SEND:
        case ACT_WHEN_OPEN:
        case ACT_WHEN_CLOSE:
        case ACT_WHEN_LOCK:
        case ACT_WHEN_UNLOCK:
        case ACT_WHEN_AUCTION:
        case ACT_WHEN_BET:
        case ACT_WHEN_REPAIR:
        case ACT_WHEN_DEPOSIT:
        case ACT_WHEN_WITHDRAW:
        case ACT_WHEN_CACHET:
        case ACT_WHEN_SLUP:
          break;
        }

        fMatch = TRUE;
        break;
      }
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_message: �R�O %s �����T.", word );
  }

  RETURN( NULL );
}


/*  ���J���~���B�~�y�z */
void load_obj_extra( OBJ_INDEX_DATA * pObjIndex , FILE * fp )
{
  EXTRA_DESCR_DATA * ed;
  char             * word;
  bool               fMatch;

  PUSH_FUNCTION( "load_obj_extra" );

  /* �t�m���~�B�~�y�z���O����H�γ]�w�w�]�� */
  ed               = alloc_struct( STRUCT_EXTRA_DESCR_DATA );
  ed->keyword      = NULL;
  ed->description  = NULL;

  for ( ;; )
  {
    word   = if_eof( fp ) ? "End" : fread_word( fp );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( fp );
      break;

    case 'D':

      if ( !str_cmp( word , "Description" ) )
      {
        fread_to_eol( fp ); /* �@�w��Ū���@�� */
        ed->description = fread_string( fp );
        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !ed->keyword )
          mudlog( LOG_DEBUG , "Load_obj_extra: �S���]�w����r." );

        if ( !ed->description )
          mudlog( LOG_DEBUG , "Load_obj_extra: �S���]�w�y�z." );

        ed->next               = pObjIndex->extra_descr;
        pObjIndex->extra_descr = ed;
        top_ed++;
        RETURN_NULL();
      }

      break;

    case 'K':

      KEY( "Keyword" , ed->keyword , fread_string( fp ) );
      break;

    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_obj_extra: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

/* Ū�J�ϰ��ɪ� reset */
void load_resets( char * filename , AREA_DATA * pArea )
{
  ROOM_INDEX_DATA * pRoomIndex;
  RESET_DATA      * pReset;
  EXIT_DATA       * pExit;
  FILE            * pFile;
  char              letter;

  PUSH_FUNCTION( "load_reset" );

  if ( !( pFile = FOPEN( filename , "r" ) ) )
  {
    mudlog( LOG_FAILLOAD , "���J�ɮ� %s ����.\n" , filename );
    RETURN_NULL();
  }

  if ( !pArea )
    mudlog( LOG_DEBUG , "Load_resets: �S������ #AREA �ҥH���వ reset ." );

  for ( ;; )
  {
    if ( if_eof( pFile ) ) break;
    letter = fread_letter( pFile );

    if ( letter == '*' )
    {
      fread_to_eol( pFile );
      continue;
    }

    /* �t�m�O���� */
    pReset          = alloc_struct( STRUCT_RESET_DATA );
    pReset->command = letter;
    pReset->arg1    = fread_number( pFile );
    pReset->arg2    = fread_number( pFile );
    pReset->arg3    = ( letter == 'G' || letter == 'R')
                        ? 0 : fread_number( pFile );

    fread_to_eol( pFile );

    switch ( letter )
    {
    default:
      mudlog( LOG_DEBUG , "Load_resets: ���w�q�� RESET �R�O '%c'.", letter );
      break;

    case 'M':
      get_mob_index ( pReset->arg1 );
      get_room_index( pReset->arg3 );
      break;

    case 'O':
      get_obj_index ( pReset->arg1 );
      get_room_index( pReset->arg3 );
      break;

    case 'P':
      get_obj_index( pReset->arg1 );
      get_obj_index( pReset->arg3 );
      break;

    case 'E':
    case 'G':
      get_obj_index( pReset->arg1 );
      break;

    case 'A':
      get_mob_index( pReset->arg1 );
      break;

    case 'D':
      pRoomIndex = get_room_index( pReset->arg1 );

      if ( pReset->arg2 < 0
        || pReset->arg2 > 5
        || ( pExit = pRoomIndex->exit[pReset->arg2] ) == NULL
        || !IS_SET( pExit->exit_info, EX_ISDOOR ) )
      {
        mudlog( LOG_DEBUG , "Load_resets: 'D': �X�f %d ���O�@�Ӫ�."
          , pReset->arg2 );
      }

      if ( pReset->arg3 < 0 || pReset->arg3 > 2 )
        mudlog( LOG_DEBUG , "Load_resets: 'D': ���~����: %d.", pReset->arg3 );

      break;

    case 'R':

      pRoomIndex = get_room_index( pReset->arg1 );

      if ( pReset->arg2 < 0 || pReset->arg2 > 6 )
        mudlog( LOG_DEBUG , "Load_resets: 'R': ���~�X�f %d.", pReset->arg2 );

      break;
    }

    if ( !pArea->reset_first ) pArea->reset_first      = pReset;
    if (  pArea->reset_last  ) pArea->reset_last->next = pReset;

    pArea->reset_last = pReset;
    pReset->next      = NULL;
    top_reset++;
  }

  FCLOSE( pFile );
  RETURN_NULL();
}

void load_notes( void )
{
  NOTE_DATA * pnotelast;
  FILE      * fp;

  PUSH_FUNCTION( "load_notes" );

  if ( !( fp = FOPEN( note_file , "r" ) ) ) RETURN_NULL();

  for ( pnotelast = NULL;; )
  {
    NOTE_DATA * pnote;
    char        letter;

    do
    {
      letter = getc( fp );
      if ( feof(fp) )
      {
        FCLOSE( fp );
        RETURN_NULL();
      }
    }
    while ( isSpace(letter) );
    ungetc( letter, fp );

    pnote = alloc_struct( STRUCT_NOTE_DATA );

    if ( str_cmp( fread_word( fp ), "sender" ) )  break;
    pnote->sender     = fread_string( fp );

    if ( str_cmp( fread_word( fp ), "date" ) )    break;
    pnote->date       = fread_string( fp );

    if ( str_cmp( fread_word( fp ), "stamp" ) )   break;
    pnote->date_stamp = fread_number( fp );

    if ( str_cmp( fread_word( fp ), "to" ) )      break;
    pnote->to_list    = fread_string( fp );

    if ( str_cmp( fread_word( fp ), "subject" ) ) break;
    pnote->subject    = fread_string( fp );

    if ( str_cmp( fread_word( fp ), "text" ) )    break;
    pnote->text       = fread_string( fp );

    if ( !note_list ) note_list       = pnote;
    else              pnotelast->next = pnote;

    pnotelast = pnote;
  }

  mudlog( LOG_DEBUG , "Load_notes: ���~������r." );
}

void load_joke( const char * path )
{
  glob_t      result;
  int         rc;
  int         count;
  FILE      * pFile;
  JOKE_DATA * pJoke;
  JOKE_DATA * zJoke;
  char        directory[ MAX_FILE_LENGTH ];
  char        buf[ MAX_FILE_LENGTH ];

  PUSH_FUNCTION( "load_joke" );

  /* �B�z�ؿ� */
  fill_path( strcpy( directory, path ) );

  if ( ( rc = glob_file( directory, joke_ext, &result ) ) >= 0 )
  {
    for ( count = 0; count < rc; count++ )
    {
      sprintf( buf, "%s%s", directory, result.gl_pathv[count] );

      if ( is_regular( buf ) )
      {
        if ( !( pFile = FOPEN( buf , "r" ) ) )
          mudlog( LOG_ERR , "�}�ү����� %s �����D" , buf );

        set_joke_default( pJoke = alloc_struct( STRUCT_JOKE_DATA ) );
        load_a_joke( pJoke, pFile );
        pJoke->stamp = ++top_joke;

        if ( !joke_list )
        {
          joke_list = pJoke;
        }

        else
        {
          for ( zJoke = joke_list; zJoke->next; zJoke = zJoke->next );
          zJoke->next = pJoke;
        }

        FCLOSE( pFile );
      }

    }
    globfree( &result );
  }

  else
  {
    mudlog( LOG_ERR , "load_joke: �S�����ܤl�ؿ�" );
  }

  mudlog( LOG_INFO , "�t�θ��J %d �ӯ�����." , top_joke );
  RETURN_NULL();
}

void load_a_joke( JOKE_DATA * pJoke, FILE * pFile )
{
  char * word;
  bool   fMatch;

  PUSH_FUNCTION( "load_a_joke" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pJoke->title || !*pJoke->title )
          mudlog( LOG_DEBUG , "load_a_joke: �ʥF���D." );

        if ( !pJoke->org )
          mudlog( LOG_DEBUG, "load_a_joke: �ʥF�X�B." );

        if ( !pJoke->text || !*pJoke->text )
          mudlog( LOG_DEBUG , "load_a_joke: �ʥF����." );

        RETURN_NULL();
      }

      break;

    case 'O':
      KEY( "Org", pJoke->org, fread_string( pFile ) );
      break;

    case 'T':

      KEY( "Title", pJoke->title, fread_string( pFile ) );

      if ( !str_cmp( word, "Text" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pJoke->text = fread_string( pFile );

        fMatch = TRUE;
        break;
      }
      break;

    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_ERR , "Load_a_joke: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

void load_vote( const char * path )
{
  glob_t      result;
  int         rc;
  int         count;
  FILE      * pFile;
  VOTE_DATA * pVote;
  VOTE_DATA * zVote;
  char        directory[ MAX_FILE_LENGTH ];
  char        buf[ MAX_FILE_LENGTH ];

  PUSH_FUNCTION( "load_vote" );

  /* �B�z�ؿ� */
  fill_path( strcpy( directory, path ) );

  if ( ( rc = glob_file( directory, vote_ext, &result ) ) >= 0 )
  {
    for ( count = 0; count < rc; count++ )
    {
      sprintf( buf, "%s%s", directory, result.gl_pathv[count] );
      if ( is_regular( buf ) )
      {
        if ( !( pFile = FOPEN( buf , "r" ) ) )
          mudlog( LOG_ERR , "�}�ҧ벼�� %s �����D" , buf );

        set_vote_default( pVote = alloc_struct( STRUCT_VOTE_DATA ) );
        load_a_vote( pVote, pFile );

        if ( !vote_list )
        {
          vote_list = pVote;
        }

        else
        {
          for ( zVote = vote_list; zVote->next; zVote = zVote->next );
          zVote->next = pVote;
        }

        FCLOSE( pFile );
        top_vote++;
      }
    }
    globfree( &result );
  }
  else
  {
    mudlog( LOG_ERR , "load_vote: �S���벼�l�ؿ�" );
  }

  mudlog( LOG_INFO , "�t�θ��J %d �ӧ벼��." , top_vote );
  RETURN_NULL();
}

void load_a_vote( VOTE_DATA * pVote, FILE * pFile )
{
  char * word;
  bool   fMatch;

  PUSH_FUNCTION( "load_a_vote" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'B':
      if ( !str_cmp( word, "Ballot" ) )
      {
        int    loop;
        int    choice;
        char * name;

        choice = fread_number( pFile );
        name   = fread_string( pFile );
        choice = UMAX( 0, UMIN( MAX_VOTES - 1, choice ) );

        for ( loop = 0; loop < MAX_POLL; loop++ )
        {
          if ( !pVote->poller[loop] || *( pVote->poller[loop] ) == '\x0' )
          {
            pVote->poller[loop] = str_dup( name );
            pVote->vote[loop]   = choice;
            pVote->poll[choice]++;
            break;
          }
        }

        free_string( name );
        fMatch = TRUE;
        break;
      }
      break;

    case 'C':
      KEY( "Club", pVote->club, fread_string( pFile ) );
      break;

    case 'D':
      KEY( "Date", pVote->date, fread_string( pFile ) );
      KEY( "Days", pVote->days, fread_number( pFile ) );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        RETURN_NULL();
      }

      break;

    case 'L':
      KEY( "Level", pVote->level, fread_number( pFile ) );
      KEY( "Lock",  pVote->lock , fread_number( pFile ) );
      break;

    case 'M':
      KEY( "Moninal", pVote->moninal, fread_number( pFile ) );
      break;

    case 'P':
      KEY( "Poster", pVote->poster, fread_string( pFile ) );
      break;

    case 'S':
      KEY( "Subject", pVote->subject, fread_string( pFile ) );
      KEY( "Stamp"  , pVote->stamp,   fread_number( pFile ) );
      break;

    case 'T':

      if ( !str_cmp( word, "Text" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pVote->text = fread_string( pFile );

        fMatch = TRUE;
        break;
      }
      break;

    case 'V':

      if ( !str_cmp( word, "Vote" ) )
      {
        int choice;

        choice = fread_number( pFile );
        choice = UMAX( 0, UMIN( MAX_VOTES - 1, choice ) );
        pVote->message[choice] = fread_string( pFile );
        fMatch = TRUE;
        break;
      }
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_ERR , "Load_a_vote: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

void load_mobprogs( FILE * fp )
{
  MOB_INDEX_DATA * iMob;
  MPROG_DATA     * original;
  MPROG_DATA     * working;
  char             letter;
  int              value;

  PUSH_FUNCTION( "load_mobprogs" );

  for ( ;; )
  {
    switch ( letter = fread_letter( fp ) )
    {
    default:
      mudlog( LOG_ERR , "Load_mobprogs: ���~�R�O '%c'." , letter );

    case 'S':
    case 's':
      fread_to_eol( fp );
      RETURN_NULL();

    case '*':
      fread_to_eol( fp );
      break;

    case 'M':
    case 'm':
      value = fread_number( fp );

      if ( !( iMob = get_mob_index( value ) ) )
        mudlog( LOG_ERR , "Load_mobprogs: �Ǫ����X %d �ä��s�b.", value );

      if ( ( original = iMob->mobprogs ) )
        for ( ; original->next; original = original->next);

      /* �t�m�O���� */
      working = alloc_struct( STRUCT_MPROG_DATA );

      if ( original ) original->next = working;
      else            iMob->mobprogs = working;

      working = mprog_file_read( fread_word( fp ) , working , iMob );
      working->next = NULL;
      fread_to_eol( fp );
      break;
    }
  }
  RETURN_NULL();
}

void load_symbol( char * filename )
{
  SYMBOL_DATA * pSymbol;
  FILE        * fp;
  char        * word;
  int           letter;
  int           count = 0;
  int           iLen;

  PUSH_FUNCTION( "load_symbol" );

  if ( !( fp = FOPEN( filename , "r" ) ) )
    mudlog( LOG_ERR , "�L�k�}�ұ`���ഫ�� %s" , filename );

  for ( ; ; )
  {
    word = fread_word( fp );
    if ( feof( fp ) ) break;

    /* symbol.def �C��H*���}�Y�������@�O�аO���|Ū�� */
    if ( word[0] == '*' )
    {
      fread_to_eol( fp );
      continue;
    }

    /* symbol.def �Y�O�X�{ #END �h�N���ɮ׵����M���᪺���|�AŪ�� */
    if ( !str_cmp( word , "#END" ) ) break;

    /* �t�m�O���� */
    pSymbol = alloc_struct( STRUCT_SYMBOL_DATA );

    pSymbol->str = str_dup( word );
    pSymbol->num = fread_number( fp );
    count++;

    if ( !isalpha( pSymbol->str[0] ) )
      mudlog( LOG_ERR , "Load_symbol: %s ���O�^��Ÿ�" , pSymbol->str );

    letter                    = LOWER( pSymbol->str[0] ) - 'a';
    iLen                      = UMIN( 19, str_len( pSymbol->str ) - 1 );
    pSymbol->next             = symbol_hash[letter][iLen];
    symbol_hash[letter][iLen] = pSymbol;
  }

  FCLOSE( fp );
  mudlog( LOG_INFO , "�t�θ��J %d �ӱ`�ƲŸ�." , count );
  RETURN_NULL();
}

void load_help( char * path )
{
  glob_t      result;
  int         rc;
  int         count;
  HELP_DATA * pHelp;
  FILE      * pFile;
  char        directory[ MAX_FILE_LENGTH ];
  char        buf[ MAX_FILE_LENGTH ];

  PUSH_FUNCTION( "load_help" );

  /* �B�z�ؿ� */
  fill_path( strcpy( directory, path ) );

  if ( ( rc = glob_file( directory, help_ext, &result ) ) >= 0 )
  {
    for ( count = 0; count < rc; count++ )
    {
      sprintf( buf, "%s%s", directory, result.gl_pathv[count] );

      /* ���ɦW�� hlp ���ɮ� */
      if ( is_regular( buf ) )
      {
        if ( !( pFile = FOPEN( buf , "r" ) ) )
          mudlog( LOG_ERR , "�}�ҨD�U�� %s �����D" , buf );

        pHelp          = alloc_struct( STRUCT_HELP_DATA );
        pHelp->level   = fread_number( pFile );
        pHelp->keyword = fread_string( pFile );
        pHelp->text    = fread_string( pFile );

        if ( !help_first ) help_first      = pHelp;
        if (  help_last  ) help_last->next = pHelp;

        help_last   = pHelp;
        pHelp->next = NULL;

        FCLOSE( pFile );
        top_help++;
      }
    }
    globfree( &result );
  }

  else
  {
    mudlog( LOG_ERR , "�S���D�U�l�ؿ�" );
  }

  mudlog( LOG_INFO , "�t�θ��J %d �ӨD�U��." , top_help );
  RETURN_NULL();
}

void load_social( char * path , char * index )
{
  SOCIAL_DATA   * pSocial;
  FILE          * pFile;
  FILE          * aFile;
  char          * word;
  char            directory[ MAX_FILE_LENGTH ];
  char            indexfile[ MAX_FILE_LENGTH ];
  char            buf[ MAX_FILE_LENGTH ];

  PUSH_FUNCTION( "load_social" );

  /* �B�z�ؿ� */
  sprintf( directory , "%s" , path );
  fill_path( directory );

  sprintf( indexfile , "%s%s" , directory , index );

  if ( ( aFile = FOPEN( indexfile , "r" ) ) )
  {
    while ( !if_eof( aFile ) )
    {
      word = fread_word( aFile );
      fread_to_eol( aFile );

      sprintf( buf , "%s%c" , directory , LOWER( word[0] ) );
      fill_path( buf );
      str_cat( buf , word      );
      str_cat( buf, "."        );
      str_cat( buf, social_ext );

      if ( ( pFile = FOPEN( buf , "r" ) ) )
      {
        /* �t�m�O���� */
        pSocial = alloc_struct( STRUCT_SOCIAL_DATA );

        pSocial->name          = fread_string( pFile );
        pSocial->chinese_name  = fread_string( pFile );
        pSocial->char_no_arg   = fread_string( pFile );
        pSocial->others_no_arg = fread_string( pFile );
        pSocial->char_found    = fread_string( pFile );
        pSocial->others_found  = fread_string( pFile );
        pSocial->vict_found    = fread_string( pFile );
        pSocial->char_auto     = fread_string( pFile );
        pSocial->others_auto   = fread_string( pFile );

        if ( !social_first ) social_first      = pSocial;
        if (  social_last  ) social_last->next = pSocial;

        social_last   = pSocial;
        pSocial->next = NULL;
        top_social++;
        FCLOSE( pFile );
      }

      else
      {
        mudlog( LOG_ERR , "�L�k�}�_����ʰ��� %s." , buf );
      }
    }
  }
  else
  {
    mudlog( LOG_ERR , "�L�k�}�Ҫ�������� %s" , indexfile );
  }

  FCLOSE( aFile );
  mudlog( LOG_INFO , "�t�θ��J %d �Ӫ���ʧ@��." , top_social );
  RETURN_NULL();
}

void load_angel( const char * path )
{
  glob_t       result;
  int          rc;
  int          count;
  ANGEL_DATA * pAngel;
  FILE       * pFile;
  char         directory[ MAX_FILE_LENGTH ];
  char         buf[ MAX_FILE_LENGTH ];

  PUSH_FUNCTION( "load_angel" );

  /* �B�z�ؿ� */
  fill_path( strcpy( directory, path ) );

  if ( ( rc = glob_file( directory, angel_ext, &result ) ) >= 0 )
  {
    for ( count = 0; count < rc; count++ )
    {
      sprintf( buf, "%s%s", directory, result.gl_pathv[count] );
      if ( is_regular( buf ) )
      {
        if ( !( pFile = FOPEN( buf , "r" ) ) )
          mudlog( LOG_ERR , "�}�Ҧu�@���� %s �����D" , buf );

        pAngel       = load_a_angel( pFile );
        pAngel->next = angel_list;
        angel_list   = pAngel;

        FCLOSE( pFile );
        top_angel++;
      }
    }
    globfree( &result );
  }

  else
  {
    mudlog( LOG_ERR , "�S���u�@���l�ؿ�" );
  }

  mudlog( LOG_INFO , "�t�θ��J %d �Ӧu�@�������." , top_angel );
  RETURN_NULL();
}

/* Ū���@�Ӧu�@����� */
ANGEL_DATA * load_a_angel( FILE * pFile )
{
  ANGEL_DATA * pAngel;
  char       * word;
  bool         fMatch;

  PUSH_FUNCTION( "load_a_angel" );

  /* �t�m�O����H�γ]�w�w�]�� */
  set_angel_default( pAngel = alloc_struct( STRUCT_ANGEL_DATA ) );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'D':

      if ( !str_cmp( word , "Description" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pAngel->description = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( pAngel->description && pAngel->function )
          mudlog( LOG_DEBUG, "load_a_angel: �u�@������ƤS���y�z." );

        if ( !pAngel->description && !pAngel->function )
          mudlog( LOG_DEBUG, "load_a_angel: �u�@���S����ƤS�S���y�z." );

        RETURN( pAngel );
      }

      break;

    case 'F':

      if ( !str_cmp( word , "Function" ) )
      {
        char      * name;
        ANGEL_FUN * function;

        name = fread_string( pFile );

        if ( name[0] )
        {
          if ( !( function = angel_function( name ) ) )
            mudlog( LOG_DEBUG , "�u�@������� %s �䤣��" , name );

          free_string( name );
          pAngel->function = function;
        }

        fMatch = TRUE;
        break;
      }
      break;

    case 'H':

      if ( !str_cmp( word, "Higher" ) )
      {
        int level;

        if ( ( level = fread_number( pFile ) ) < 0 || level > MAX_LEVEL )
          mudlog( LOG_DEBUG, "load_a_angel: �u�@�̰����� %d ����.", level );

        pAngel->higher = level;
        fMatch = TRUE;
        break;
      }

      break;

    case 'L':

      if ( !str_cmp( word, "Lower" ) )
      {
        int level;

        if ( ( level = fread_number( pFile ) ) < 0 || level > MAX_LEVEL )
          mudlog( LOG_DEBUG, "load_a_angel: �u�@�̧C���� %d ����.", level );

        pAngel->lower = level;
        fMatch = TRUE;
        break;
      }

      break;

    case 'P':

      if ( !str_cmp( word, "Position" ) )
      {
        int position;

        switch( ( position = fread_number( pFile ) ) )
        {
        default:
           mudlog( LOG_DEBUG, "load_a_angel: �u�@���A����.", position );

        case POS_DEAD:
        case POS_SLEEPING:
        case POS_RESTING:
        case POS_FIGHTING:
        case POS_STANDING:
          break;
        }

        pAngel->position = position;
        fMatch = TRUE;
        break;
      }

      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_a_angel: �R�O %s �����T." , word );
  }

  RETURN( NULL );
}

/* ���J�i���e�� */
void load_welcome_immortal( char * filename )
{
  FILE * pFile;

  PUSH_FUNCTION( "load_welcome_immortal" );

  if ( !( pFile = FOPEN( filename , "r" ) ) )
    mudlog( LOG_ERR , "�}���w�ﯫ�ڵe���� %s �����D" , filename );

  welcome_immortal = fread_string( pFile );

  FCLOSE( pFile );
  RETURN_NULL();
}

/* ���J�i���e�� */
void load_welcome( char * filename )
{
  FILE * pFile;

  PUSH_FUNCTION( "load_welcome" );

  if ( !( pFile = FOPEN( filename , "r" ) ) )
    mudlog( LOG_ERR , "�}���w��e���� %s �����D" , filename );
  welcome_message = fread_string( pFile );
  FCLOSE( pFile );
  RETURN_NULL();
}

/* ���J�i���e�� */
void load_greeting( char * path )
{
  glob_t  result;
  int     rc;
  int     count;
  FILE  * pFile;
  char    directory[ MAX_FILE_LENGTH ];
  char    buf[ MAX_FILE_LENGTH ];

  PUSH_FUNCTION( "load_greeting" );

  /* �B�z�ؿ� */
  fill_path( strcpy( directory, path ) );

  if ( ( rc = glob_file( directory, greet_ext, &result ) ) >= 0 )
  {
    for ( count = 0; count < rc; count++ )
    {
      sprintf( buf, "%s%s", directory, result.gl_pathv[count] );

      if ( is_regular( buf ) )
      {
        if ( !( pFile = FOPEN( buf , "r" ) ) )
          mudlog( LOG_ERR , "�}�Ҷi���e���� %s �����D" , buf );

        greeting_table[top_greeting++] = fread_string( pFile );

        if ( top_greeting >= MAX_GREETING )
          mudlog( LOG_ERR , "�i���e���ӼƶW�L�t�Ωw�q��" );

        FCLOSE( pFile );
      }
    }
    globfree( &result );
  }

  else
  {
    mudlog( LOG_ERR , "�S���i���e���l�ؿ�" );
  }

  mudlog( LOG_INFO , "�t�θ��J %d �Ӷi���e����." , top_greeting );
  RETURN_NULL();
}

/* ���J�a�θ���ɮ�, ���ɦW�� def */
void load_sector( char * path )
{
  glob_t        result;
  int           rc;
  int           count;
  FILE        * pFile;
  char        * word;
  SECTOR_DATA * pSector;
  char          directory[ MAX_FILE_LENGTH ];
  char          buf[ MAX_FILE_LENGTH ];
  bool          fMatch;
  bool          finish;
  int           vnum;

  PUSH_FUNCTION( "load_sector" );

  /* �B�z�ؿ� */
  fill_path( strcpy( directory, path ) );

  if ( ( rc = glob_file( directory, sector_ext, &result ) ) >= 0 )
  {
    for ( count = 0; count < rc; count++ )
    {
      sprintf( buf, "%s%s", directory, result.gl_pathv[count] );

      if ( is_regular( buf ) )
      {
        if ( !( pFile = FOPEN( buf , "r" ) ) )
          mudlog( LOG_ERR , "�}�Ҧa���ɮ� %s �����D" , buf );

        pSector = alloc_struct( STRUCT_SECTOR_DATA );
        set_sector_default( pSector );

        for ( finish = FALSE; finish != TRUE; )
        {
          word   = if_eof( pFile ) ? "End" : fread_word( pFile );
          fMatch = FALSE;

          switch ( UPPER( word[0] ) )
          {
          /* ���� */
          case '*':
            fMatch = TRUE;
            fread_to_eol( pFile );
            break;

          case 'D':

            if ( !str_cmp( word , "Dark" ) )
            {
              pSector->dark = ( fread_number( pFile ) == TRUE )
                              ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word, "Default" ) )
            {

              if ( fread_number( pFile ) == TRUE )
              {
                if ( DefaultSector )
                  mudlog( LOG_DEBUG, "load_sector: �w�]�a�έ���." );

                DefaultSector = pSector;
              }

              fMatch = TRUE;
              break;
            }
            break;

          case 'E':

            if ( !str_cmp( word, "End" ) )
            {
              if ( IS_ERROR( pSector->vnum ) )
                mudlog( LOG_DEBUG , "load_sector: �a���ɮרS���s��" );

              if ( IS_ERROR( pSector->movement ) )
                mudlog( LOG_DEBUG , "load_sector: �a���ɮרS�����ʮ��Ӽƭ�" );

              if ( !pSector->cname )
                mudlog( LOG_DEBUG , "load_sector: �a���ɮרS������W��" );

              pSector->next = sector_list;
              sector_list   = pSector;

              top_sector++;
              fMatch = TRUE;
              finish = TRUE;
              break;
            }
            break;

          case 'F':

            KEY( "Flags", pSector->flags, fread_number( pFile ) );
            break;

          case 'M':

            KEY( "Movement", pSector->movement, fread_number( pFile ) );
            break;

          case 'N':

            KEY( "Name" , pSector->cname , fread_string( pFile ) );
            break;

          case 'V':

            if ( !str_cmp( word , "Vnum" ) )
            {
              if ( get_sector_index( ( vnum = fread_number( pFile ) ) ) )
                mudlog( LOG_DEBUG , "load_sector: �s�� %d ���a�����X����"
                  , vnum );

              if ( vnum < 0 )
                mudlog( LOG_DEBUG , "load_sector: �s�� %d ���a���ɮת��s�����X�k"
                  , vnum );

              pSector->vnum = vnum;
              fMatch = TRUE;
              break;
            }

            break;
          }

          /* ���O���A���~ */
          if ( !fMatch )
            mudlog( LOG_DEBUG , "Load_sector: �R�O %s �����T." , word );
        }

        FCLOSE( pFile );
      }
    }
    globfree( &result );
  }

  else
  {
    mudlog( LOG_ERR , "�S���a�θ�ƪ��l�ؿ�" );
  }

  if ( !DefaultSector ) mudlog( LOG_ERR, "load_sector: �S���w�]�a��." );

  mudlog( LOG_INFO , "�t�θ��J %d �Ӧa�θ����." , top_sector );
  RETURN_NULL();
}

/* ���J¾�~����ɮ�, ���ɦW�� def */
void load_class( char * path )
{
  glob_t       result;
  int          rc;
  int          count;
  CLASS_DATA * pClass;
  FILE       * pFile;
  char       * word;
  char         directory[ MAX_FILE_LENGTH ];
  char         buf[ MAX_FILE_LENGTH ];
  int          amount;
  bool         fMatch;
  bool         finish;

  PUSH_FUNCTION( "load_class" );

  /* �B�z�ؿ� */
  fill_path( strcpy( directory, path ) );

  if ( ( rc = glob_file( directory, class_ext, &result ) ) >= 0 )
  {
    for ( count = 0; count < rc; count++ )
    {
      sprintf( buf, "%s%s", directory, result.gl_pathv[count] );

      if ( is_regular( buf ) )
      {
        if ( !( pFile = FOPEN( buf , "r" ) ) )
          mudlog( LOG_ERR , "�}��¾�~�ɮ� %s �����D" , buf );

        pClass = alloc_struct( STRUCT_CLASS_DATA );
        set_class_default( pClass );

        for ( finish = FALSE; finish != TRUE; )
        {
          word   = if_eof( pFile ) ? "End" : fread_word( pFile );
          fMatch = FALSE;

          switch ( UPPER( word[0] ) )
          {
          /* ���� */
          case '*':
            fMatch = TRUE;
            fread_to_eol( pFile );
            break;

          case 'A':
            KEY( "Associate", pClass->associate, fread_number( pFile ) );
            break;

          case 'C':
            KEY( "Cname", pClass->cname , fread_string( pFile ) );

            if ( !str_cmp( word , "Conmax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(       0, amount );
              amount = UMIN( MaxCon, amount );
              pClass->attr[CON_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Confactor" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->factor[CON_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "ConDefaultMax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->max_default[CON_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "ConDefaultMin" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->min_default[CON_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            break;

          case 'D':

            if ( !str_cmp( word , "Dexmax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(       0, amount );
              amount = UMIN( MaxDex, amount );
              pClass->attr[DEX_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Dexfactor" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->factor[DEX_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "DexDefaultMax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->max_default[DEX_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "DexDefaultMin" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->min_default[DEX_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            break;

          case 'E':
            if ( !str_cmp( word , "End" ) )
            {
              if ( IS_ERROR( pClass->vnum ) )
                mudlog( LOG_DEBUG , "load_class: ¾�~�ɨS���s��." );

              if ( !pClass->name )
                mudlog( LOG_DEBUG, "load_class: ¾�~�ɨS���^��W��." );

              if ( !pClass->cname )
                mudlog( LOG_DEBUG, "load_class: ¾�~�ɨS������W��." );

              if ( !pClass->title )
                mudlog( LOG_DEBUG, "load_class: ¾�~�ɨS�����Y." );

              if ( pClass->limit > 0 && !pClass->msg_limit )
                mudlog( LOG_DEBUG, "load_class: ¾�~�ɨS������ԭz." );

              if ( pClass->multiplier <= 1 )
                mudlog( LOG_DEBUG, "load_class: ¾�~�ɷ������Ƥ��X�z." );

              if ( pClass->nskill <= 0 )
                mudlog( LOG_DEBUG, "load_class: ¾�~�ɪ��ޯ��`�Ƥ��X�z." );

              pClass->next = class_list;
              class_list   = pClass;

              if ( ++top_class > MAX_CLASS )
                mudlog( LOG_DEBUG, "load_class: ¾�~�ƥؤӦh%d.", top_class );

              fMatch = TRUE;
              finish = TRUE;
              break;
            }
            break;

          case 'F':

            if ( !str_cmp( word, "Force" ) )
            {
              pClass->force = fread_number( pFile ) == FALSE ? FALSE : TRUE;
              fMatch = TRUE;
              break;
            }

            break;

          case 'H':

            if ( !str_cmp( word , "HeroCon" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->hero[CON_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "HeroStr" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->hero[STR_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "HeroInt" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->hero[INT_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "HeroWis" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->hero[WIS_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "HeroDex" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->hero[DEX_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            break;

          case 'I':

            if ( !str_cmp( word , "Intmax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(       0, amount );
              amount = UMIN( MaxInt, amount );
              pClass->attr[INT_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Intfactor" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->factor[INT_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "IntDefaultMax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->max_default[INT_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "IntDefaultMin" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->min_default[INT_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            break;

          case 'L':

            KEY( "Lowerlimit", pClass->low_rebirth, fread_number( pFile ) );
            KEY( "LimitMsg"  , pClass->msg_limit  , fread_string( pFile ) );
            KEY( "Limit"     , pClass->limit      , fread_number( pFile ) );
            break;

          case 'M':

            KEY( "Multiplier", pClass->multiplier, fread_number( pFile ) );

            if ( !str_cmp( word , "Mana" ) )
            {
              pClass->fMana = fread_number( pFile ) == TRUE
                ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }
            break;

          case 'N':
            KEY( "Name"  , pClass->name  , fread_string( pFile ) );
            KEY( "NSkill", pClass->nskill, fread_number( pFile ) );
            break;

          case 'R':

            KEY( "Rebirthwarn", pClass->warn , fread_number( pFile ) );

            if ( !str_cmp( word, "Rudiment" ) )
            {
              pClass->rudiment = fread_number( pFile ) == FALSE ? FALSE : TRUE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Rebirthgold" ) )
            {
              if ( ( amount = fread_number( pFile ) ) < 0 )
                mudlog( LOG_DEBUG , "load_class: �s�� %d ��¾�~�ɮת���¾�����X�k"
                  , amount );

              pClass->rebirth_gold = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word, "Rank" ) )
            {
              if ( ( amount = fread_number( pFile ) ) < 0
                || amount > MAX_LEVEL )
                mudlog( LOG_DEBUG, "load_class: �s�� %d �����Y���X�k", amount );

              if ( pClass->rank[amount] )
                mudlog( LOG_DEBUG, "load_class: �s�� %d �����Y���Ʃw�q.", amount );

              pClass->rank[amount] = str_dup( fread_word( pFile ) );
              fMatch = TRUE;
              break;
            }
            break;

          case 'S':

            if ( !str_cmp( word, "Select" ) )
            {
              pClass->select = fread_number( pFile ) == FALSE ? FALSE : TRUE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Strmax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(       0, amount );
              amount = UMIN( MaxStr, amount );
              pClass->attr[STR_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Strfactor" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->factor[STR_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "StrDefaultMax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->max_default[STR_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "StrDefaultMin" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->min_default[STR_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            break;

          case 'T':
            KEY( "Title", pClass->title, fread_string( pFile ) );
            break;

          case 'U':

            if ( !str_cmp( word, "UpperLimit" ) )
            {
              if ( ( amount = fread_number( pFile ) ) > MAX_LEVEL )
                mudlog( LOG_DEBUG , "�s�� %d ��¾�~�ɮת��W�����Ť��X�k"
                 , amount );

              pClass->high_rebirth = amount;
              fMatch = TRUE;
              break;
            }
            break;

          case 'V':

            if ( !str_cmp( word , "Vnum" ) )
            {
              if ( class_lookup( amount = fread_number( pFile ) ) )
                mudlog( LOG_DEBUG , "�s�� %d ��¾�~���X����" , amount );

              if ( amount < 0 )
                mudlog( LOG_DEBUG , "�s�� %d ��¾�~�ɮת��s�����X�k"
                  , amount );

              pClass->vnum = amount;
              fMatch = TRUE;
              break;
            }

          case 'W':

            if ( !str_cmp( word , "Wismax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(       0, amount );
              amount = UMIN( MaxWis, amount );
              pClass->attr[WIS_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Wisfactor" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->factor[WIS_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "WisDefaultMax" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->max_default[WIS_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "WisDefaultMin" ) )
            {
              amount = fread_number( pFile );
              amount = UMAX(   0, amount );
              amount = UMIN( 100, amount );
              pClass->min_default[WIS_ITEM] = amount;
              fMatch = TRUE;
              break;
            }

            break;

          }

          /* ���O���A���~ */
          if ( !fMatch )
            mudlog( LOG_DEBUG , "Load_class: �R�O %s �����T." , word );
        }

        FCLOSE( pFile );
      }
    }
    globfree( &result );

    /* ��M�w�]��¾�~ */
    for ( amount = 0, class_force = class_demos = NULL, pClass = class_list;
      pClass;
      pClass = pClass->next )
    {
      if ( pClass->select ) iClass[amount++] = pClass;

      if ( pClass->rudiment )
      {
        if ( class_demos ) mudlog( LOG_ERR, "load_class: �w�]¾�~ %d ����."
          , pClass->vnum );
        class_demos = pClass;
      }

      if ( pClass->force )
      {
        if ( class_force ) mudlog( LOG_ERR, "load_class: �j��¾�~ %d ����."
          , pClass->vnum );
        class_force = pClass;
      }
    }

    if ( !class_demos ) mudlog( LOG_ERR, "�S���w�]��¾�~." );
    if ( !class_force ) mudlog( LOG_ERR, "�S���j�¾�~." );
    if ( amount <= 0  ) mudlog( LOG_ERR, "�S����ܪ�¾�~." );
  }

  else
  {
    mudlog( LOG_ERR , "�S��¾�~��ƪ��l�ؿ�" );
  }

  mudlog( LOG_INFO , "�t�θ��J %d ��¾�~�����." , top_class );
  RETURN_NULL();
}

/* ���J�G�����ɮ�, ���ɦW�� def */
void load_liq( char * path )
{
  glob_t     result;
  int        rc;
  int        count;
  LIQ_DATA * pLiq;
  FILE     * pFile;
  char     * word;
  char       directory[ MAX_FILE_LENGTH ];
  char       buf[ MAX_FILE_LENGTH ];
  bool       fMatch;
  bool       finish;

  PUSH_FUNCTION( "load_liq" );

  /* �B�z�ؿ� */
  fill_path( strcpy( directory, path ) );

  if ( ( rc = glob_file( directory, liquid_ext, &result ) ) >= 0 )
  {
    for ( count = 0; count < rc; count++ )
    {
      sprintf( buf, "%s%s", directory, result.gl_pathv[count] );

      if ( is_regular( buf ) )
      {
        if ( !( pFile = FOPEN( buf , "r" ) ) )
          mudlog( LOG_ERR , "�}�ҲG���ɮ� %s �����D" , buf );

        set_liq_default( pLiq = alloc_struct( STRUCT_LIQ_DATA ) );

        for ( finish = FALSE; finish != TRUE; )
        {
          word   = if_eof( pFile ) ? "End" : fread_word( pFile );
          fMatch = FALSE;

          switch ( UPPER( word[0] ) )
          {
          /* ���� */
          case '*':
            fMatch = TRUE;
            fread_to_eol( pFile );
            break;

          case 'C':
            KEY( "Color" , pLiq->color , fread_string( pFile ) );
            break;

          case 'D':
            KEY( "Drunk" , pLiq->drunk , fread_number( pFile ) );
            break;

          case 'E':
            if ( !str_cmp( word , "End" ) )
            {
              if ( !pLiq->name     ) mudlog( LOG_DEBUG, "�G���ɨS���W��" );
              if ( !pLiq->color    ) mudlog( LOG_DEBUG, "�G���ɨS���C��" );
              if ( pLiq->slot <= 0 ) mudlog( LOG_DEBUG, "�G��S���s��."  );

              pLiq->next = liq_list;
              liq_list   = pLiq;
              top_liq++;

              fMatch = TRUE;
              finish = TRUE;
              break;
            }
            break;

          case 'F':
            KEY( "Full" , pLiq->full , fread_number( pFile ) );
            break;

          case 'N':
            KEY( "Name" , pLiq->name , fread_string( pFile ) );
            break;

          case 'S':

            if ( !str_cmp( word, "Slot" ) )
            {
              if ( liq_lookup(  pLiq->slot = fread_number( pFile ) ) )
                mudlog( LOG_DEBUG, "�G��s�� %d ����.", pLiq->slot );

              fMatch = TRUE;
              break;
            }
            break;

          case 'T':
            KEY( "Thirst" , pLiq->thirst , fread_number( pFile ) );
            break;

          case 'W':

            if ( !str_cmp( word, "Water" ) )
            {
              pLiq->water = fread_number( pFile ) == FALSE ? FALSE : TRUE;
              fMatch = TRUE;
              break;
            }
            break;
          }

          /* ���O���A���~ */
          if ( !fMatch )
             mudlog( LOG_DEBUG , "Load_liq: �R�O %s �����T." , word );
        }

        FCLOSE( pFile );
      }
    }
    globfree( &result );

    /* ��M�������G�� */
    for ( liq_water = NULL, pLiq = liq_list; pLiq; pLiq = pLiq->next )
    {
      if ( pLiq->water )
      {
        if ( liq_water ) mudlog( LOG_ERR, "�G��� %d ����.", pLiq->slot );
        liq_water = pLiq;
      }
    }

    if ( !liq_water ) mudlog( LOG_ERR, "�S�������G��" );
  }

  else
  {
    mudlog( LOG_ERR , "�S���G���ƪ��l�ؿ�" );
  }

  mudlog( LOG_INFO , "�t�θ��J %d �ӲG������." , top_liq );
  RETURN_NULL();
}

void load_site( char * filename )
{
  BAN_DATA * pBan;
  FILE     * File;
  char     * word;
  int        ban_type;

  PUSH_FUNCTION( "load_site" );

  if ( !( File = FOPEN( filename , "r" ) ) )
    mudlog( LOG_ERR , "�L�k�}�ҸT��s�u�ɮ� %s" , filename );

  for ( ;; )
  {
    word = fread_word( File );
    if ( feof( File ) ) break;

    /* �C��H * ���}�Y�������@�O�аO���|Ū�� */
    if ( word[0] == '*' )
    {
      fread_to_eol( File );
      continue;
    }

    /* �Y�O�X�{ #END �h�N���ɮ׵����M���᪺���|�AŪ�� */
    if ( !str_cmp( word , "#END" ) ) break;

    switch( ( ban_type = fread_number( File ) ) )
    {
    default :
      mudlog( LOG_DEBUG , "���J��} %s ��T���~ %d." , word , ban_type );
      break;

    case BAN_LOGIN  :
    case BAN_FQDN   :
    case BAN_FINGER :
      break;
    }

    /* �t�m�O���� */
    pBan = alloc_struct( STRUCT_BAN_DATA );

    pBan->name = str_dup( word );
    pBan->type = ban_type;
    pBan->next = ban_list;
    ban_list   = pBan;
    mudlog( LOG_INFO , "�t�γ]�w %s ����}�X�� %d." , word , ban_type );
  }

  FCLOSE( File );
  RETURN_NULL();
}

void load_server( const char * filename )
{
  SERVER_DATA  * pServer;
  FILE         * File;
  char         * word;
  int            count;

  PUSH_FUNCTION( "load_server" );

  if ( !( File = FOPEN( filename , "r" ) ) )
    mudlog( LOG_ERR , "�L�k�}�Ҥu�@���ɮ� %s", filename );

  for ( count = 0; ; )
  {
    word = fread_word( File );
    if ( feof( File ) ) break;

    /* �C��H * ���}�Y�������@�O�аO���|Ū�� */
    if ( word[0] == '*' )
    {
      fread_to_eol( File );
      continue;
    }

    /* �Y�O�X�{ #END �h�N���ɮ׵����M���᪺���|�AŪ�� */
    if ( !str_cmp( word , "#END" ) ) break;

    /* �t�m�O���� */
    set_server_default( pServer = alloc_struct( STRUCT_SERVER_DATA ) );
    pServer->address = str_dup( word );
    pServer->next    = server_list;
    server_list      = pServer;
    count++;

  }

  FCLOSE( File );
  mudlog( LOG_INFO, "�t�γ]�w %d �Ӥu�@����}.", count );

  RETURN_NULL();
}

void load_xnames( char * filename )
{
  XNAMES_DATA * pXnames;
  FILE        * File;
  char        * word;
  int           count = 0;
  int           xnames_type;

  PUSH_FUNCTION( "load_xname" );

  if ( !( File = FOPEN( filename , "r" ) ) )
    mudlog( LOG_ERR , "�L�k�}�ҫO�d�r�ɮ� %s" , filename );

  for ( ;; )
  {
    word = fread_word( File );
    if ( feof( File ) ) break;

    /* symbol.def �C��H*���}�Y�������@�O�аO���|Ū�� */
    if ( word[0] == '*' )
    {
      fread_to_eol( File );
      continue;
    }

    /* �Y�O�X�{ #END �h�N���ɮ׵����M���᪺���|�AŪ�� */
    if ( !str_cmp( word , "#END" ) ) break;

    switch( ( xnames_type = fread_number( File ) ) )
    {
    default :
      mudlog( LOG_DEBUG , "���J�O�d�r %s ���~�X�� %d." , word , xnames_type );
      break;

    case XNAMES_SYSTEM  :
    case XNAMES_CACONYM :
    case XNAMES_CHAT    :
    case XNAMES_CNAME   :
      break;
    }

    /* �t�m�O���� */
    pXnames = alloc_struct( STRUCT_XNAME_DATA );

    pXnames->word = str_dup( word );
    pXnames->type = xnames_type;
    pXnames->next = xnames_first;
    xnames_first  = pXnames;
    count++;
  }

  mudlog( LOG_INFO , "�t�θ��J %d �ӫO�d�r." , count );
  FCLOSE( File );
  RETURN_NULL();
}

void load_skill( char * path , char * index )
{
  RESTRICT_DATA * pRestrict;
  SKILL_DATA  * pSkill;
  DAMAGE_DATA * pDam;
  FILE        * pFile;
  FILE        * aFile;
  char        * word;
  char          indexfile[ MAX_FILE_LENGTH ];
  char          buf[MAX_FILE_LENGTH];
  char          directory[ MAX_FILE_LENGTH ];
  bool          fMatch;
  bool          finish;

  PUSH_FUNCTION( "load_skill" );

  /* �B�z�ؿ� */
  str_cpy( directory , path );
  fill_path( directory );

  /* �B�z�����ɮצW�� */
  sprintf( indexfile , "%s%s" , directory , index );

  /* �}�ү����ɮ�, ����S���o���ɮ� */
  if ( ( pFile = FOPEN( indexfile , "r" ) ) )
  {
    /* �@��Ū�����ɮץ��� */
    while ( !if_eof( pFile ) )
    {
      /* Ū���R�O�ɮת��W�� */
      word = fread_word( pFile );
      fread_to_eol( pFile );

      /* �B�z���}�ҩR�O�ɮת��W�� */
      sprintf( buf , "%s%c/%s.%s"
        , directory , LOWER( word[0] ) , word, skill_ext );

      if ( ( aFile = FOPEN( buf , "r" ) ) )
      {
        /* �t�m�O���� */
        set_skill_default( pSkill = alloc_struct( STRUCT_SKILL_DATA ) );

        /* ���J�ޯ઺�D�{������ */
        for ( finish = FALSE; finish != TRUE; )
        {
          word   = if_eof( aFile ) ? "End" : fread_word( aFile );
          fMatch = FALSE;

          switch ( UPPER( word[0] ) )
          {
          /* ���� */
          case '*':
            fMatch = TRUE;
            fread_to_eol( aFile );
            break;

          case '#':

            if ( !str_cmp( word, "#DAMAGE" ) )
            {
              load_damage( pSkill, aFile );
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word, "#Restrict" ) )
            {
              /* ���J�ޯ୭�� */
              pRestrict = load_restrict( aFile );
              pRestrict->next  = pSkill->restrict;
              pSkill->restrict = pRestrict;
              fMatch = TRUE;
              break;
            }

            break;

          case 'A':

            KEY( "Associate" , pSkill->associate , fread_number( aFile ) );
            KEY( "Affect"    , pSkill->affect    , fread_number( aFile ) );
            KEY( "AffectID"  , pSkill->affect_id , fread_number( aFile ) );

            if ( !str_cmp( word, "AntiRating" ) )
            {
              switch( pSkill->antirating = fread_number( aFile ) )
              {
              default:
                mudlog( LOG_DEBUG ,
                  "Load_skill: �ޯ�۫g���� %d ���X�z" ,pSkill->antirating );

              case RATING_SKILL:
              case RATING_WIND:
              case RATING_EARTH:
              case RATING_LIGHTNING:
              case RATING_POISON:
              case RATING_FIRE:
              case RATING_WATER:
              case RATING_DARKNESS:
              case RATING_LIGHT:
              case RATING_SAINT:
              case RATING_EVIL:
              case RATING_LOST:
              case RATING_CURE:
              case RATING_SING:
              case RATING_FIGHT:
              case RATING_MURDER:
              case RATING_CREATE:
              case RATING_THIEF:
                break;

              }

              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Adeptation" ) )
            {
              if ( ( pSkill->adeptation = fread_number( aFile ) ) < 0
                || pSkill->adeptation > 100 )
                mudlog( LOG_DEBUG , "load_skill: ������m��%d���X�z."
                  , pSkill->adeptation );

              fMatch = TRUE;
              break;
            }

            break;

          case 'C':

            if ( !str_cmp( word , "Check" ) )
            {
              char      * name;
              CHECK_FUN * check;

              name = fread_string( aFile );

              if ( !( check = check_function_name( name ) ) )
                mudlog( LOG_DEBUG , "�ޯ��ɪ������� %s �䤣��" , name );

              free_string( name );
              pSkill->check = check;

              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Cname" ) )
            {
              SKILL_DATA * aSkill;
              char       * name;

              name = fread_string( aFile );
              for ( aSkill = skill_list; aSkill; aSkill = aSkill->next )
              {
                if ( !str_cmp( aSkill->cname , name ) )
                {
                  mudlog( LOG_DEBUG ,
                    "Load_skill: �ޯत��W�� %s ����." , name );
                }
              }

              pSkill->cname = name;
              fMatch        = TRUE;
              break;
            }

            if ( !str_cmp( word , "Concentration" ) )
            {
              pSkill->concentration = fread_number( aFile ) == TRUE
                                       ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "CanAsk" ) )
            {
              pSkill->canask = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Cast" ) )
            {
              pSkill->cast = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Costtype" ) )
            {
              int type;

              switch ( type = fread_number( aFile ) )
              {
              default:
                mudlog( LOG_DEBUG , "Load_skill: ���ӫ��A %d ���~.", type );

              case COST_HIT:
              case COST_MANA:
              case COST_MOVE:
              case COST_GOLD:
                break;
              }

              pSkill->cost_type = type;
              fMatch            = TRUE;
              break;
            }

            KEY( "Cost" , pSkill->cost , fread_number( aFile ) );
            break;

          case 'D':

            if ( !str_cmp( word , "Degree" ) )
            {
              int degree;

              degree = fread_number( aFile );
              if ( degree < 0 || degree > 1000 )
                mudlog( LOG_DEBUG ,
                  "Load_skill: %d" , degree );

              pSkill->degree = degree;
              fMatch         = TRUE;
              break;
            }

            break;

          case 'E':

            if ( !str_cmp( word , "Enable" ) )
            {
              pSkill->enable = fread_number( aFile ) == 1 ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word, "End" ) )
            {
              if ( IS_ERROR( pSkill->slot ) )
                mudlog( LOG_DEBUG, "Load_skill: �ޯ�S���s��." );

              if ( !pSkill->name )
                mudlog( LOG_DEBUG , "Load_skill: �ޯ�S���W��" );

              if ( !pSkill->cname )
                mudlog( LOG_DEBUG , "Load_skill: �ޯ�S������W��" );

              if ( pSkill->function && pSkill->damage )
                mudlog( LOG_DEBUG, "Load_skill: ����ƤS����˱ԭz." );

              if ( !pSkill->function && !pSkill->damage )
                mudlog( LOG_DEBUG , "Load_skill: �ޯ�S���ާ@���" );

              if ( ++top_skill >= MAX_SKILL )
                mudlog( LOG_DEBUG, "Load_skill: �ޯ�ƥضW�L�]�w" );

              if ( pSkill->innate && pSkill->adeptation <= 0 )
                mudlog( LOG_DEBUG, "Load_skill: ������o�S���m��." );

              /* �p����v�`�M */
              for ( pDam = pSkill->damage; pDam; pDam = pDam->next )
                pSkill->chance += pDam->chance;

              if ( !skill_list ) skill_list       = pSkill;
              if (  skill_last ) skill_last->next = pSkill;

              skill_last   = pSkill;
              pSkill->next = NULL;

              finish = TRUE;
              fMatch = TRUE;
              break;
            }

            KEY( "Exp" , pSkill->exp , fread_number( aFile ) );
            break;

          case 'F':

            if ( !str_cmp( word , "Function" ) )
            {
              char      * name;
              SPELL_FUN * function;

              name = fread_string( aFile );

              if ( name[0] )
              {
                if ( !( function = skill_function_name( name ) ) )
                  mudlog( LOG_DEBUG , "�ޯ��ɪ���� %s �䤣��" , name );

                free_string( name );
                pSkill->function = function;
              }

              fMatch = TRUE;
              break;
            }
            break;

          case 'H':

            KEY( "Help" , pSkill->help , fread_string( aFile ) );
            break;

          case 'I':

            if ( !str_cmp( word , "Innate" ) )
            {
              pSkill->innate = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

          case 'L':

            if ( !str_cmp( word , "Limit" ) )
            {
              int          iClass;
              LIMIT_DATA * pLimit;
              CLASS_DATA * pClass;

              pClass = class_lookup( iClass =fread_number( aFile ) );

              if ( !pClass )
                mudlog( LOG_DEBUG, "�ޯ��ɤ�¾�~ %d ���s�b", iClass );

              pLimit = alloc_struct( STRUCT_LIMIT_DATA );

              pLimit->class = pClass;
              pLimit->level = fread_number( aFile );
              pLimit->adept = fread_number( aFile );
              pLimit->next  = pSkill->limit;
              pSkill->limit = pLimit;

              fread_to_eol( aFile );
              fMatch = TRUE;
              break;
            }

            break;

          case 'M':

            KEY( "Msgoff", pSkill->msg_off, fread_string( aFile ) );

            if ( !str_cmp( word , "Message" ) )
            {
              char   buf[MAX_STRING_LENGTH];
              char * temp;
              char * pSource;
              char * pString;

              /* �@�w��Ū���@�� */
              fread_to_eol( aFile );
              pSource = temp = fread_string( aFile );

              if ( str_len( temp ) > sizeof( buf ) - 10 )
                mudlog( LOG_DEBUG, "load_skill: �T���Ӫ�" );

              /* ��������r�� */
              for ( pString = buf; *temp; temp++ )
              {
                switch( *temp )
                {
                default:
                  *pString++ = *temp;
                  break;

                case '\n': case '\r':
                  break;
                }
              }

              *pString = '\x0';
              pSkill->message = str_dup( buf );
              free_string( pSource );

              fMatch = TRUE;
              break;
            }

            break;

          case 'N':

            if ( !str_cmp( word , "Name" ) )
            {
              SKILL_DATA * aSkill;
              char       * name;

              name = fread_string( aFile );
              for ( aSkill = skill_list; aSkill; aSkill = aSkill->next )
              {
                if ( !str_cmp( aSkill->name , name ) )
                  mudlog( LOG_DEBUG, "Load_skill: �ޯ�W�� %s ����." , name );
              }

              pSkill->name = name;
              fMatch       = TRUE;
              break;
            }

            break;

          case 'P':

            KEY( "Ply", pSkill->ply, fread_number( aFile ) );

            if ( !str_cmp( word , "Position" ) )
            {
              int position;

              switch( position = fread_number( aFile ) )
              {
              default:
                mudlog( LOG_DEBUG ,
                  "Load_skill: �ޯ�̧C���A %d ���X�z" , position );

              case POS_DEAD:
              case POS_SLEEPING:
              case POS_RESTING:
              case POS_FIGHTING:
              case POS_STANDING:
                break;
              }

              pSkill->position = position;
              fMatch           = TRUE;
              break;
            }

            break;

          case 'Q':
            KEY( "Qutoient", pSkill->qutoient, fread_number( aFile ) );
            break;

          case 'R':

            if ( !str_cmp( word, "Rating" ) )
            {
              switch( pSkill->rating = fread_number( aFile ) )
              {
              default:
                mudlog( LOG_DEBUG ,
                  "Load_skill: �ޯ��ѧO���� %d ���X�z" ,pSkill->rating );

              case RATING_SKILL:
              case RATING_WIND:
              case RATING_EARTH:
              case RATING_LIGHTNING:
              case RATING_POISON:
              case RATING_FIRE:
              case RATING_WATER:
              case RATING_DARKNESS:
              case RATING_LIGHT:
              case RATING_SAINT:
              case RATING_EVIL:
              case RATING_LOST:
              case RATING_CURE:
              case RATING_SING:
              case RATING_FIGHT:
              case RATING_MURDER:
              case RATING_CREATE:
              case RATING_THIEF:
                break;

              }

              fMatch = TRUE;
              break;
            }

            break;

          case 'S':

            if ( !str_cmp( word , "Sayspell" ) )
            {
              pSkill->say_spell = fread_number( aFile ) == 1 ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word, "Slot" ) )
            {
              if ( ( pSkill->slot = fread_number( aFile ) ) >= MAX_SKILL
                || pSkill->slot < 0 )
                mudlog( LOG_DEBUG, "Load_skill: �ޯ�s�� %d ���X�z."
                  , pSkill->slot );

              if ( get_skill( pSkill->slot ) )
                mudlog( LOG_DEBUG , "Load_skill: �ޯ�s�� %d ����."
                  , pSkill->slot );

              fMatch = TRUE;
              break;
            }
            break;

          case 'T':

            if ( !str_cmp( word , "Teach" ) )
            {
              pSkill->teach = fread_number( aFile ) == 1 ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Type" ) )
            {
              int type;

              switch( type = fread_number( aFile ) )
              {
              default :
                mudlog( LOG_DEBUG , "Load_skill: �ޯ�κA %d ����" , type );

              case TAR_IGNORE:
              case TAR_CHAR_OFFENSIVE:
              case TAR_CHAR_DEFENSIVE:
              case TAR_CHAR_SELF:
              case TAR_OBJ_INV:
              case TAR_DODGE:
              case TAR_STRING:
              case TAR_FLEE:
              case TAR_ARGUMENT:
              case TAR_MEDITATION:
              case TAR_OBJ_ROOM:
              case TAR_MOUNT:
              case TAR_NO_CAST:
                break;
              }

              pSkill->type = type;
              fMatch       = TRUE;
              break;
            }

            break;

          case 'V':

            if ( !str_cmp( word , "Valid" ) )
            {
              pSkill->valid = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            break;

          case 'W':

            if ( !str_cmp( word , "Weapon" ) )
            {
              int weapon;

              switch( ( weapon = fread_number( aFile ) ) )
              {
              default:
                mudlog( LOG_DEBUG ,"Load_skill: �Z���κA %d ����", weapon );

              case WEAPON_ALL:
              case WEAPON_HAND:
              case WEAPON_DAGGER:
              case WEAPON_SWORD:
              case WEAPON_BLADE:
              case WEAPON_AXE:
              case WEAPON_WHIP:
              case WEAPON_SPEAR:
              case WEAPON_PEN:
              case WEAPON_HAMMER:
              case WEAPON_CLUB:
              case WEAPON_BOW:
              case WEAPON_FORCE:
                pSkill->weapon = weapon;
                fMatch         = TRUE;
                break;
              }

              break;
            }

            KEY( "Wait" , pSkill->wait , fread_number( aFile ) );
            break;
          }

          /* ���O���A���~ */
          if ( !fMatch )
            mudlog( LOG_DEBUG , "Load_skill: �R�O %s �����T." , word );
        }

        FCLOSE( aFile );
      }

      else
      {
        mudlog( LOG_ERR , "�L�k�}�ҧޯ��� %s" , buf );
      }
    }
  }

  else
  {
    mudlog( LOG_ERR , "�S���ޯ�ؿ��C��" );
  }

  FCLOSE( pFile );
  mudlog( LOG_INFO , "�t�θ��J %d �ӧޯ���." , top_skill );
  RETURN_NULL();
}


void load_damage( SKILL_DATA * pSkill, FILE * pFile )
{
  DAMAGE_DATA * pDamage;
  DAMAGE_DATA * zDamage;
  char        * word;
  bool          fMatch;

  PUSH_FUNCTION( "load_damage" );

  /* �t�m�оɩһݭn���O����H�γ]�w�w�]�� */
  pDamage = alloc_struct( STRUCT_DAMAGE_DATA );
  set_damage_default( pDamage );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0]) )
    {
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'C':

      KEY( "Chance", pDamage->chance, fread_number( pFile ) );
      break;

    case 'D':

      if ( !str_cmp( word , "Description" ) )
      {
        char   buf[MAX_STRING_LENGTH];
        char * temp;
        char * pSource;
        char * pString;

        /* �@�w��Ū���@�� */
        fread_to_eol( pFile );
        pSource = temp = fread_string( pFile );

        if ( str_len( temp ) > sizeof( buf ) - 10 )
          mudlog( LOG_DEBUG, "loa_damage: ��˴y�z�Ӫ�" );

        /* ��������r�� */
        for ( pString = buf; *temp; temp++ )
        {
          switch( *temp )
          {
          default:
            *pString++ = *temp;
            break;

          case '\n': case '\r':
            break;
          }
        }

        *pString = '\x0';
        pDamage->description = str_dup( buf );
        free_string( pSource );

        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pDamage->description )
          mudlog( LOG_DEBUG, "load_damage: ��˨S���ԭz." );

        if ( IS_ERROR( pDamage->chance ) || pDamage->chance <= 0 )
          mudlog( LOG_DEBUG, "load_damage: ��˨S�����v�Τ����T." );

        if ( IS_ERROR( pDamage->value )  || pDamage->value < 0 )
          mudlog( LOG_DEBUG, "loa_damage: ��˨S���ˮ`�ȩΤ����T." );

        /* ��M�̫�@�� */
        for ( zDamage = pSkill->damage;
              zDamage && zDamage->next;
              zDamage = zDamage->next );

        if ( !zDamage ) pSkill->damage = pDamage;
        else            zDamage->next  = pDamage;

        RETURN_NULL();
      }

      if ( !str_cmp( word, "Effect" ) )
      {
        EFFECT_DATA * pEffect;
        int           loop = 0;

        pEffect = alloc_struct( STRUCT_EFFECT_DATA );
        set_effect_default( pEffect );

        switch( ( pEffect->type = fread_number( pFile ) ) )
        {
        default:
          mudlog( LOG_DEBUG, "load_damage: �������A���~." );
          break;

        case EFFECT_VICTIM_MANA:
        case EFFECT_SELF_MANA:
        case EFFECT_VICTIM_MOVE:
        case EFFECT_SELF_MOVE:
        case EFFECT_VICTIM_BLINDNESS:
        case EFFECT_VICTIM_CURSE:
        case EFFECT_VICTIM_POISON:
        case EFFECT_VICTIM_SLEEP:
        case EFFECT_VICTIM_PARA:
        case EFFECT_VICTIM_FAERIE_FIRE:
          break;
        }

        while( loop < MAX_EFFECT_VALUE )
        {
          if ( fread_if_eol( pFile ) ) break;
          pEffect->value[loop++] = fread_number( pFile );
        }

        fread_to_eol( pFile );

        pEffect->next   = pDamage->effect;
        pDamage->effect = pEffect;

        fMatch             = TRUE;
        break;
      }
      break;

    case 'I':

      if ( !str_cmp( word, "Innate" ) )
      {
        pDamage->obj_vnum = fread_number( pFile );
        pDamage->multiple = fread_number( pFile );

        fMatch = TRUE;
        break;
      }

      break;

    case 'P':
      KEY( "Parry", pDamage->parry, fread_number( pFile ) );
      break;

    case 'R':

      if ( !str_cmp( word , "Routine" ) )
      {
        char        * name;
        ROUTINE_FUN * routine;

        name = fread_string( pFile );

        if ( name[0] )
        {
          if ( !( routine = check_routine_name( name ) ) )
            mudlog( LOG_DEBUG , "load_damage: �ޯ��ɪ���� %s �䤣��" , name );

          free_string( name );
          pDamage->routine = routine;
        }

        fMatch = TRUE;
        break;
      }
      break;

    case 'S':
      KEY( "Situs", pDamage->situs, fread_number( pFile ) );
      break;

    case 'V':
      KEY( "Value"    , pDamage->value    , fread_number( pFile ) );
      KEY( "ViceValue", pDamage->vicevalue, fread_number( pFile ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch ) mudlog( LOG_DEBUG , "Load_damage: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

void load_instrument( char * path , char * index )
{
  CMD_DATA * pCommand;
  FILE     * pFile;
  FILE     * aFile;
  char     * word;
  char       indexfile[ MAX_FILE_LENGTH ];
  char       buf[MAX_FILE_LENGTH];
  char       directory[ MAX_FILE_LENGTH ];
  bool       fMatch;
  bool       finish;

  PUSH_FUNCTION( "load_instrument" );

  /* �B�z�ؿ� */
  str_cpy( directory , path );
  fill_path( directory );

  /* �B�z�����ɮצW�� */
  sprintf( indexfile , "%s%s" , directory , index );

  /* �}�ү����ɮ�, ����S���o���ɮ� */
  if ( ( pFile = FOPEN( indexfile , "r" ) ) )
  {
    /* �@��Ū�����ɮץ��� */
    while ( !if_eof( pFile ) )
    {
      /* Ū���R�O�ɮת��W�� */
      word = fread_word( pFile );
      fread_to_eol( pFile );

      /* �B�z���}�ҩR�O�ɮת��W�� */
      sprintf( buf , "%s%c" , directory , LOWER( word[0] ) );

      fill_path( buf            );
      str_cat( buf, word        );
      str_cat( buf, "."         );
      str_cat( buf, command_ext );

      if ( ( aFile = FOPEN( buf , "r" ) ) )
      {
        /* �t�m�O���� */
        pCommand = alloc_struct( STRUCT_CMD_DATA );

        /* ���m�w�]�� */
        set_command_default( pCommand );

        /* ���J���O���D�{������ */
        for ( finish = FALSE; finish != TRUE; )
        {
          word   = if_eof( aFile ) ? "End" : fread_word( aFile );
          fMatch = FALSE;

          switch ( UPPER( word[0] ) )
          {
          /* ���� */
          case '*':
            fMatch = TRUE;
            fread_to_eol( aFile );
            break;

          case 'A':

            if ( !str_cmp( word , "Argument" ) )
            {
              pCommand->argument = fread_number( aFile ) == 1 ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            break;

          case 'C':

            if ( !str_cmp( word , "Canlock" ) )
            {
              pCommand->canlock = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Chat" ) )
            {
              pCommand->chat = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            KEY( "Cname" , pCommand->cname , fread_string( aFile ) );
            break;

          case 'D':

            if ( !str_cmp( word , "Dead" ) )
            {
              pCommand->dead = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            break;

          case 'E':

            if ( !str_cmp( word, "End" ) )
            {
              if ( !pCommand->name )
                mudlog( LOG_DEBUG , "���O�ɨS���W��" );

              if ( !pCommand->cname )
                mudlog( LOG_DEBUG , "���O�ɨS������W��" );

              if ( !pCommand->function )
                mudlog( LOG_DEBUG , "���O�ɨS��������" );

              if ( pCommand->lock ) pCommand->canlock = FALSE;

              if ( !cmd_list ) cmd_list       = pCommand;
              if (  cmd_last ) cmd_last->next = pCommand;

              cmd_last       = pCommand;
              pCommand->next = NULL;
              top_cmd++;
              finish = TRUE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Exact" ) )
            {
              pCommand->exact = fread_number( aFile ) == 1 ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            break;

          case 'F':

            if ( !str_cmp( word , "Function" ) )
            {
              char   * name;
              DO_FUN * function;

              name = fread_string( aFile );

              if ( !( function = command_function_name( name ) ) )
                mudlog( LOG_DEBUG , "���O�ɪ���� %s �䤣��" , name );

              free_string( name );
              pCommand->function = function;

              fMatch = TRUE;
              break;
            }
            break;

          case 'H':

            KEY( "Help" , pCommand->help , fread_string( aFile ) );
            break;

          case 'J':

            if ( !str_cmp( word , "Jail" ) )
            {
              pCommand->jail = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            break;

          case 'L':

            if ( !str_cmp( word , "Limit" ) )
            {
              pCommand->limit = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Lock" ) )
            {
              pCommand->lock = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            KEY( "Level" , pCommand->level , fread_number( aFile ) );

            if ( !str_cmp( word , "Lost" ) )
            {
              pCommand->lost = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            if ( !str_cmp( word , "Log" ) )
            {
              int log;

              switch( log = fread_number( aFile ) )
              {
              default:
                mudlog( LOG_DEBUG , "���O�ɪ��аO�ܼ� %d ���X�z" , log );

              case LOG_NORMAL:
              case LOG_ALWAYS:
              case LOG_NEVER:
              case LOG_WIZ:
                break;
              }

              pCommand->log = log;
              fMatch        = TRUE;
              break;
            }

            break;

          case 'M':

            if ( !str_cmp( word , "Mobonly" ) )
            {
              pCommand->mobonly = fread_number( aFile ) == 1 ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            break;

          case 'N':

            if ( !str_cmp( word , "Name" ) )
            {
              CMD_DATA * aCommand;

              pCommand->name = fread_string( aFile );

              for ( aCommand = cmd_list; aCommand; aCommand = aCommand->next )
              {
                if ( !str_cmp( aCommand->name , pCommand->name ) )
                  mudlog( LOG_DEBUG , "���O�ɫ��O %s ����.", pCommand->name );
              }

              fMatch = TRUE;
              break;
            }

          case 'O':

            if ( !str_cmp( word , "Order" ) )
            {
              pCommand->order = fread_number( aFile ) == TRUE ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            break;

          case 'P':

            if ( !str_cmp( word , "Position" ) )
            {
              int pos;

              switch( pos = fread_number( aFile ) )
              {
              default:
                mudlog( LOG_DEBUG ,"Load_skill: �ޯ�̧C���A %d ���X�z"
                  , pos );

              case POS_DEAD:
              case POS_SLEEPING:
              case POS_RESTING:
              case POS_FIGHTING:
              case POS_STANDING:
                break;
              }

              pCommand->position = pos;
              fMatch = TRUE;
              break;
            }

            break;

          case 'W':

            if ( !str_cmp( word , "Wizlog" ) )
            {
              pCommand->wizlog = fread_number( aFile ) == 1 ? TRUE : FALSE;
              fMatch = TRUE;
              break;
            }

            break;
          }

          /* ���O���A���~ */
          if ( !fMatch )
            mudlog( LOG_DEBUG , "Load_instrument: �R�O %s �����T." , word );
        }
        FCLOSE( aFile );
      }

      else
      {
        mudlog( LOG_ERR , "�L�k�}�ҩR�O�� %s" , buf );
      }
    }
  }

  else
  {
    mudlog( LOG_ERR , "�S���R�O�ؿ��C��" );
  }

  FCLOSE( pFile );
  mudlog( LOG_INFO , "�t�θ��J %d �ӫ��O��." , top_cmd );
  RETURN_NULL();
}

void load_internal( char * filename )
{
  NET_DATA * pNet;
  FILE     * pFile;
  char     * word;
  bool       fMatch;
  bool       Finish = FALSE;

  PUSH_FUNCTION( "load_internal" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Station" ) )
        {
          /* �t�m�O����åB�M�����w�]�� */
          set_station_default( pNet = alloc_struct( STRUCT_NET_DATA ) );

          /* ���J�ɮ� */
          load_station( pNet, pFile );

          /* �p�G�i�H���J */
          if ( pNet->valid ) init_client( pNet );
          else pNet->import = pNet->export = -2;

          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        if ( !str_cmp( word, "End" ) )
        {
          Finish = fMatch = TRUE;
          break;
        }
        break;

      case 'P':

        if ( !str_cmp( word , "Port" ) )
        {
          if ( ( internal_port = fread_number( pFile ) ) <= 1024
            || internal_port > 65000 )
          mudlog( LOG_ERR, "�A���q�T�� %d ���X�k.\n" , internal_port );

          fMatch = TRUE;
          break;
        }
        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "Load_internal: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J������ں��������" );
  }

  RETURN_NULL();
}

void load_station( NET_DATA * pNet, FILE * pFile )
{
  char * word;
  bool   fMatch;

  PUSH_FUNCTION( "load_station" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'A':

      if ( !str_cmp( word, "Address" ) )
      {
        pNet->address = str_dup( fread_word( pFile ) );

        /* �קK���ƪ���} */
        if ( get_net_data( pNet->address, NET_ADDRESS ) )
          mudlog( LOG_ERR, "load_station: ���} %s ����", pNet->address );

        fMatch = TRUE;
        break;
      }

      break;

    case 'C':

      if ( !str_cmp( word, "Cname" ) )
      {
        pNet->cname = str_dup( fread_word( pFile ) );
        fMatch = TRUE;
        break;
      }
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pNet->name    ) mudlog( LOG_ERR, "Load_station: �ʥF���W."   );
        if ( !pNet->address ) mudlog( LOG_ERR, "Load_station: �ʥF��}."   );
        if ( pNet->port < 0 ) mudlog( LOG_ERR, "Load_station: �ʥF�q�T��." );

        pNet->next = net_list;
        net_list   = pNet;

        RETURN_NULL();
      }

      break;

    case 'L':

      if ( !str_cmp( word, "Log" ) )
      {
        pNet->log = ( fread_number( pFile ) == FALSE ) ? FALSE : TRUE;
        fMatch = TRUE;
        break;
      }

      break;

    case 'N':

      if ( !str_cmp( word, "Name" ) )
      {
        pNet->name = str_dup( fread_word( pFile ) );

        /* �קK���ƪ����W */
        if ( get_net_data( pNet->name, NET_NAME ) )
          mudlog( LOG_ERR, "load_station: ���W %s ����", pNet->name );

        fMatch = TRUE;
        break;
      }

      break;

    case 'P':

      KEY( "Port", pNet->port, fread_number( pFile ) );
      break;

    case 'V':

      if ( !str_cmp( word, "Valid" ) )
      {
        pNet->valid = ( fread_number( pFile ) == FALSE ) ? FALSE : TRUE;
        fMatch = TRUE;
        break;
      }

      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_station: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

void load_bus( char * filename )
{
  ROOM_INDEX_DATA * platform;
  ROOM_INDEX_DATA * loge;
  BUS_DATA        * pBus;
  FILE            * pFile;
  char            * word;
  bool              fMatch;
  bool              Finish = FALSE;
  int               count = 0;
  int               location;

  PUSH_FUNCTION( "load_bus" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case 'B':
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          set_bus_default( ( pBus = alloc_struct( STRUCT_BUS_DATA ) ) );

          /* Ū�J���W */
          pBus->name = str_dup( fread_word( pFile ) );

          /* Ū�J�W�U���B, ���B���ݥ��s�b, �B���঳�V�U�X�f */
          location = fread_number( pFile );
          if ( !( pBus->station = get_room_index( location ) ) )
            mudlog( LOG_DEBUG, "load_bus: �䤣��a�K�� %d." , location );

          /* �ˬd�O�_���V�U�X�f, ���h���� */
          if ( !check_station( pBus->station ) )
            mudlog( LOG_DEBUG, "load_bus: �a�K�� %d ���X�k.", location );

          /* Ū����x, ����s�b, �t�Ϋإ� */
          fBootDb  = FALSE;
          platform = get_room_index( location = fread_number( pFile ) );
          fBootDb  = TRUE;

          if ( platform )
            mudlog( LOG_DEBUG, "load_bus: �a�K����x %d �s�b.", location );

          if ( !( pBus->platform = create_platform( location
            , pBus->name, pBus->station->area ) ) )
          {
            mudlog( LOG_DEBUG, "load_bus: �إߦa�K�� %d ����.", location );
          }

          /* �W�U�s������ */
          if ( !link_path( pBus->station, pBus->platform ) )
            mudlog( LOG_DEBUG, "load_bus: �s���a�K������." );

          /* Ū�����[, ����s�b, �t�Ϋإ� */
          fBootDb = FALSE;
          loge    = get_room_index( location = fread_number( pFile ) );
          fBootDb = TRUE;

          if ( loge )
            mudlog( LOG_DEBUG, "load_bus: �a�K�����[ %d �s�b.", location );

          if ( !( pBus->loge = create_loge( location
            , pBus->name, pBus->station->area ) ) )
          {
            mudlog( LOG_DEBUG, "load_bus: �إߦa�K�� %d ����.", location );
          }

          /* Ū���O�� */
          if ( ( pBus->cost = fread_number( pFile ) ) <= 0 )
            mudlog( LOG_DEBUG, "load_bus: �a�K���O %d ���X�z.", pBus->cost );

          fread_to_eol( pFile );

          /* �إߦ�C */
          if ( !bus_first ) bus_first      = pBus;
          if (  bus_last  ) bus_last->next = pBus;

          bus_last   = pBus;
          pBus->next = NULL;

          count++;
          fMatch = TRUE;
          break;
        }
        break;

      case 'C':

        KEY( "Company" , company_name, fread_string( pFile ) );
        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }
        break;

      case 'L':

        if ( !str_cmp( word , "Loge" ) )
        {
          fread_to_eol( pFile ); /* �@�w��Ū���@�� */
          loge_descr = fread_string( pFile );
          fMatch = TRUE;
          break;
        }

        KEY( "LogeShort", loge_short, fread_string( pFile ) );
        break;

      case 'P':

        if ( !str_cmp( word , "Platform" ) )
        {
          fread_to_eol( pFile ); /* �@�w��Ū���@�� */
          platform_descr = fread_string( pFile );
          fMatch = TRUE;
          break;
        }

        KEY( "PlatformShort", platform_short, fread_string( pFile ) );
        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "Load_bus: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d �Ӧa�K���." , count );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J����a�K�����" );
  }

  RETURN_NULL();
}

/* ���J§����� */
void load_bounty( const char * filename )
{
  BOUNTY_DATA * pBounty;
  FILE        * pFile;
  char        * word;
  bool          fMatch;
  bool          Finish = FALSE;

  PUSH_FUNCTION( "load_bounty" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Bounty" ) )
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          set_bounty_default( pBounty = alloc_struct( STRUCT_BOUNTY_DATA ) );
          load_a_bounty( pBounty, pFile );

          top_bounty++;
          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;

      case 'L':

        KEY( "Limit", BountyLimit, fread_number( pFile ) );
        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "load_bounty: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d ���a����." , top_bounty );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J����§�������" );
  }

  RETURN_NULL();
}

/* Ū���@��§����� */
void load_a_bounty( BOUNTY_DATA * pBounty, FILE * pFile )
{
  MOB_INDEX_DATA * pMob;
  char           * word;
  bool             fMatch;
  int              slot;

  PUSH_FUNCTION( "load_a_bounty" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'C':

      if ( !str_cmp( word, "Chance" ) )
      {
        if ( ( slot = fread_number( pFile ) ) <= 0 || slot > 1000 )
          mudlog( LOG_DEBUG, "load_a_bounty: �X�{���v %d ���X�z.", slot );

        pBounty->chance = slot;
        fMatch          = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pBounty->mob )
          mudlog( LOG_DEBUG, "load_a_bounty: �ʥF�Ǫ����Ǹ�." );

        if ( !pBounty->msg || !*pBounty->msg )
          mudlog( LOG_DEBUG, "load_a_bounty: �ʥF��X�ԭz." );

        if ( IS_ERROR( pBounty->chance ) )
          mudlog( LOG_DEBUG, "load_a_bounty: �ʥF�X�{���v." );

        if ( IS_ERROR( pBounty->migration ) )
          mudlog( LOG_DEBUG, "load_a_migration: �ʥF�E�p���v." );

        if ( IS_ERROR( pBounty->type ) )
          mudlog( LOG_DEBUG, "load_a_bounty: �ʥF���૬�A." );

        if ( IS_ERROR( pBounty->max ) )
          mudlog( LOG_DEBUG, "load_a_bounty: �ʥF�̤j�X�{�q." );

        pBounty->next = bounty_list;
        bounty_list   = pBounty;

        RETURN_NULL();
      }

      break;

    case 'L':

      if ( !str_cmp( word , "Lock" ) )
      {
        pBounty->lock = fread_number( pFile ) == TRUE ? TRUE : FALSE;
        fMatch = TRUE;
        break;
      }
      break;

    case 'M':

      if ( !str_cmp( word, "Migration" ) )
      {
        if ( ( slot = fread_number( pFile ) ) < 0 || slot > 100 )
          mudlog( LOG_DEBUG, "load_a_bounty: �E�p���v %d ���X�z.", slot );

        pBounty->migration = slot;
        fMatch             = TRUE;
        break;
      }

      if ( !str_cmp( word, "Mobile" ) )
      {
        fBootDb = FALSE;
        if ( !( pMob = get_mob_index( slot = fread_number( pFile ) ) ) )
        {
          fBootDb = TRUE;
          mudlog( LOG_DEBUG, "load_a_bounty: �a��� %d ���s�b.", slot );
        }

        pBounty->mob = pMob;
        fMatch       = TRUE;
        fBootDb      = TRUE;
        break;
      }

      if ( !str_cmp( word, "Message" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pBounty->msg = fread_string( pFile );
        fMatch       = TRUE;
        break;
      }

      if ( !str_cmp( word, "MaxNumber" ) )
      {
        if ( ( slot = fread_number( pFile ) ) <= 0 )
          mudlog( LOG_DEBUG, "load_a_bounty: �̤j�ƥ� %d ���X�z.", slot );

        pBounty->max = slot;
        fMatch       = TRUE;
        break;
      }

      break;

    case 'R':

      if ( !str_cmp( word, "Room" ) )
      {
        if ( ( slot = fread_number( pFile ) ) > 0 )
        {
          fBootDb = FALSE;
          if ( !get_room_index( slot ) )
          {
            fBootDb = TRUE;
            mudlog( LOG_DEBUG, "load_a_bounty: �ж� %d ���s�b.", slot );
          }
          pBounty->room = slot;
          fBootDb       = TRUE;
        }

        fMatch = TRUE;
        break;
      }
      break;

    case 'T':

      if ( !str_cmp( word, "Type" ) )
      {
        switch( ( slot = fread_number( pFile ) ) )
        {
        default:
          mudlog( LOG_DEBUG, "load_a_bounty: ���૬�A %d ���X�z.", slot );
          break;

        case BOUNTY_GOLD:
        case BOUNTY_FIRMAN:
          break;
        }

        pBounty->type = slot;
        fMatch        = TRUE;
        break;
      }
      break;

    case 'V':
      KEY( "Value", pBounty->value, fread_number( pFile ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "load_a_bounty: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* ���J§����� */
void load_gift( const char * filename )
{
  GIFT_DATA * pGift;
  FILE      * pFile;
  char      * word;
  bool        fMatch;
  bool        Finish = FALSE;

  PUSH_FUNCTION( "load_gift" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Gift" ) )
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          set_gift_default( pGift = alloc_struct( STRUCT_GIFT_DATA ) );
          load_a_gift( pGift, pFile );

          top_gift++;
          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "load_gift: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d ��§�����." , top_gift );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J����§�������" );
  }

  RETURN_NULL();
}

/* Ū���@��§����� */
void load_a_gift( GIFT_DATA * pGift, FILE * pFile )
{
  GIFT_DATA * aGift;
  char      * word;
  int         level;
  bool        fMatch;

  PUSH_FUNCTION( "load_a_gift" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'D':

      if ( !str_cmp( word, "Duration" ) )
      {
        if ( ( level = fread_number( pFile ) ) <= 0 )
          mudlog( LOG_DEBUG, "load_a_gift: ���j�ɶ� %d ���X�z.", level );

        pGift->duration = level;
        fMatch          = TRUE;
        break;
      }

      if ( !str_cmp( word, "Days" ) )
      {
        if ( ( level = fread_number( pFile ) ) <= 0 )
          mudlog( LOG_DEBUG, "load_a_gift: �|��Ѽ� %d ���X�z.", level );

        pGift->days = level;
        fMatch      = TRUE;
        break;
      }

      if ( !str_cmp( word, "Date" ) )
      {
        int day;
        int month;

        month = atoi( fread_word( pFile ) );
        day   = atoi( fread_word( pFile ) );

        if ( month <= 0 || day <= 0 )
          mudlog( LOG_DEBUG, "load_a_gift: §���H�e������X�z." );

        switch( month )
        {
        default:
          mudlog( LOG_DEBUG, "load_a_gift: §���H�e������X�z." );
          break;

        case  1: case  3: case 5: case 7: case 8:
        case 10: case 12:

          if ( day <= 0 || day > 31 )
            mudlog( LOG_DEBUG, "load_a_gift: §���H�e������X�z." );

          break;

        case 2:

          if ( day <= 0 || day > 29 )
            mudlog( LOG_DEBUG, "load_a_gift: §���H�e������X�z." );

          break;

        case 4: case 6: case 9: case 11:

          if ( day <= 0 || day > 30 )
            mudlog( LOG_DEBUG, "load_a_gift: §���H�e������X�z." );

          break;
        }

        pGift->day   = day;
        pGift->month = month;
        fMatch       = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( IS_ERROR( pGift->high ) )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF�̰�����." );

        if ( IS_ERROR( pGift->low ) )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF�̧C����." );

        if ( IS_ERROR( pGift->stamp ) )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF§���Ǹ�." );

        if ( IS_ERROR( pGift->sender ) )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF§�����e��." );

        if ( IS_ERROR( pGift->duration ) )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF§�����j�ɶ�." );

        if ( IS_ERROR( pGift->days ) )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF§���|��Ѽ�." );

        if ( IS_ERROR( pGift->day ) || IS_ERROR( pGift->month ) )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF§�����e���." );

        if ( !pGift->gift )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF§��." );

        if ( !pGift->title || !*pGift->title )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF§�����D." );

        if ( !pGift->message || !*pGift->message )
          mudlog( LOG_DEBUG, "load_a_gift: �ʥF§���T��." );

        if ( pGift->high < pGift->low ) SWAP( pGift->high, pGift->low );

        set_gift_time( pGift );

        pGift->next = NULL;
        for ( aGift = gift_list; aGift && aGift->next; aGift = aGift->next );

        if ( !aGift ) gift_list   = pGift;
        else          aGift->next = pGift;

        RETURN_NULL();
      }

      break;

    case 'G':

      if ( !str_cmp( word, "Gold" ) )
      {
        if ( ( level = fread_number( pFile ) ) < 0 )
          mudlog( LOG_DEBUG, "load_a_gift: §�� %d ���X�z.", level );

        pGift->gold = level;
        fMatch      = TRUE;
        break;
      }

      if ( !str_cmp( word, "Gift" ) )
      {
        OBJ_INDEX_DATA * pIndex;

        level = fread_number( pFile );

        if ( !( pIndex = get_obj_index( level ) ) )
          mudlog( LOG_DEBUG, "load_a_gift: §�����X %d ���s�b.", level );

        pGift->gift = pIndex;
        fMatch      = TRUE;
        break;
      }

      break;

    case 'H':

      if ( !str_cmp( word, "High" ) )
      {
        if ( ( level = fread_number( pFile ) ) <= 0 || level > MAX_LEVEL )
          mudlog( LOG_DEBUG, "load_a_gift: �̰����� %d ���X�z.", level );

        pGift->high = level;
        fMatch      = TRUE;
        break;
      }
      break;

    case 'L':

      if ( !str_cmp( word, "Low" ) )
      {
        if ( ( level = fread_number( pFile ) ) <= 0 || level > MAX_LEVEL )
          mudlog( LOG_DEBUG, "load_a_gift: �̧C���� %d ���X�z.", level );

        pGift->low = level;
        fMatch     = TRUE;
        break;
      }

      break;

    case 'M':

      if ( !str_cmp( word, "Message" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pGift->message = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'S':

      if ( !str_cmp( word, "Sender" ) )
      {
        if ( !get_mob_index( level = fread_number( pFile ) ) )
          mudlog( LOG_DEBUG, "load_a_gift: §�����e�� %d ���s�b.", level );

        pGift->sender = level;
        fMatch        = TRUE;
        break;
      }

      if ( !str_cmp( word, "Stamp" ) )
      {
        level = fread_number( pFile );

        for ( aGift = gift_list; aGift; aGift = aGift->next )
        {
          if ( aGift->stamp == level )
            mudlog( LOG_DEBUG, "load_a_gift: �Ǹ� %d ����.", level );
        }

        pGift->stamp = level;
        fMatch       = TRUE;
        break;
      }
      break;

    case 'T':
      KEY( "Title", pGift->title, fread_string( pFile ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "load_a_gift: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* ���J���D��� */
void load_question( const char * filename )
{
  QUESTION_DATA * pQuestion;
  FILE          * pFile;
  char          * word;
  bool            fMatch;
  bool            Finish = FALSE;

  PUSH_FUNCTION( "load_question" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Question" ) )
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          pQuestion = alloc_struct( STRUCT_QUESTION_DATA );
          set_question_default( pQuestion );

          load_a_question( pQuestion, pFile );

          top_question++;
          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "load_question: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d �Ӱ��D���." , top_question );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J������D�����" );
  }

  RETURN_NULL();
}

/* Ū���@�Ӹ������ */
void load_a_question( QUESTION_DATA * pQuestion, FILE * pFile )
{
  char * word;
  bool   fMatch;
  int    loop;
  int    count;
  int    ans;

  PUSH_FUNCTION( "load_a_question" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pQuestion->title || !*pQuestion->title )
          mudlog( LOG_DEBUG, "load_a_question: �S�����D�D��." );

        for ( ans = loop = count = 0; loop < MAX_QUESTION; loop++ )
        {
          if ( pQuestion->question[loop] && *pQuestion->question[loop] )
          {
            if ( pQuestion->answer[loop] == TRUE ) ans++;
            count++;
          }
        }

        if ( count <= 1 )
          mudlog( LOG_DEBUG, "load_a_question: ���D�Ӥ� %d.", count );

        if ( ans <= 0 )
          mudlog( LOG_DEBUG, "load_a_question: �ܤ֭n���@�ӥH�W������." );

        pQuestion->next = question_list;
        question_list   = pQuestion;
        RETURN_NULL();
      }

      break;

    case 'Q':

      if ( !str_cmp( word, "Question" ) )
      {
        for ( loop = 0; loop < MAX_QUESTION; loop++ )
          if ( !pQuestion->question[loop] ) break;

        if ( loop >= MAX_QUESTION )
          mudlog( LOG_DEBUG, "load_a_question: �Ӧh�D�ءM�L�k�x�s." );

        pQuestion->question[loop] = fread_string( pFile );
        pQuestion->answer[loop]   = fread_number( pFile );

        if ( !pQuestion->question[loop] || !*pQuestion->question[loop] )
          mudlog( LOG_DEBUG, "load_a_question: �D�ؤ�²�u." );

        fMatch = TRUE;
        break;
      }

      break;

    case 'T':

      if ( !str_cmp( word, "Title" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pQuestion->title = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_a_question: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* ���J������� */
void load_quest( const char * filename )
{
  QUEST_INFO * pQuest;
  FILE       * pFile;
  char       * word;
  bool         fMatch;
  bool         Finish = FALSE;

  PUSH_FUNCTION( "load_quest" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Quest" ) )
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          set_quest_default( pQuest = alloc_struct( STRUCT_QUEST_INFO ) );
          load_a_quest( pQuest, pFile );

          top_quest++;
          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "Load_quest: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d �Ӹ������." , top_quest );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J������������" );
  }

  RETURN_NULL();
}

/* Ū���@�Ӹ������ */
void load_a_quest( QUEST_INFO * pQuest, FILE * pFile )
{
  char * word;
  bool   fMatch;

  PUSH_FUNCTION( "load_a_quest" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pQuest->mark )
          mudlog( LOG_DEBUG, "load_a_quest: �S����������r." );

        if ( !pQuest->info )
          mudlog( LOG_DEBUG, "load_a_quest: �S�������ѻ���T." );

        if ( pQuest->show && !pQuest->help[0] )
          mudlog( LOG_DEBUG, "load_a_quest: ��ܪ����ȥ����n������." );

        pQuest->next = quest_list;
        quest_list   = pQuest;
        RETURN_NULL();
      }

      break;

    case 'H':

      if ( !str_cmp( word , "Help" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pQuest->help = fread_string( pFile );
        fMatch       = TRUE;
        break;
      }

      break;

    case 'I':
      KEY( "Information", pQuest->info, fread_string( pFile ) );
      break;

    case 'K':

      if ( !str_cmp( word, "Keyword" ) )
      {
        if ( quest_lookup( pQuest->mark = fread_string( pFile ) ) )
          mudlog( LOG_ERR, "load_a_quest: ��������r%s����.", pQuest->mark );

        fMatch = TRUE;
        break;
      }
      break;

    case 'S':

      if ( !str_cmp( word , "Show" ) )
      {
        pQuest->show = ( fread_number( pFile ) == TRUE ) ? TRUE : FALSE;
        fMatch = TRUE;
        break;
      }
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_a_quest: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* ���J������� */
void load_event( const char * filename )
{
  EVENT_DATA * pEvent;
  FILE       * pFile;
  char       * word;
  bool         fMatch;
  bool         Finish = FALSE;

  PUSH_FUNCTION( "load_event" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Event" ) )
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          set_event_default( pEvent = alloc_struct( STRUCT_EVENT_DATA ) );
          load_a_event( pEvent, pFile );

          top_event++;
          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "load_event: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d ��Ĳ�o�ƥ�." , top_event );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J����Ĳ�o�ƥ�." );
  }

  RETURN_NULL();
}

/* Ū���@��Ĳ�o�ƥ� */
void load_a_event( EVENT_DATA * pEvent, FILE * pFile )
{
  EVENT_DATA * zEvent;
  char       * word;
  char       * keyword;
  bool         fMatch;
  int          chance;

  PUSH_FUNCTION( "load_a_event" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'C':

      if ( !str_cmp( word, "Chance" ) )
      {
        if ( ( chance = fread_number( pFile ) ) <= 0 || chance > 1000 )
          mudlog( LOG_DEBUG, "load_a_event: �X�{���v %d ���X�z.", chance );

        pEvent->chance = chance;
        fMatch          = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( IS_ERROR( pEvent->chance ) )
          mudlog( LOG_DEBUG, "load_a_event: �S���]�wĲ�o���v." );

        if ( !pEvent->function )
          mudlog( LOG_DEBUG, "load_a_event: �S��Ĳ�o�B�z���." );

        if ( !pEvent->title )
          mudlog( LOG_DEBUG, "load_a_event: �S��Ĳ�o�W��." );

        if ( !pEvent->keyword )
          mudlog( LOG_DEBUG, "load_a_event: �ʥFĲ�o����r." );

        pEvent->next = event_list;
        event_list   = pEvent;
        RETURN_NULL();
      }

      break;

    case 'F':

      if ( !str_cmp( word , "Function" ) )
      {
        EVENT_FUN * function;

        keyword = fread_string( pFile );

        if ( keyword[0] )
        {
          if ( !( function = event_function( keyword ) ) )
            mudlog( LOG_DEBUG , "load_a_event: Ĳ�o�ƥ󪺨�� %s �䤣��"
              , keyword );

          pEvent->function = function;
          free_string( keyword );
        }

        fMatch = TRUE;
        break;
      }

      break;

    case 'K':
      if ( !str_cmp( word, "Keyword" ) )
      {
        keyword = fread_string( pFile );

        for ( zEvent = event_list; zEvent; zEvent = zEvent->next )
        {
          if ( !str_cmp( keyword, zEvent->keyword ) )
            mudlog( LOG_DEBUG, "load_a_event: ����r %s ����.", keyword );
        }

        pEvent->keyword = str_dup( keyword );
        free_string( keyword );

        fMatch = TRUE;
        break;
      }

      break;

    case 'L':

      if ( !str_cmp( word , "Lock" ) )
      {
        pEvent->lock = fread_number( pFile ) == TRUE ? TRUE : FALSE;
        fMatch = TRUE;
        break;
      }
      break;

    case 'T':
      KEY( "Title", pEvent->title, fread_string( pFile ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "load_a_event: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* ���J����� */
void load_ship( const char * filename )
{
  SHIP_DATA    * pShip;
  FILE         * pFile;
  char         * word;
  bool           fMatch;
  bool           Finish = FALSE;

  PUSH_FUNCTION( "load_ship" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Ship" ) )
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          set_ship_default( pShip = alloc_struct( STRUCT_SHIP_DATA ) );
          load_a_ship( pShip, pFile );

          top_ship++;
          pShip->waiting_tick = pShip->waiting;
          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "Load_ship: �R�O %s �����T.", word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d �Ӵ����." , top_ship );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J��������" );
  }

  RETURN_NULL();
}

/* Ū���@������� */
void load_a_ship( SHIP_DATA * pShip, FILE * pFile )
{
  char            * word;
  ROOM_INDEX_DATA * pRoom;
  SHIP_DATA       * aShip;
  int               slot;
  int               loop;
  int               iHash;
  bool              fMatch;

  PUSH_FUNCTION( "load_a_ship" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'C':

      if ( !str_cmp( word, "Cabin" ) )
      {
        if ( pShip->cabin )
          mudlog( LOG_DEBUG, "load_a_ship: �����." );

        fBootDb = FALSE;
        if ( get_room_index( slot = fread_number( pFile ) ) )
          mudlog( LOG_DEBUG, "load_a_ship: ������s�b", slot );
        fBootDb = TRUE;

        if ( !pShip->description )
          mudlog( LOG_DEBUG, "load_a_ship: �S����W��." );

        if ( !pShip->description )
          mudlog( LOG_DEBUG, "load_a_ship: �S����ԭz." );

        set_room_default( pRoom = alloc_struct( STRUCT_ROOM_INDEX_DATA ) );

        pRoom->people          = NULL;
        pRoom->contents        = NULL;
        pRoom->extra_descr     = NULL;
        pRoom->club            = NULL;
        pRoom->job             = NULL;
        pRoom->area            = DefaultArea;
        pRoom->name            = str_dup( pShip->name );
        pRoom->description     = str_dup( pShip->description );
        pRoom->filename        = str_dup( "�t�Ϋإ�" );
        pRoom->vnum            = slot;
        pRoom->room_flags      = ROOM_SAFE | ROOM_NO_RECALL | ROOM_NO_WHERE
                                 | ROOM_NOQUIT | ROOM_SAIL | ROOM_NO_MOB;
        pRoom->light           = 0;
        pRoom->sector          = DefaultSector;
        iHash                  = pRoom->vnum % MAX_KEY_HASH;
        pRoom->next            = room_index_hash[iHash];
        room_index_hash[iHash] = pRoom;
        top_room++;

        for ( loop = 0; loop < DIR_MAX; loop++ ) pRoom->exit[loop] = NULL;

        pShip->cabin       = pRoom;
        fMatch             = TRUE;
        break;
      }

      if ( !str_cmp( word, "Cost" ) )
      {
        if ( ( slot = fread_number( pFile ) ) <= 0 || slot >= MAX_ASSET )
          mudlog( LOG_DEBUG, "load_a_ship: ��O %d ���X�z.", slot );

        pShip->cost = slot;
        fMatch      = TRUE;
        break;
      }

      break;

    case 'D':

      if ( !str_cmp( word , "Description" ) )
      {
        if ( pShip->description )
          mudlog( LOG_DEBUG, "load_a_ship: ��ԭz����." );

        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pShip->description = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      if ( !str_cmp( word, "Destination" ) )
      {
        if ( pShip->destination )
          mudlog( LOG_DEBUG, "load_a_ship: �ت��a����." );

        if ( !( pRoom = get_room_index( slot = fread_number( pFile ) ) ) )
          mudlog( LOG_DEBUG, "load_a_ship: �䤣��ت��a�I %d.", slot );

        for ( aShip = ship_list; aShip; aShip = aShip->next )
        {
          if ( aShip->destination == pRoom )
            mudlog( LOG_DEBUG, "load_a_ship: �ت��a %d ����.", slot );
        }

        pShip->destination = pRoom;
        fMatch             = TRUE;
        break;
      }

      if ( !str_cmp( word, "Delay" ) )
      {
        if ( ( slot = fread_number( pFile ) ) < 0 || slot >= 10000 )
          mudlog( LOG_DEBUG, "load_a_ship: �������v %d ���X�z.", slot );

        pShip->delay = slot;
        fMatch       = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pShip->name )
          mudlog( LOG_DEBUG, "load_a_ship: �S�����W��." );

        if ( !pShip->msg_entrance )
          mudlog( LOG_DEBUG, "load_a_ship: �S���a���ԭz." );

        if ( !pShip->msg_land )
          mudlog( LOG_DEBUG, "load_a_ship: �S���J��ԭz." );

        if ( !pShip->description )
          mudlog( LOG_DEBUG, "load_a_ship: �S����ԭz." );

        if ( !pShip->starting )
          mudlog( LOG_DEBUG, "load_a_ship: �S���X�o�I." );

        if ( !pShip->destination )
          mudlog( LOG_DEBUG, "load_a_ship: �S���ت��a." );

        if ( !pShip->cabin )
          mudlog( LOG_DEBUG, "load_a_ship: �S���." );

        if ( IS_ERROR( pShip->cost ) )
          mudlog( LOG_DEBUG, "load_a_ship: �S���O��." );

        if ( IS_ERROR( pShip->sailing ) )
          mudlog( LOG_DEBUG, "load_a_ship: �S�����ɶ�." );

        if ( IS_ERROR( pShip->waiting ) )
          mudlog( LOG_DEBUG, "load_a_ship: �S�����ݮɶ�." );

        pShip->next = ship_list;
        ship_list   = pShip;

        RETURN_NULL();
      }

      if ( !str_cmp( word , "Entrance" ) )
      {
        if ( pShip->msg_entrance )
          mudlog( LOG_DEBUG, "load_a_ship: �a��ԭz����." );

        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pShip->msg_entrance = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'L':

      if ( !str_cmp( word , "Land" ) )
      {
        if ( pShip->msg_land )
          mudlog( LOG_DEBUG, "load_a_ship: �J��ԭz����." );

        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pShip->msg_land = fread_string( pFile );
        fMatch = TRUE;
        break;
      }

      break;

    case 'N':
      KEY( "Name", pShip->name, fread_string( pFile ) );
      break;

    case 'P':

      if ( !str_cmp( word, "Pirate" ) )
      {
        if ( ( slot = fread_number( pFile ) ) < 0 || slot >= 10000 )
          mudlog( LOG_DEBUG, "load_a_ship: ���s�X�{���v %d ���X�z.", slot );

        pShip->pirate = slot;
        fMatch        = TRUE;
        break;
      }

      break;

    case 'S':

      if ( !str_cmp( word, "Sailing" ) )
      {
        if ( ( slot = fread_number( pFile ) ) <= 0 )
          mudlog( LOG_DEBUG, "load_a_ship: ���ɶ� %d ���X�z.", slot );

        pShip->sailing = slot;
        fMatch         = TRUE;
        break;
      }

      if ( !str_cmp( word, "Starting" ) )
      {
        if ( pShip->starting )
          mudlog( LOG_DEBUG, "load_a_ship: �X�o�I����." );

        if ( !( pRoom = get_room_index( slot = fread_number( pFile ) ) ) )
          mudlog( LOG_DEBUG, "load_a_ship: �䤣��X�o�I %d.", slot );

        for ( aShip = ship_list; aShip; aShip = aShip->next )
        {
          if ( aShip->starting == pRoom )
            mudlog( LOG_DEBUG, "load_a_ship: �X�o�I %d ����.", slot );
        }

        pShip->starting = pRoom;
        fMatch          = TRUE;
        break;
      }

      break;

    case 'W':

      if ( !str_cmp( word, "Waiting" ) )
      {
        if ( ( slot = fread_number( pFile ) ) <= 0 )
          mudlog( LOG_DEBUG, "load_a_ship: ���ݴ��ɶ� %d ���X�z.", slot );

        pShip->waiting = slot;
        fMatch         = TRUE;
        break;
      }
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_a_ship: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* Ū�����~�ɮ׸�� */
void load_sale( const char * filename )
{
  SALE_DATA * pSale;
  FILE      * pFile;
  char      * word;
  bool        fMatch;
  bool        Finish = FALSE;

  PUSH_FUNCTION( "load_sale" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Sale" ) )
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          pSale = alloc_struct( STRUCT_SALE_DATA );
          set_sale_default( pSale );
          load_a_sale( pSale, pFile );

          top_sale++;
          fMatch = TRUE;
          break;
        }

        break;

      case 'C':

        if ( !str_cmp( word, "Chance" ) )
        {
          if ( ( SaleChance = fread_number( pFile ) ) <= 0 )
            mudlog( LOG_DEBUG , "load_sale: �����v %d ���X�k.", SaleChance );

          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          if ( SaleChance <= 0 )
            mudlog( LOG_DEBUG , "load_sale: �����v %d ���X�k.", SaleChance );

          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;

      case 'L':

        if ( !str_cmp( word, "Limit" ) )
        {
          if ( ( SaleLimit = fread_number( pFile ) ) <= 0 )
            mudlog( LOG_DEBUG , "load_sale: ���U���H�� %d ���X�k.", SaleLimit );

          fMatch = TRUE;
          break;
        }

        break;

      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "load_sale: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d �ө��~." , top_sale );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J������~�����" );
  }

  RETURN_NULL();
}

/* Ū���@�ө��~��� */
void load_a_sale( SALE_DATA * pSale, FILE * pFile )
{
  OBJ_INDEX_DATA * pIndex;
  char           * word;
  bool             fMatch;
  int              vnum;

  PUSH_FUNCTION( "load_a_sale" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'C':

      if ( !str_cmp( word , "Cost" ) )
      {
        if ( ( pSale->cost = fread_number( pFile ) ) <= 0 )
          mudlog( LOG_DEBUG, "load_a_sale: ���~��� %d ���X�z."
            , pSale->cost );

        fMatch = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pSale->obj ) mudlog( LOG_DEBUG, "load_a_sale: �S�����~." );

        if ( !IS_SET( pSale->obj->wear_flags, ITEM_TAKE ) )
          mudlog( LOG_DEBUG, "load_a_sale: ���~�D�i�H���T" );

        if ( IS_ERROR( pSale->cost ) )
          mudlog( LOG_DEBUG, "load_a_sale: ���~�S������T" );

        pSale->next = sale_list;
        sale_list   = pSale;

        RETURN_NULL();
      }

      break;

    case 'O':

      if ( !str_cmp( word, "Object" ) )
      {
        if ( !( pIndex = get_obj_index( vnum = fread_number( pFile ) ) ) )
          mudlog( LOG_DEBUG, "load_a_sale: �S�����~���X %d .", vnum );

        pSale->obj = pIndex;
        fMatch     = TRUE;
        break;
      }

      break;

    case 'V':

      if ( !str_cmp( word , "Visible" ) )
      {
        pSale->visible = ( fread_number( pFile ) == TRUE ) ? TRUE : FALSE;
        fMatch = TRUE;
        break;
      }

      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "load_a_sale: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* ���J���ڸ�� */
void load_immlist( const char * filename )
{
  IMMLIST_DATA * pImmlist;
  FILE         * pFile;
  char         * word;
  bool           fMatch;
  bool           Finish = FALSE;

  PUSH_FUNCTION( "load_immlist" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#Immortal" ) )
        {
          /* �t�m�O����H�γ]�w�w�]�� */
          pImmlist = alloc_struct( STRUCT_IMMLIST_DATA );
          set_immlist_default( pImmlist );
          load_a_immlist( pImmlist, pFile );

          top_immlist++;
          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "Load_immlist: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d �ӯ��ڸ��." , top_immlist );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J���󯫱ڪ����" );
  }

  RETURN_NULL();
}

/* Ū���@�ӯ��ڸ�� */
void load_a_immlist( IMMLIST_DATA * pImmlist, FILE * pFile )
{
  char * word;
  char   buf[MAX_INPUT_LENGTH];
  bool   fMatch;

  PUSH_FUNCTION( "load_a_immlist" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'A':

      if ( !str_cmp( word, "Adviser" ) )
      {
        int adviser;

        adviser = fread_number( pFile );
        if ( adviser < 0 || adviser > 1 )
          mudlog( LOG_DEBUG, "load_a_immlist: �U�ݸ�椣�X�z." );

        pImmlist->adviser = adviser;
        fMatch = TRUE;
        break;
      }
      break;

    case 'D':

      if ( !str_cmp( word , "Description" ) )
      {
        fread_to_eol( pFile ); /* �@�w��Ū���@�� */
        pImmlist->description = fread_string( pFile );
        fMatch                = TRUE;
        break;
      }

      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pImmlist->name )
          mudlog( LOG_DEBUG, "load_a_immlist: �S�����ڦW��." );

        if ( !pImmlist->description )
          mudlog( LOG_DEBUG, "load_a_immlist: �S���ѻ��ԭz." );

        if ( IS_ERROR( pImmlist->level ) && IS_ERROR( pImmlist->trust ) )
          mudlog( LOG_DEBUG, "load_a_immlist: �S�����ũάO�H�൥��." );

        if ( !imm_list ) imm_list       = pImmlist;
        if ( imm_last  ) imm_last->next = pImmlist;
        imm_last       = pImmlist;
        pImmlist->next = NULL;

        RETURN_NULL();
      }

      break;

    case 'L':

      if ( !str_cmp( word, "Level" ) )
      {
        int level;

        level = fread_number( pFile );
        if ( level <= LEVEL_HERO || level > MAX_LEVEL )
          mudlog( LOG_DEBUG, "load_a_immlist: ���Ť��X�z." );

        pImmlist->level = level;
        fMatch = TRUE;
        break;
      }
      break;

    case 'N':

      if ( !str_cmp( word, "Name" ) )
      {
        pImmlist->name = fread_string( pFile );
        str_cpy( buf, file_name( pImmlist->name, SAVE_FILE ) );
        if ( access( buf, R_OK ) != 0 )
          mudlog( LOG_DEBUG, "load_a_immlist: �W��%s���s�b.", pImmlist->name );
        fMatch = TRUE;
        break;
      }
      break;

    case 'T':

      if ( !str_cmp( word, "Trust" ) )
      {
        int trust;

        trust = fread_number( pFile );
        if ( trust <= LEVEL_HERO || trust > MAX_LEVEL )
          mudlog( LOG_DEBUG, "load_a_immlist: �H�൥�Ť��X�z." );

        pImmlist->trust = trust;
        fMatch = TRUE;
        break;
      }
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_a_immlist: �R�O %s �����T." , word );
  }

  RETURN_NULL();
}

/* ���J�Ѳ���� */
void load_stock( const char * filename )
{
  extern int   stock_win;
  extern int   stock_lost;
  FILE       * pFile;
  char       * word;
  bool         fMatch;
  bool         Finish = FALSE;
  int          count = 0;
  int          loop;
  int          cycle;

  PUSH_FUNCTION( "load_stock" );

  /* ���M���}�C��� */
  for ( loop = 0; loop < MAX_STOCK; loop++ )
  {
    stock_data[loop].cost       = 0;
    stock_data[loop].name       = NULL;
    stock_data[loop].buy        = 0;
    stock_data[loop].sell       = 0;
    stock_data[loop].today_sell = 0;
    stock_data[loop].today_buy  = 0;
    stock_data[loop].win        = stock_win;
    stock_data[loop].lost       = stock_lost;
    stock_data[loop].lock       = FALSE;

    for ( cycle = 0; cycle < MAX_STOCK_HISTORY; cycle++ )
      stock_data[loop].history[cycle] = -1;
  }

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }
        break;

      case 'S':

        if ( !str_cmp( word, "Stock" ) )
        {
          int slot;

          slot = fread_number( pFile ) - 1;
          if ( slot < 0 || slot >= MAX_STOCK )
            mudlog( LOG_DEBUG, "load_stock: ���X %d ���~.", slot );

          if ( stock_data[slot].name )
            mudlog( LOG_DEBUG, "load_stock: ���X %d ����.", slot );

          stock_data[slot].name       = str_dup( fread_word( pFile ) );
          stock_data[slot].cost       = fread_number( pFile );
          stock_data[slot].history[0] = stock_data[slot].cost;

          stock_data[slot].sell    = fread_number( pFile );
          stock_data[slot].buy     = fread_number( pFile );
          count++;
          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "Load_stock: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d �ӪѲ����." , count );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J����Ѳ������" );
  }

  RETURN_NULL();
}

/* ���J�ɯŸ�Ƹ�� */
void load_promotion( const char * filename )
{
  FILE * pFile;
  char * word;
  bool   fMatch;
  int    loop;
  int    level;
  int    count;

  PUSH_FUNCTION( "load_promotion" );

  /* ���M���}�C��� */
  for ( loop = 0; loop < MAX_LEVEL; loop++ )
  {
    kill_table[loop].number    = 0;
    kill_table[loop].killed    = 0;
    kill_table[loop].promotion = 0;
    kill_table[loop].damage    = 0;
    kill_table[loop].dodge     = 0;
  }

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':

        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          FCLOSE( pFile );
          RETURN_NULL();
        }
        break;

      case 'L':

        if ( !str_cmp( word, "Level" ) )
        {
          if ( ( level = fread_number( pFile ) ) < 0 || level >= MAX_LEVEL )
            mudlog( LOG_DEBUG, "load_promotion: ���� %d ���X�z.", level );

          if ( ( count = fread_number( pFile ) ) < 0 )
            mudlog( LOG_DEBUG, "load_promotion: �ƥ� %d ���X�z.", count );

          kill_table[level].promotion = count;

          if ( ( count = fread_number( pFile ) ) < 0 )
            mudlog( LOG_DEBUG, "load_promotion: �g��� %d ���X�z.", count );

          kill_table[level].exp = count;

          kill_table[level].damage = fread_number( pFile );
          kill_table[level].dodge  = fread_number( pFile );

          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "Load_promotion: �R�O %s �����T." , word );
    }

    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_DEBUG, "load_promotion: �S����������ɮ�." );
  }

  RETURN_NULL();
}

/* ���J�^����� */
void load_hero( const char * filename )
{
  HERO_DATA * pHero;
  FILE      * pFile;
  char      * word;
  bool        fMatch;
  bool        Finish = FALSE;
  int         count = 0;

  PUSH_FUNCTION( "load_hero" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = TRUE;
          fMatch = TRUE;
          break;
        }

        break;

      case 'H':

        if ( !str_cmp( word, "Hero" ) )
        {
          pHero        = alloc_struct( STRUCT_HERO_DATA );
          pHero->name  = fread_string( pFile );
          pHero->cname = fread_string( pFile );
          pHero->class = fread_string( pFile );
          pHero->timer = fread_number( pFile );

          if ( !hero_first ) hero_first      = pHero;
          if (  hero_last  ) hero_last->next = pHero;

          hero_last   = pHero;
          pHero->next = NULL;

          count++;
          fMatch = TRUE;
          break;
        }

        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "Load_hero: �R�O %s �����T." , word );

      if ( Finish ) break;
    }

    mudlog( LOG_INFO, "�t�θ��J %d �ӭ^�����." , count );
    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J����^�������" );
  }

  RETURN_NULL();
}

/* ���J�ػP��� */
void load_donate( const char * filename )
{
  FILE * pFile;
  char * word;
  bool   fMatch;
  bool   Finish = FALSE;

  PUSH_FUNCTION( "load_donate" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case 'B':
        KEY( "Benifit", DonateBenifit, fread_number( pFile ) );
        break;

      case 'C':
        KEY( "Count", DonateCount, fread_number( pFile ) );
        break;

      case 'D':
        KEY( "Duration", DonateDuration, fread_number( pFile ) );
        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          if ( DonateBenifit < 0 )
            mudlog( LOG_ERR, "load_donate: ���٪����X�k." );

          if ( DonateMoney < 0 )
            mudlog( LOG_ERR, "load_donate: ���٪��`���B���X�k." );

          if ( DonateLevel < 0 )
            mudlog( LOG_ERR, "load_donate: ���ٵ��Ť��X�k." );

          if ( DonateLimit < 0 )
            mudlog( LOG_ERR, "load_donate: ���ٹ�H���X�k." );

          if ( DonateDuration < 0 )
            mudlog( LOG_ERR, "load_donate: ���ٶ��j���X�k." );

          if ( DonateCount < 0 )
            mudlog( LOG_ERR, "load_donate: ���٦��Ƥ��X�k." );

          DonateLock = FALSE;
          Finish     = TRUE;
          fMatch     = TRUE;
          break;
        }

        break;

      case 'L':
        KEY( "Level", DonateLevel, fread_number( pFile ) );
        KEY( "Limit", DonateLimit, fread_number( pFile ) );
        break;

      case 'M':
        KEY( "Money", DonateMoney, fread_number( pFile ) );
        break;
      }

      /* ���O���A���~ */
      if ( !fMatch )
        mudlog( LOG_DEBUG , "load_donate: �R�O %s �����T.", word );

      if ( Finish ) break;
    }

  }

  else
  {
    mudlog( LOG_INFO, "�S�����J�����ػP�����" );
    DonateLock = TRUE;
  }

  RETURN_NULL();
}

/* Ū��������� */
void load_club( const char * filename )
{
  CLUB_DATA * pClub;
  FILE      * pFile;
  char      * word;
  bool        fMatch;
  bool        Finish = FALSE;

  PUSH_FUNCTION( "load_club" );

  if ( ( pFile = FOPEN( filename , "r" ) ) )
  {
    while ( !if_eof( pFile ) )
    {
      word   = if_eof( pFile ) ? "End" : fread_word( pFile );
      fMatch = FALSE;

      switch ( UPPER( word[0] ) )
      {
      /* ���� */
      case '*':
        fMatch = TRUE;
        fread_to_eol( pFile );
        break;

      case '#':

        if ( !str_cmp( word, "#CLUB" ) )
        {
          if ( club_count() >= max_club )
            mudlog( LOG_ERR, "load_club: �����ƥضW�X���w��." );

          /* �t�m�O����H�γ]�w�w�]�� */
          set_club_default( pClub = alloc_struct( STRUCT_CLUB_DATA ) );
          load_a_club( pClub, pFile );

          /* �إ߰_�����ж� */
          club_location( pClub );
          fMatch = TRUE;
          break;
        }

        break;

      case 'E':

        /* ���� */
        if ( !str_cmp( word, "End" ) )
        {
          Finish = fMatch = TRUE;
          break;
        }
        break;
      }

      /* ���O���A���~ */
      if ( !fMatch ) mudlog( LOG_DEBUG , "Load_club: �R�O %s �����T." , word );
      if ( Finish ) break;
    }

    FCLOSE( pFile );
  }

  else
  {
    mudlog( LOG_INFO, "�S�����J�������������" );
  }

  RETURN_NULL();
}

/* Ū���@��������� */
void load_a_club( CLUB_DATA * pClub, FILE * pFile )
{
  char * word;
  char * pName;
  bool   fMatch;
  int    status;

  PUSH_FUNCTION( "load_a_club" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    case '*':

      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'C':
      KEY( "Cname", pClub->cname, fread_string( pFile ) );
      break;

    case 'D':

      if ( !str_cmp( word, "Doyen" ) )
      {
        pName = fread_string( pFile );

        /* �w�����a�W�٤Ӫ� */
        if ( str_len( pName ) > NAME_LENGTH )
          mudlog( LOG_DEBUG, "load_a_club: ���a�W�r %s �Ӫ�", pName );
        else
          char_to_club( pName, pClub, CLUB_DOYEN );

        free_string( pName );
        fMatch = TRUE;
        break;
      }
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pClub->name )
          mudlog( LOG_ERR, "load_a_club: �S���^�������W��." );

        if ( !pClub->cname )
          mudlog( LOG_ERR, "load_a_club: �S����������W��." );

        if ( !pClub->master )
          mudlog( LOG_ERR, "load_a_club: �S�������D�H�W��." );

        if ( pClub->status == CLUB_STATUS_UNKNOW )
          mudlog( LOG_ERR, "load_a_club: ���A %d ���X�z.", pClub->status );

        pClub->next = club_list;
        club_list   = pClub;

        RETURN_NULL();
      }

      break;

    case 'F':

      if ( !str_cmp( word, "Follower" ) )
      {
        pName = fread_string( pFile );

        /* �w�����a�W�٤Ӫ� */
        if ( str_len( pName ) > NAME_LENGTH )
          mudlog( LOG_DEBUG, "load_a_club: ���a�W�r %s �Ӫ�", pName );

        else
          char_to_club( pName, pClub, CLUB_FOLLOWER );

        free_string( pName );
        fMatch = TRUE;
        break;
      }

      break;

    case 'M':

      if ( !str_cmp( word, "Member" ) )
      {
        pName = fread_string( pFile );

        /* �w�����a�W�٤Ӫ� */
        if ( str_len( pName ) > NAME_LENGTH )
          mudlog( LOG_DEBUG, "load_a_club: ���a�W�r %s �Ӫ�", pName );

        else
          char_to_club( pName, pClub, CLUB_MEMBER );

        free_string( pName );
        fMatch = TRUE;
        break;
      }

      KEY( "Master", pClub->master, fread_string( pFile ) );
      KEY( "Money",  pClub->money,  fread_number( pFile ) );
      break;

    case 'N':
      KEY( "Name", pClub->name, fread_string( pFile ) );
      break;

    case 'S':

      if ( !str_cmp( word, "Status" ) )
      {
        switch( status = fread_number( pFile ) )
        {
        default:
          mudlog( LOG_DEBUG , "Load_a_club: ���A %d �����T." , status );
          break;

        case CLUB_STATUS_COUNTERSIGN:
        case CLUB_STATUS_UNIONIZE:
          break;
        }

        pClub->status = status;
        fMatch        = TRUE;
      }
      break;

    case 'T':
      KEY( "Timer" , pClub->timer , fread_number( pFile ) );
      break;

    case 'V':
      KEY( "ViceMaster", pClub->vicemaster, fread_string( pFile ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Load_a_club: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}

/* ���J�ݸ���� */
ENQUIRE_DATA * load_enquire( FILE * pFile )
{
  ENQUIRE_DATA * pEnquire;
  char         * word;
  bool           fMatch;

  PUSH_FUNCTION( "load_enquire" );

  /* �t�m�O����H�γ]�w�w�]�� */
  set_enquire_default( pEnquire = alloc_struct( STRUCT_ENQUIRE_DATA ) );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    /* ���� */
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pEnquire->keyword )
          mudlog( LOG_DEBUG, "load_enquire: �S���]�w�ݸ�������r." );

        RETURN( pEnquire );
      }

      break;

    case 'K':

      KEY( "Keyword", pEnquire->keyword, fread_string( pFile ) );
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch ) mudlog( LOG_DEBUG , "load_pEnquire: �R�O %s �����T.", word );
  }

  RETURN( pEnquire );
}

/* ���JĲ�o�ʧ@ */
JOB_DATA * load_job( FILE * pFile )
{
  JOB_DATA * pJob;
  char     * word;
  bool       fMatch;

  PUSH_FUNCTION( "load_job" );

  /* �t�m�O����H�γ]�w�w�]�� */
  set_job_default( pJob = alloc_struct( STRUCT_JOB_DATA ) );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    /* ���� */
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        if ( !pJob->keyword )
          mudlog( LOG_DEBUG, "Load_job: �S���]�wĲ�o������." );

        if ( !pJob->function )
          mudlog( LOG_DEBUG, "Load_job: �S���]�wĲ�o�����." );

        if ( IS_ERROR( pJob->position ) )
          mudlog( LOG_DEBUG, "Load_job: �S���]�wĲ�o�����A." );

        RETURN( pJob );
      }
      break;

    case 'F':

      if ( !str_cmp( word, "Function" ) )
      {
        char * func;

        func = fread_string( pFile );

        if ( !( pJob->function  = job_lookup( func ) ) )
          mudlog( LOG_DEBUG, "load_room: �䤣��ާ@��� %s.", func );

        free_string( func );

        fMatch = TRUE;
        break;
      }

    case 'K':

      KEY( "Keyword", pJob->keyword, fread_string( pFile ) );
      break;

    case 'P':

      if ( !str_cmp( word, "Position" ) )
      {
        switch( ( pJob->position = fread_number( pFile ) ) )
        {
        default:
          mudlog( LOG_DEBUG, "load_job: ���~�����A %d.", pJob->position );

        case POS_DEAD:
        case POS_SLEEPING:
        case POS_RESTING:
        case POS_FIGHTING:
        case POS_STANDING:
          break;
        }

        fMatch = TRUE;
        break;
      }

      break;
    }

    /* ���O���A���~ */
    if ( !fMatch ) mudlog( LOG_DEBUG , "Load_job: �R�O %s �����T.", word );
  }

  RETURN( NULL );
}

void protype( FILE * pFile )
{
  char * word;
  bool   fMatch;

  PUSH_FUNCTION( "protype" );

  for ( ;; )
  {
    word   = if_eof( pFile ) ? "End" : fread_word( pFile );
    fMatch = FALSE;

    switch ( UPPER( word[0] ) )
    {
    /* ���� */
    case '*':
      fMatch = TRUE;
      fread_to_eol( pFile );
      break;

    case 'E':

      if ( !str_cmp( word, "End" ) )
      {
        RETURN_NULL();
      }
      break;
    }

    /* ���O���A���~ */
    if ( !fMatch )
      mudlog( LOG_DEBUG , "Protype: �R�O %s �����T." , word );
  }
  RETURN_NULL();
}
