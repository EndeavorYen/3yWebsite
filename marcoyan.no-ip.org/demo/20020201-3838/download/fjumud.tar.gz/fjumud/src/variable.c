/***************************************************************************
*  �o�O�ѻ��j�ƾǨt�s�@�s�Ҽ��g���C���M�D��� merc ��s�ӨӡM�Ҧ������v    *
*  �N�|�Q�O�d�M���w��j�a�ק�M���ڭ̤]�Ʊ�A�̤]�ണ�ѵ��j�a�M�Ҧ�����    *
*  �~�欰�N���Q���\�C                                                      *
*                                                                          *
*  paul@mud.ch.fju.edu.tw                                                  *
*  lc@mud.ch.fju.edu.tw                                                    *
*                                                                          *
***************************************************************************/
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include "merc.h"

/* �`�Ϊ��ж����������X */
#define ROOM_VNUM_JAIL                  1
#define ROOM_VNUM_LIMBO                 2
#define ROOM_VNUM_CHAT                  3
#define ROOM_VNUM_DEADROOM              10
#define ROOM_VNUM_DEADBODY              20
#define ROOM_VNUM_RECALL                501
#define ROOM_VNUM_SCHOOL                500
#define ROOM_VNUM_FAIL                  50

/* �ۦW��MOB���������X */
#define MOB_VNUM_VAMPIRE                2

int                     RoomJailVnum    =       ROOM_VNUM_JAIL;
ROOM_INDEX_DATA *       RoomJail        =       NULL;

int                     RoomLimboVnum   =       ROOM_VNUM_LIMBO;
ROOM_INDEX_DATA *       RoomLimbo       =       NULL;

int                     RoomDeadVnum    =       ROOM_VNUM_DEADROOM;
ROOM_INDEX_DATA *       RoomDead        =       NULL;

int                     RoomRecallVnum  =       ROOM_VNUM_RECALL;
ROOM_INDEX_DATA *       RoomRecall      =       NULL;

int                     RoomSchoolVnum  =       ROOM_VNUM_SCHOOL;
ROOM_INDEX_DATA *       RoomSchool      =       NULL;

int                     RoomFailVnum    =       ROOM_VNUM_FAIL;
ROOM_INDEX_DATA *       RoomFail        =       NULL;

int                     RoomChatVnum    =       ROOM_VNUM_CHAT;
ROOM_INDEX_DATA *       RoomChat        =       NULL;

int                     RoomCorpseVnum  =       ROOM_VNUM_DEADBODY;
ROOM_INDEX_DATA *       RoomCorpse      =       NULL;

AREA_DATA       *       DefaultArea     =       NULL;

int                     MobVampireVnum  =       MOB_VNUM_VAMPIRE;
MOB_INDEX_DATA *        MobVampire      =       NULL;

int                     ObjProtypeVnum  =       OBJ_VNUM_PROTYPE;
OBJ_INDEX_DATA *        ObjProtype      =       NULL;

int                     ObjMoneyVnum    =       OBJ_VNUM_MONEY_ONE;
OBJ_INDEX_DATA *        ObjMoney        =       NULL;

int                     ObjMoneySomeVnum=       OBJ_VNUM_MONEY_SOME;
OBJ_INDEX_DATA *        ObjMoneySome    =       NULL;

int                     ObjCorpseNPCVnum=       OBJ_VNUM_CORPSE_NPC;
OBJ_INDEX_DATA *        ObjCorpseNPC    =       NULL;

int                     ObjCorpsePCVnum =       OBJ_VNUM_CORPSE_PC;
OBJ_INDEX_DATA *        ObjCorpsePC     =       NULL;

int                     ObjHeadVnum     =       OBJ_VNUM_SEVERED_HEAD;
OBJ_INDEX_DATA *        ObjHead         =       NULL;

int                     ObjHeartVnum    =       OBJ_VNUM_TORN_HEART;
OBJ_INDEX_DATA *        ObjHeart        =       NULL;

int                     ObjArmVnum      =       OBJ_VNUM_SLICED_ARM;
OBJ_INDEX_DATA *        ObjArm          =       NULL;

int                     ObjLegVnum      =       OBJ_VNUM_SLICED_LEG;
OBJ_INDEX_DATA *        ObjLeg          =       NULL;

int                     ObjTurdVnum     =       OBJ_VNUM_FINAL_TURD;
OBJ_INDEX_DATA *        ObjTurd         =       NULL;

int                     ObjMushroomVnum =       OBJ_VNUM_MUSHROOM;
OBJ_INDEX_DATA *        ObjMushroom     =       NULL;

int                     ObjLightVnum    =       OBJ_VNUM_LIGHT_BALL;
OBJ_INDEX_DATA *        ObjLight        =       NULL;

int                     ObjSpringVnum   =       OBJ_VNUM_SPRING;
OBJ_INDEX_DATA *        ObjSpring       =       NULL;

int                     ObjDumplingVnum =       OBJ_VNUM_DUMPLING;
OBJ_INDEX_DATA *        ObjDumpling     =       NULL;

int                     ObjBougiVnum    =       OBJ_VNUM_BOUGI;
OBJ_INDEX_DATA *        ObjBougi        =       NULL;

int                     ObjPonVnum      =       OBJ_VNUM_PON;
OBJ_INDEX_DATA *        ObjPon          =       NULL;

int                     ObjChickenVnum  =       OBJ_VNUM_CHICKEN;
OBJ_INDEX_DATA *        ObjChicken      =       NULL;

int                     ObjMagicStoneVnum=      OBJ_VNUM_MAGICSTONE;
OBJ_INDEX_DATA *        ObjMagicStone   =       NULL;

int                     ObjMeatVnum     =       OBJ_VNUM_MEAT;
OBJ_INDEX_DATA *        ObjMeat         =       NULL;

int                     ObjLetterVnum   =       OBJ_VNUM_LETTER;
OBJ_INDEX_DATA *        ObjLetter       =       NULL;

bool                    ChatLog         =       TRUE;

bool                    ChannelAuction  =        TRUE;
bool                    ChannelChat     =        TRUE;
bool                    ChannelBulletin =        TRUE;
bool                    ChannelImmtalk  =        TRUE;
bool                    ChannelMusic    =        TRUE;
bool                    ChannelQuestion =        TRUE;
bool                    ChannelShout    =        TRUE;
bool                    ChannelYell     =        TRUE;
bool                    ChannelGamble   =        TRUE;
bool                    ChannelClass    =        TRUE;
bool                    ChannelClub     =        TRUE;
bool                    ChannelSemote   =        TRUE;
bool                    ChannelWeather  =        TRUE;
bool                    ChannelPhone    =        TRUE;
bool                    ChannelSuicide  =        TRUE;
bool                    ChannelRumor    =        TRUE;
bool                    ChannelNotice   =        TRUE;
bool                    ChannelGroup    =        TRUE;
bool                    ChannelPK       =        TRUE;

bool                    ConfigAutoExit  =       TRUE;
bool                    ConfigAutoLoot  =       TRUE;
bool                    ConfigAutoSac   =       FALSE;
bool                    ConfigBlank     =       TRUE;
bool                    ConfigBrief     =       FALSE;
bool                    ConfigCombine   =       TRUE;
bool                    ConfigPrompt    =       TRUE;
bool                    ConfigExact     =       TRUE;
bool                    ConfigMessage   =       TRUE;
bool                    ConfigFlee      =       FALSE;
bool                    ConfigAngel     =       TRUE;
bool                    ConfigAutoFood  =       FALSE;
bool                    ConfigAutoDrink =       FALSE;
bool                    ConfigRebirth   =       FALSE;
bool                    ConfigTrain     =       FALSE;
bool                    ConfigPractice  =       FALSE;
bool                    ConfigAnsi      =       FALSE;
bool                    ConfigLotto     =       FALSE;

int                     MaxRepeat       =       MAX_REPEAT;
