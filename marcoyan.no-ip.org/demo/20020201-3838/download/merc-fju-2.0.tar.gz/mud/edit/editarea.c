#include "edit.h"

#define AREA_X          10
#define AREA_Y          6
#define AREA_FRONT_COL  YELLOW
#define AREA_BACK_COL   BLACK
#define AREA_TAG_COL    RED
#define AREA_COL        ( AREA_FRONT_COL + ( AREA_BACK_COL << 4 ) )
#define AREA_TAG        ( AREA_FRONT_COL + ( AREA_TAG_COL  << 4 ) )

void show_area_shape            ( AREA_INFO * , FILE_INFO * );
void show_edit_area             ( int );
void set_area_default           ( AREA_INFO * );
int  load_area                  ( AREA_INFO * );

void show_area_shape( AREA_INFO *pArea , FILE_INFO * pFile )
{
  print_string( AREA_X , AREA_Y   , AREA_COL ,"�z�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�{" );
  print_string( AREA_X , AREA_Y+1 , AREA_COL ,"�x �ϰ��ɦW:                                              �x" );
  print_string( AREA_X , AREA_Y+2 , AREA_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( AREA_X , AREA_Y+3 , AREA_COL ,"�x �ϰ쪺�ݩ�: (*) ����� (*) �ݭn���                    �x" );
  print_string( AREA_X , AREA_Y+4 , AREA_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( AREA_X , AREA_Y+5 , AREA_COL ,"�x �ϰ�y�z  :                                            �x" );
  print_string( AREA_X , AREA_Y+6 , AREA_COL ,"�u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t" );
  print_string( AREA_X , AREA_Y+7 , AREA_COL ,"�x <�s��>  <���>                                         �x" );
  print_string( AREA_X , AREA_Y+8 , AREA_COL ,"�|�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�}" );

  /* �C�L�ɦW */
  print_string( AREA_X + 15 , AREA_Y + 1 , AREA_COL , pFile->filename );

  /* �C�L�ɮת����� */
  if ( pArea->valid == 0 )
    print_string( AREA_X + 40 , AREA_Y + 1 , AREA_COL , "���ɮ�" );

  else if ( pArea->valid == 1 )
    print_string( AREA_X + 40 , AREA_Y + 1 , AREA_COL , "�s�ɮ�" );

  else if ( pArea->valid == 2 )
    print_string( AREA_X + 40 , AREA_Y + 1 , AREA_COL , "�����T�����ɮ�" );


  /* �C�L�ݩ� */
  if ( pArea->attribution == 0 )
  {
    print_string( AREA_X + 16 , AREA_Y + 3 , AREA_COL , "*" );
    print_string( AREA_X + 27 , AREA_Y + 3 , AREA_COL , " " );
  }

  else
  {
    print_string( AREA_X + 16 , AREA_Y + 3 , AREA_COL , " " );
    print_string( AREA_X + 27 , AREA_Y + 3 , AREA_COL , "*" );
  }

  /* �C�L�s��� */

  print_string( AREA_X + 15 , AREA_Y + 5 , AREA_COL , pArea->editor );

  return;
}

/* ��ܽs��ϰ�榡���e�� */

void show_edit_area( int control )
{
  print_string( AREA_X + 3 , AREA_Y + 3
    ,( ( control == 1 ) ? AREA_TAG : AREA_COL )
    , "�ϰ쪺�ݩ�" );

  print_string( AREA_X + 3 , AREA_Y + 5
    ,( ( control == 2 ) ? AREA_TAG : AREA_COL )
    , "�ϰ�y�z" );

  print_string( AREA_X + 4 , AREA_Y + 7
    ,( ( control == 3 ) ? AREA_TAG : AREA_COL )
    , "�s��" );

  print_string( AREA_X + 12 , AREA_Y + 7
    ,( ( control == 4 ) ? AREA_TAG : AREA_COL )
    , "���" );

  return;

}

/* �s��s�榡�ϰ쪺�D�{�� */

void do_edit_area( void )
{
  AREA_INFO     area_formation;
  AREA_INFO   * pArea;
  STRING_INFO   aEditor;
  STRING_INFO * pEditor;
  FILE_INFO   * pFile;
  int           control = 1;
  int           execute = 0;
  int           control_key;

  /* �M���ù��H�ή������ */
  clear_screen();
  set_cursor_type( NO_CURSOR );

  /* �}���ɮ� */
  pFile = get_file_name( ".sec" );

  /* �ɮ׵L�kŪ�� */
  if ( pFile->information < 0 ) return;

  /* �]�w�ϰ쪺�_�ϭ� */
  pArea              = &area_formation;
  pArea->valid       = pFile->information;
  pArea->pEditor     = &aEditor;
  pArea->pFile       = pFile;

  /* �]�w�s��̦r��_�ҭ� */
  {
    pEditor                  = &aEditor;
    pEditor->x_pos           = AREA_X + 15;
    pEditor->y_pos           = AREA_Y +  5;
    pEditor->x_len           = 40;
    pEditor->y_len           =  1;
    pEditor->front_color     = BLUE;
    pEditor->back_color      = LIGHTGRAY;
    pEditor->org_front_color = AREA_COL;
    pEditor->org_back_color  = BLACK;
    pEditor->save_x_cursor   = 0;
    pEditor->save_y_cursor   = 0;
    pEditor->smash           = SMASH_EXECUTE;
    pEditor->number          = NUMBER_ACCEPT;
    pEditor->address         = pArea->editor;
    clear_string( pEditor );
  }

  /* �]�w�ϰ쪺�_�ϭ� */
  set_area_default( pArea );

  /* ���J�ϰ��ɮ� */
  if ( pFile->information == 0 )
  {

    /* �p�G�����~ */
    if ( !load_area( pArea ) )
    {
      pArea->valid = 2;
      set_area_default( pArea );
    }
  }

  /* ��ܤ@�}�l���s��ù� */
  show_area_shape( pArea , pFile );

  do
  {
    /* ��ܿù����ܰ� */
    show_edit_area( control );

    control_key = get_control_key();

    if ( control_key == RETURN_TAB    ) control++;
    if ( control_key == RETURN_UP     ) control--;
    if ( control_key == RETURN_DOWN   ) control++;
    if ( control_key == RETURN_RETURN ) execute = control;
    if ( control_key == RETURN_HOME   ) control = 1;
    if ( control_key == RETURN_END    ) control = 4;

    /* �ˬd�O�_�W�X�d�� */
    check_boundary( 1 , 4 , &control );

    switch ( execute )
    {

     /* �s��ϰ쪺�ݩ� */
     case 1 :

       while ( TRUE )
       {
         control_key = get_control_key();

         if ( control_key == RETURN_RETURN || control_key == RETURN_TAB )
           break;

         if ( control_key == RETURN_LEFT  ) pArea->attribution++;
         if ( control_key == RETURN_RIGHT ) pArea->attribution--;

         /* �ˬd�O�_�W�X�d�� */
         check_boundary( 0 , 1 , &(pArea->attribution ) );

         show_edit_area( control );

         if ( pArea->attribution == 0 )
         {
           print_string( AREA_X + 16 , AREA_Y + 3 , AREA_COL , "*" );
           print_string( AREA_X + 27 , AREA_Y + 3 , AREA_COL , " " );
         }

         else
         {
           print_string( AREA_X + 16 , AREA_Y + 3 , AREA_COL , " " );
           print_string( AREA_X + 27 , AREA_Y + 3 , AREA_COL , "*" );
         }
       }

       execute = 0;
       break;

     /* �s��s��� */
     case 2 :

       get_string( pEditor );

       execute = 0;
       break;

     /* �s�� */
     case 3 :

       fclose( pFile->filehandler );
       pFile->filehandler = fopen ( pFile->filename ,"w+" );

       fprintf( pFile->filehandler , "#AREA\n" );

       if ( pArea->attribution == 0 )
         fprintf( pFile->filehandler , "Echo    NO_ECHO\n" );

       else
         fprintf( pFile->filehandler , "Echo    WILL_ECHO\n" );

       fprintf( pFile->filehandler , "Editor  %s~\n" ,
         pArea->editor );

       fprintf( pFile->filehandler , "End\n" );

       fclose( pFile->filehandler );
       return;

     /* ���s�� */

     case 4 :

       /* �Y�O�s���ɮ׫h�R�� , ���M�h����. */

       if ( pFile->information == 1 )
         delete_null_file( pFile );
       else fclose( pFile->filehandler );

    }
  } while ( execute != 4 );
}

#undef AREA_X
#undef AREA_Y
#undef AREA_FRONT_COL
#undef AREA_BACK_COL
#undef AREA_COLOR
#undef AREA_TAG

/* �]�w�ϰ쪺�w�]�� */

void set_area_default( AREA_INFO *pArea )
{
  clear_string( pArea->pEditor );
  pArea->attribution = 1;
  return;
}

int load_area( AREA_INFO * pArea )
{
  char   word[ MAX_WORD_LENGTH ];
  char * pWord;
  int    Match;

  pWord = word ;
  for ( ; ; )
  {
    fread_word( pArea->pFile , pWord );
    if ( pArea->pFile->status == 1 ) return FALSE;
    Match = FALSE;

    switch( pWord[0] )
    {
      case '*' :

        fread_to_eol( pArea->pFile );
        Match = TRUE;
        break;

      case '#' :

        if ( !strcmp( pWord , "#AREA" ) )
        {
          Match = TRUE;
          break;
        }

       break;

     case 'E' :

       if ( !strcmp( pWord , "End" ) )
       {
         if ( fread_if_eof( pArea->pFile ) ) return TRUE;
         else                                return FALSE;
       }

       if ( !strcmp( pWord , "Echo" ) )
       {
          pArea->attribution = fread_number( pArea->pFile );
          if ( pArea->pFile->status == 1 ) return FALSE;
          if ( pArea->attribution > 1 && pArea->attribution < 0 )
            return FALSE;

          Match = TRUE;
          break;
       }

       if ( !strcmp( pWord , "Editor" ) )
       {
          fread_string( pArea->pFile , pArea->pEditor );
          if ( pArea->pFile->status == 1 ) return FALSE;
          Match = TRUE;
          break;
       }

       break;

    }

    if ( !Match ) return FALSE;

  }
}
