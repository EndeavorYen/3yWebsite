#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "merc.h"
#include "directory.h"

#define TEST_AREA_DIR           "../area.test/"

extern void     load_mobiles    args( ( FILE *fp ) );
extern void     load_object     args( ( FILE *fp ) );
extern void     load_resets     args( ( FILE *fp ) );
extern void     load_specials   args( ( FILE *fp ) );
extern void     load_notes      args( ( void ) );
extern void     load_mobprogs   args( ( FILE* fp ) );

extern int                      top_room;
extern int                      top_exit;
extern AREA_DATA *              area_last;
extern ROOM_INDEX_DATA *        room_index_hash         [MAX_KEY_HASH];
extern char                     str_empty[1];
extern bool                     fBootDb;

EDIT_ROOM_DATA *        pEdit_room;
ROOM_INDEX_DATA *       room_index_data_free;
EXIT_DATA *             exit_data_free;
EDIT_ROOM_DATA *        edit_room_data_free;

/* �� pRoomIndex �o���ж��� dir �X�f�R�� */
bool del_exit( ROOM_INDEX_DATA *pRoomIndex, int dir )
{
    EXIT_DATA *pexit;

    if( ( pexit = pRoomIndex->exit[dir] ) == NULL )  return FALSE;

    free_string(pexit->description);
    free_string(pexit->keyword);
    pexit->description      = &str_empty[0];
    pexit->keyword          = &str_empty[0];
    pexit->exit_info    = 0;
    pexit->key          = -1;
    pexit->vnum         = 0;
    pexit->to_room              = NULL;
    pRoomIndex->exit[dir]       = NULL;

    /*
    if( exit_data_free == NULL )
        exit_data_free = pexit;
    else
    {
        pexit->next = exit_data_free;
        exit_data_free = pexit->next;
    }
    */

    return TRUE;
}

bool load_area_file(CHAR_DATA *ch,FILE *fp)
{
    fBootDb = TRUE;
    for ( ; ; )
    {
        char *word;

        if ( fread_letter( fp ) != '#' )
        {
            send_to_char( "Load_Area_File: # not found.", ch );
            fBootDb = FALSE;
            return FALSE;
        }

        word = fread_word( fp );

            if ( word[0] == '$'               )              break;
        else if ( !str_cmp( word, "AREA"     ) ) load_area    (fp);
        else if ( !str_cmp( word, "MOBILES"  ) ) load_mobiles (fp);
        else if ( !str_cmp( word, "MOBPROGS" ) ) load_mobprogs(fp);
        else if ( !str_cmp( word, "OBJECTS"  ) ) load_object  (fp);
        else if ( !str_cmp( word, "RESETS"   ) ) load_resets  (fp);
        else if ( !str_cmp( word, "ROOMS"    ) ) load_room    (fp);
        else if ( !str_cmp( word, "SHOPS"    ) ) load_shop    (fp);
        else if ( !str_cmp( word, "SPECIALS" ) ) load_specials(fp);
        else
        {
            send_to_char( "Load_Area_file: bad section name.", ch );
            fBootDb = FALSE;
            return FALSE;
        }
    }
    fBootDb = FALSE;
    return TRUE;
}

void reset_room_index_data( ROOM_INDEX_DATA *pRoomIndex , int vnum)
{
    int door;
    pRoomIndex->people          = NULL;
    pRoomIndex->contents        = NULL;
    pRoomIndex->extra_descr     = NULL;
    pRoomIndex->area            = area_last;
    pRoomIndex->vnum            = vnum;
    free_string( pRoomIndex->name );
    free_string( pRoomIndex->description);
    pRoomIndex->room_flags      = 8;
    pRoomIndex->sector_type     = 0;
    pRoomIndex->light           = 0;
    for ( door = 0; door <= 5; door++ )
    {
        del_exit( pRoomIndex, door);
    }
}

void fwrite_edit_area( ROOM_INDEX_DATA *pRoomIndex, FILE *fp )
{
    int dir;

    if( fp == NULL )
    {
        bug(" Fwrite_edit_area: fp NULL !!", 0 );
        return;
    }
    fprintf( fp, "#%d\n", pRoomIndex->vnum );
    if( pRoomIndex->name != NULL )
        fprintf( fp, "%s~\n", pRoomIndex->name );
    else
        fprintf( fp, "~\n");
    if( pRoomIndex->description != NULL )
        fprintf( fp, "%s~\n", pRoomIndex->description );
    else
        fprintf( fp, "~\n");
    fprintf( fp, "%d %d %d \n", pRoomIndex->vnum/100, pRoomIndex->room_flags,
                                pRoomIndex->sector_type );
    for( dir = 0; dir < 5; dir++ )
    {
        if( pRoomIndex->exit[dir] != NULL )
        {
            fprintf( fp, "D%d\n", dir);
            if( pRoomIndex->exit[dir]->description != NULL )
                fprintf( fp, "%s~\n", pRoomIndex->exit[dir]->description );
            else
                fprintf( fp, "~\n");
            if( pRoomIndex->exit[dir]->keyword != NULL )
                fprintf( fp, "%s~\n", pRoomIndex->exit[dir]->keyword );
            else
                fprintf( fp, "~\n");
            fprintf( fp, "%d %d %d\n", 0, pRoomIndex->exit[dir]->key,
                                pRoomIndex->exit[dir]->vnum );
        }
    }
    fprintf( fp, "S\n");
}

/* �� pRoomIndex �o���ж����X�f�s�� vnum �� */

void set_exit( ROOM_INDEX_DATA *pRoomIndex, int vnum, int dir )
{
        EXIT_DATA *pexit;

        if( pRoomIndex->exit[dir] == NULL )
        {
            if( exit_data_free != NULL )
            {
                pexit = exit_data_free;
                /* exit_data_free = pexit->next; */
            }
            else
                pexit   = alloc_perm( sizeof(*pexit) , TYPE_32 );
        }
        else
        {
          pexit                 = pRoomIndex->exit[dir];
          free_string(pexit->description);
          free_string(pexit->keyword);
        }
        pexit->description      = &str_empty[0];
        pexit->keyword          = &str_empty[0];
        pexit->exit_info        = 0;
        pexit->key              = -1;
        pexit->vnum             = vnum;
        pexit->to_room = get_room_index( vnum );
        pRoomIndex->exit[dir]   = pexit;
        return;
}



void do_addroom( CHAR_DATA * ch, char *argument)
{
    ROOM_INDEX_DATA *pRoomIndex;
    int vnum, iHash;
    EDIT_ROOM_DATA *  pRoom;

    if( argument == NULL )
    {
        send_to_char("�榡: addroom <vnum> \n\r", ch);
        return;
    }
    if( !is_number( argument ) )
    {
        send_to_char(" vnum �п�J�Ʀr...\n\r", ch);
        return;
    }

    vnum = atoi( argument );
    if( get_room_index( vnum ) != NULL )
    {
        send_to_char("�o�Ӹ��X�w�g�s�b�F..\n\r", ch );
        return;
    }

    /*
     * Init Room Data ..Qing
     */

    if( room_index_data_free == NULL )
        pRoomIndex  = alloc_perm( sizeof(*pRoomIndex) , TYPE_31 );
    else
    {
        pRoomIndex = room_index_data_free;
        room_index_data_free = room_index_data_free->next;
    }
    reset_room_index_data( pRoomIndex, vnum );
    iHash                       = vnum % MAX_KEY_HASH;
    pRoomIndex->next            = room_index_hash[iHash];
    room_index_hash[iHash]      = pRoomIndex;
    top_room++;

    if( edit_room_data_free == NULL )
        pRoom = alloc_perm( sizeof(*pRoom) , TYPE_39 );
    else
    {
        pRoom = edit_room_data_free;
        edit_room_data_free = edit_room_data_free->next;
    }

    pRoom->room = pRoomIndex;
    pRoom->next = pEdit_room;
    pEdit_room = pRoom;
    send_to_char("OK!\n\r",ch);
}

void do_delroom( CHAR_DATA * ch, char *argument)
{
    ROOM_INDEX_DATA *pRoomIndex,*pRoomHash;
    ROOM_INDEX_DATA *location;
    int vnum, iHash;
    EDIT_ROOM_DATA *  pRoom;

    if( argument == NULL )
    {
        send_to_char("�榡: delroom <vnum> \n\r", ch);
        return;
    }
    if( !is_number( argument ) )
    {
        send_to_char(" vnum �п�J�Ʀr...\n\r", ch);
        return;
    }

    vnum = atoi( argument );
    if( ( pRoomIndex = get_room_index( vnum ) ) == NULL )
    {
        send_to_char("�o�Ӹ��X�ä��s�b.\n\r", ch );
        return;
    }
    location = ch->in_room;
    char_from_room( ch);
    char_to_room( ch, pRoomIndex);
    do_purge(ch,"");                    /* Clear all in Room */
    char_from_room( ch);
    char_to_room( ch, location);
    for( ; pRoomIndex->people != NULL ; )
    {

        if ( ( location = get_room_index( ROOM_VNUM_TEMPLE ) ) == NULL )
        {
            location = get_room_index( ROOM_VNUM_LIMBO);
        }
        if( ch->in_room == location )
            return;
        if( ch->fighting != NULL )
            stop_fighting( ch, TRUE);
        char_from_room( ch );
        char_to_room( ch, location);
        do_look( ch, "auto" );
    }

    iHash                       = vnum % MAX_KEY_HASH;
    if( room_index_hash[iHash] == pRoomIndex )
        room_index_hash[iHash] = pRoomIndex->next;
    else
    {

        for( pRoomHash = room_index_hash[iHash]; pRoomHash != NULL;
                                pRoomHash = pRoomHash->next )
        {
            if( pRoomHash == pRoomIndex )
            {
                char buf[100];
                sprintf( buf, " �R���ж�: %s %d! \n\r", pRoomHash->name,
                                        pRoomHash->vnum);
                send_to_char( buf, ch );
                break;
            }
        }
    }

    if( pRoomIndex == pEdit_room->room )
    {
        pRoom = pEdit_room;
        pEdit_room = pEdit_room->next;
    }
    else
    {
        EDIT_ROOM_DATA *pRoomTmp;
        for( pRoom = pEdit_room; pRoom->next != NULL
                      && pRoom->next->room != pRoomIndex; pRoom = pRoom->next )
                        ; /* �@�� */
        if( pRoom->next == NULL )
        {
            send_to_char(" �ж����s�b !! \n\r", ch );
            return;
        }
        else
        {
            pRoomTmp = pRoom->next;
            pRoom->next = pRoom->next->next;
            pRoom = pRoomTmp;
        }
    }
    top_room--;

    reset_room_index_data( pRoomIndex, vnum );

    if( room_index_data_free == NULL )
        room_index_data_free = pRoomIndex;
    else
    {
        pRoomIndex->next = room_index_data_free;
        room_index_data_free = room_index_data_free->next;
    }

    if( edit_room_data_free == NULL )
        edit_room_data_free = pRoom;
    else
    {
        pRoom->next = edit_room_data_free;
        edit_room_data_free = edit_room_data_free->next;
    }
    send_to_char("OK!\n\r",ch);
}


void do_editroom( CHAR_DATA * ch, char *argument)
{
    char *pArg;
    char command[MAX_INPUT_LENGTH];

    pArg = one_argument( argument, command );

    if( command[0] == '\0' || pArg[0] == '\0' )
    {
        send_to_char("�榡: editroom <command> <argumet> \n\r", ch);
        return;
    }

    if( !str_prefix( command, "name" ) )
    {
        free_string(ch->in_room->name);
        ch->in_room->name               = str_dup( pArg );
        send_to_char("Ok! \n\r", ch);
        return;
    }
    if( !str_prefix( command, "descr" ) )
    {
        free_string(ch->in_room->description);
        sprintf( command,"%s\n",pArg);
        ch->in_room->description                = str_dup( command );
        send_to_char("Ok! \n\r", ch);
        return;
    }
    if( !str_prefix( command, "flag" ) )
    {
        ch->in_room->room_flags         |= atoi( pArg );
        send_to_char("Ok! \n\r", ch);
        return;
    }
    if( !str_prefix( command, "sector" ) )
    {
        ch->in_room->sector_type                |= atoi( pArg );
        send_to_char("Ok! \n\r", ch);
        return;
    }
    if( !str_prefix( command, "list" ) )
    {
        EDIT_ROOM_DATA  * pRoomIndex;
        char            buf[MAX_STRING_LENGTH];

        for( pRoomIndex = pEdit_room; pRoomIndex != NULL;
                                                pRoomIndex = pRoomIndex->next )
        {
            if( pRoomIndex->room->name != NULL )
            {
                sprintf( buf, " [ %6d ]  %s\n\r", pRoomIndex->room->vnum,
                                        pRoomIndex->room->name );
                send_to_char( buf , ch);
            }
            else
            {
                sprintf( buf, " [ %6d ]  �|���w�W\n\r", pRoomIndex->room->vnum);
                send_to_char( buf , ch);
            }
        }
        return;
    }
    if( !str_prefix( command, "clear" ) )
    {
        EDIT_ROOM_DATA *pEdit,*pEdit_next;
        char buf[1000];

        if( str_cmp( pArg, "iamsure") )
        {
            send_to_char("�p�G�u���n�M���Ҧ��s��L�����: editroom clear iamsure\n\r", ch);
            return;
        }
        for( pEdit = pEdit_room; pEdit != NULL; pEdit = pEdit_next)
        {
            pEdit_next = pEdit->next;
            sprintf(buf,"%d",pEdit->room->vnum);
            do_delroom(ch,buf);
        }
    }
    send_to_char("�R�O���ŦX...\n\r", ch);
    return;
}

void do_saveroom( CHAR_DATA * ch, char *argument)
{
    EDIT_ROOM_DATA *pRoom;
    char strsave[MAX_INPUT_LENGTH];
    char arg[MAX_INPUT_LENGTH];
    FILE *fp;

    one_argument( argument, arg );

    sprintf( strsave, "%s%s", TEST_AREA_DIR,  arg );

    fclose(fpReserve);
    if ( ( fp = fopen( strsave, "w" ) ) == NULL )
    {
        send_to_char("�}�ɿ��~!! \n\r", ch );
        return;
    }
    if( pEdit_room == NULL )
    {
        send_to_char("�ثe�S���s�褤���ϰ�...\n\r", ch);
        return;
    }
    fprintf( fp, "#ROOMS\n");
    for( pRoom = pEdit_room; pRoom != NULL; pRoom = pRoom->next )
        fwrite_edit_area( pRoom->room, fp );
    fprintf( fp, "#0\n");
    fclose( fp );
    fpReserve = fopen( NULL_FILE, "r" );
    send_to_char("OK!\n\r",ch);
    return;
}

/* ���V�]�w */
void do_addexit( CHAR_DATA * ch, char *argument)
{
    char direct[MAX_INPUT_LENGTH];
    char *pVnum;
    int vnum, dir;


    pVnum = one_argument( argument, direct );

    if( direct[0] == '\0' || pVnum == NULL )
    {
        send_to_char("�榡: addexit <direct> <vnum> \n\r", ch);
        return;
    }
    if( !is_number( pVnum ) )
    {
        send_to_char(" vnum �п�J�Ʀr...\n\r", ch);
        return;
    }

    vnum = atoi( pVnum );

    if( !str_prefix( direct, "north" ) )
        dir = 0;
    else if( !str_prefix( direct, "east" ) )
        dir = 1;
    else if( !str_prefix( direct, "south" ) )
        dir = 2;
    else if( !str_prefix( direct, "west" ) )
        dir = 3;
    else if( !str_prefix( direct, "up" ) )
        dir = 4;
    else if( !str_prefix( direct, "down" ) )
        dir = 5;
    else
    {
        send_to_char("�A�Q�[�쨺�Ӥ�V�h��..? \n\r", ch);
        return;
    }
    if(  get_room_index( vnum ) == NULL )
    {
        send_to_char(" ���s�h���ж����s�b ! \n\r", ch);
        return;
    }
    if ( ch->in_room->exit[dir] != NULL )
    {
        send_to_char("�o�Ӥ�V�w�g�s�b�F...\n\r", ch );
        return;
    }

    /*
     * Init Exit Data ..Qing
     */

    set_exit( ch->in_room, vnum, dir );
    switch ( dir )
    {
        case 0:
            set_exit( ch->in_room->exit[dir]->to_room, ch->in_room->vnum, 2);
            break;
        case 1:
            set_exit( ch->in_room->exit[dir]->to_room, ch->in_room->vnum, 3);
            break;
        case 2:
            set_exit( ch->in_room->exit[dir]->to_room, ch->in_room->vnum, 0);
            break;
        case 3:
            set_exit( ch->in_room->exit[dir]->to_room, ch->in_room->vnum, 1);
            break;
        case 4:
            set_exit( ch->in_room->exit[dir]->to_room, ch->in_room->vnum, 5);
            break;
        case 5:
            set_exit( ch->in_room->exit[dir]->to_room, ch->in_room->vnum, 4);
            break;
    }
    top_exit++;
    send_to_char("OK!\n\r",ch);
}

/* �u����V�R���Ӥ������V�R�� */
void do_delexit( CHAR_DATA * ch, char *argument)
{
    char direct[MAX_INPUT_LENGTH];
    int dir;


    one_argument( argument, direct );

    if( direct[0] == '\0')
    {
        send_to_char("�榡: delexit <direct>\n\r", ch);
        return;
    }
    if( !str_prefix( direct, "north" ) )
        dir = 0;
    else if( !str_prefix( direct, "east" ) )
        dir = 1;
    else if( !str_prefix( direct, "south" ) )
        dir = 2;
    else if( !str_prefix( direct, "west" ) )
        dir = 3;
    else if( !str_prefix( direct, "up" ) )
        dir = 4;
    else if( !str_prefix( direct, "down" ) )
        dir = 5;
    else
    {
        send_to_char("�A�Q�R�����Ӥ�V���X�f��..? \n\r", ch);
        return;
    }
    if ( ch->in_room->exit[dir] == NULL )
    {
        send_to_char("�o�Ӥ�V�ä��s�b...\n\r", ch );
        return;
    }

    del_exit( ch->in_room, dir );
    top_exit--;
    send_to_char("OK!\n\r",ch);
}

/* �u�W���J�ϰ��ɮ� */
void do_loadarea( CHAR_DATA * ch, char *argument)
{
    char areafile[MAX_INPUT_LENGTH];
    FILE *fp;


    one_argument( argument, areafile );

    if( areafile[0] == '\0')
    {
        send_to_char("�榡: loadarea <areafile name>\n\r", ch);
        return;
    }
    if( ( fp = fopen(areafile,"r") ) == NULL )
    {
        send_to_char("�o���ɮפ��s�b!\n\r", ch);
        return;
    }
    if( load_area_file(ch, fp ) != FALSE )
    {
        send_to_char("���J���\\!!\n\r",ch);
        return;
    }
    else
    {
        send_to_char("���J����!!\n\r", ch);
        return;
    }
    fclose(fp);
    send_to_char("OK!\n\r",ch);
}

void do_copyroom( CHAR_DATA * ch, char *argument)
{
    ROOM_INDEX_DATA *pRoomSource,*pRoomTarget;
    char *pTarget;
    char source[MAX_INPUT_LENGTH];
    int  s_vnum,t_vnum;

    pTarget = one_argument( argument, source );

    if( source[0] == '\0' || pTarget[0] == '\0' )
    {
        send_to_char("�榡: copyroom <source vnum> <target vnum> \n\r", ch);
        return;
    }
    if( !is_number(source) || !is_number(pTarget) )
    {
        send_to_char("�榡: copyroom <source vnum> <target vnum> \n\r", ch);
        return;
    }
    s_vnum = atoi(source);
    t_vnum = atoi(pTarget);
    if( ( pRoomSource = get_room_index( s_vnum ) ) == NULL )
    {
        send_to_char("�ӷ��ж��ä��s�b.\n\r",ch);
        return;
    }
    if( ( pRoomTarget = get_room_index( t_vnum ) ) == NULL )
    {
        do_addroom(ch, pTarget);
        if( ( pRoomTarget = get_room_index( t_vnum) ) == NULL )
        {
            send_to_char("�L�k�}�ҥت��ж�.\n\r", ch);
            return;
        }
    }
    else
    {
        free_string(pRoomTarget->name);
        free_string(pRoomTarget->description);
    }
    pRoomTarget->name = strdup(pRoomSource->name);
    pRoomTarget->description = strdup(pRoomSource->description);
    pRoomTarget->room_flags = pRoomSource->room_flags;
    pRoomTarget->light = pRoomSource->light;
    pRoomTarget->sector_type = pRoomSource->sector_type;
    send_to_char("OK!\n\r",ch);
    return;
}

